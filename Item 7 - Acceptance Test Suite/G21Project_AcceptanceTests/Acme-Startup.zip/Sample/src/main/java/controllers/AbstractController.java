/*
 * AbstractController.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;


import domain.Announcement;


import services.AnnouncementService;
import domain.Announcement;
import domain.Configuration;
import services.AnnouncementService;
import services.ConfigurationService;

@Controller
public class AbstractController {

	
	@Autowired
	ConfigurationService configurationService;
	
	@Autowired
	AnnouncementService announcementService;
	// Panic handler ----------------------------------------------------------

	@ExceptionHandler(Throwable.class)
	public ModelAndView panic(final Throwable oops) {
		ModelAndView result;

		result = new ModelAndView("misc/panic");
		result.addObject("name", ClassUtils.getShortName(oops.getClass()));
		result.addObject("exception", oops.getMessage());
		result.addObject("stackTrace", ExceptionUtils.getStackTrace(oops));
		
		String aux = "";
		
		Collection<Configuration> ee = configurationService.findAll();
		for(Configuration c : ee){
			aux = c.getBanner();
		}
		result.addObject("photo", aux);

		return result;

	}
	
	
	@ModelAttribute(value = "banner")
	public String banner() {
		String result = "";

		Collection<Configuration> ee = configurationService.findAll();
		for(Configuration c : ee){
			result = c.getBanner();
		}
		
		return result;
	}
	
	
	@ModelAttribute(value = "footer")
	public String footer() {

		String footer = "";
		int aux = 0;
		int num = 0;
		Collection<Announcement> advs = new ArrayList<Announcement>();

		advs = announcementService.findAll();
		aux = advs.size();
		if (aux != 0) {
			num = (int) (Math.random() * aux);
			Announcement adv = (Announcement) advs.toArray()[num];
			footer = adv.getBanner();
			link(adv);
		}
		
		return footer;
	}
	
	
	@ModelAttribute(value = "link")
	public String link(Announcement a) {

				
		return a.getLink();
	}

}
