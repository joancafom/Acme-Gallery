
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Actor;
import domain.Admin;
import domain.Company;
import domain.CreditCard;
import domain.Merchant;
import domain.Sponsor;
import domain.User;
import forms.CreditCardForm;
import forms.EditActorForm;
import forms.EditActorPassword;
import forms.EditUserForm;
import forms.UserAccountForm;
import security.UserAccount;
import services.ActorService;
import services.AdminService;
import services.CompanyService;
import services.MerchantService;
import services.SponsorService;
import services.UserService;

@Controller
@RequestMapping("/actor")
public class ActorController extends AbstractController {

	@Autowired
	private ActorService actorService;

	@Autowired
	private UserService userService;

	@Autowired
	private AdminService adminService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private SponsorService sponsorService;

	@Autowired
	private MerchantService merchantService;


	// Constructors -----------------------------------------------------------
	public ActorController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();
		result = new ModelAndView("actor/list");

		if (actor.getClass() == User.class) {
			actor = userService.findOne(actor.getId());
		} else if (actor.getClass() == Admin.class) {
			actor = adminService.findOne(actor.getId());
		} else if (actor.getClass() == Company.class) {
			actor = companyService.findOne(actor.getId());
		} else if (actor.getClass() == Merchant.class) {
			actor = merchantService.findOne(actor.getId());
		} else if (actor.getClass() == Sponsor.class) {
			actor = sponsorService.findOne(actor.getId());
		}

		result.addObject("a", actor);
		result.addObject("requestURI", "actor/list.do");

		return result;
	}

	//PASSWORD
	@RequestMapping(value = "/editPassword", method = RequestMethod.GET)
	public ModelAndView editPassword() {
		ModelAndView result;
		EditActorPassword editActorForm;
		editActorForm = new EditActorPassword();

		result = createEditModelAndViewPassword(editActorForm);
		result.addObject("editActorForm", editActorForm);
		result.addObject("requestURI", "actor/editPassword.do");

		return result;
	}

	@RequestMapping(value = "/editPassword", method = RequestMethod.POST, params = "savePassword")
	public ModelAndView savePassword(@Valid EditActorPassword actorForm, BindingResult binding) {
		ModelAndView result;
		Actor registeredActor = actorService.findByPrincipal();
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();

		String contrasenyaCodificada = encoder.encodePassword(actorForm.getPassword(), null);

		if (binding.hasErrors()) {
			result = createEditModelAndViewPassword(actorForm);
		} else if (!contrasenyaCodificada.equals(registeredActor.getUserAccount().getPassword())) {
			result = createEditModelAndViewPassword(actorForm, "actor.commit.errorP");
		} else if (!actorForm.getNewPassword().equals(actorForm.getConfNewPassword())) {
			result = createEditModelAndViewPassword(actorForm, "actor.commit.errorD");
		} else {
			try {
				if (registeredActor.getClass() == User.class) {
					User u = userService.findOne(registeredActor.getId());

					// UserAccount --------------------------------------------
					u.getUserAccount().setPassword(actorForm.getNewPassword());
					u.getUserAccount().setPassword(encoder.encodePassword(actorForm.getNewPassword(), null));

					userService.save(u);
				} else if (registeredActor.getClass() == Admin.class) {
					Admin admin = adminService.findOne(registeredActor.getId());
					admin.getUserAccount().setPassword(actorForm.getNewPassword());
					admin.getUserAccount().setPassword(encoder.encodePassword(actorForm.getNewPassword(), null));
					adminService.save(admin);
				} else if (registeredActor.getClass() == Sponsor.class) {
					Sponsor sponsor = sponsorService.findOne(registeredActor.getId());
					sponsor.getUserAccount().setPassword(actorForm.getNewPassword());
					sponsor.getUserAccount().setPassword(encoder.encodePassword(actorForm.getNewPassword(), null));
					sponsorService.save(sponsor);
				} else if (registeredActor.getClass() == Company.class) {
					Company company = companyService.findOne(registeredActor.getId());
					company.getUserAccount().setPassword(actorForm.getNewPassword());
					company.getUserAccount().setPassword(encoder.encodePassword(actorForm.getNewPassword(), null));
					companyService.save(company);
				} else if (registeredActor.getClass() == Merchant.class) {
					Merchant merchant = merchantService.findOne(registeredActor.getId());
					merchant.getUserAccount().setPassword(actorForm.getNewPassword());
					merchant.getUserAccount().setPassword(encoder.encodePassword(actorForm.getNewPassword(), null));
					merchantService.save(merchant);
				}

				result = new ModelAndView("redirect:/");
			} catch (Throwable oops) {
				result = createEditModelAndViewPassword(actorForm, "actor.commit.error");
			}
		}
		return result;
	}

	//EDIT USER
	@RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public ModelAndView editUser() {
		ModelAndView result;

		Actor actor = actorService.findByPrincipal();
		EditUserForm editUserForm;
		editUserForm = new EditUserForm();
		result = createEditModelAndViewUser(editUserForm);
		actor = userService.findOne(actor.getId());
		result.addObject("editUserForm", editUserForm);
		result.addObject("actor", actor);

		return result;
	}

	@RequestMapping(value = "/editUser", method = RequestMethod.POST, params = "saveUser")
	public ModelAndView save(@Valid EditUserForm editUserForm, BindingResult binding) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createEditModelAndViewUser(editUserForm);
		} else if (actorService.emailsSavedInBD().contains(editUserForm.getEmail())) {
			result = createEditModelAndViewUser(editUserForm, "security.emailError");
		} else {
			try {

				User u = userService.findOne(actor.getId());
				u.setName(editUserForm.getName());
				u.setSurname(editUserForm.getSurname());
				u.setEmail(editUserForm.getEmail());
				u.setPhone(editUserForm.getPhone());
				u.setAddress(editUserForm.getAddress());
				u.setPostalAddress(editUserForm.getPostalAddress());
				u.setProfession(editUserForm.getProfession());
				userService.save(u);

				result = new ModelAndView("redirect:/");

			} catch (Throwable oops) {
				result = createEditModelAndViewUser(editUserForm, "actor.commit.error");
			}
		}
		return result;
	}

	//EDIT USER
	@RequestMapping(value = "/editActor", method = RequestMethod.GET)
	public ModelAndView editActor() {
		ModelAndView result;

		Actor actor = actorService.findByPrincipal();
		EditActorForm editActorForm;
		editActorForm = new EditActorForm();
		result = createEditModelAndViewActor(editActorForm);

		if (actor.getClass() == Admin.class) {
			actor = adminService.findOne(actor.getId());
		} else if (actor.getClass() == Company.class) {
			actor = companyService.findOne(actor.getId());
		} else if (actor.getClass() == Merchant.class) {
			actor = merchantService.findOne(actor.getId());
		} else if (actor.getClass() == Sponsor.class) {
			actor = sponsorService.findOne(actor.getId());
		}

		result.addObject("editActorForm", editActorForm);
		result.addObject("actor", actor);

		return result;
	}

	@RequestMapping(value = "/editActor", method = RequestMethod.POST, params = "saveActor")
	public ModelAndView save(@Valid EditActorForm editActorForm, BindingResult binding) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createEditModelAndViewActor(editActorForm);
		} else if (actorService.emailsSavedInBD().contains(editActorForm.getEmail())) {
			result = createEditModelAndViewActor(editActorForm, "security.emailError");
		} else {
			try {

				if (actor.getClass() == Admin.class) {
					Admin u = adminService.findOne(actor.getId());
					u.setName(editActorForm.getName());
					u.setEmail(editActorForm.getEmail());
					u.setPhone(editActorForm.getPhone());
					u.setAddress(editActorForm.getAddress());
					u.setPostalAddress(editActorForm.getPostalAddress());
					adminService.save(u);
				} else if (actor.getClass() == Company.class) {
					Company u = companyService.findOne(actor.getId());
					u.setName(editActorForm.getName());
					u.setEmail(editActorForm.getEmail());
					u.setPhone(editActorForm.getPhone());
					u.setAddress(editActorForm.getAddress());
					u.setPostalAddress(editActorForm.getPostalAddress());
					companyService.save(u);
				} else if (actor.getClass() == Merchant.class) {
					Merchant u = merchantService.findOne(actor.getId());
					u.setName(editActorForm.getName());
					u.setEmail(editActorForm.getEmail());
					u.setPhone(editActorForm.getPhone());
					u.setAddress(editActorForm.getAddress());
					u.setPostalAddress(editActorForm.getPostalAddress());
					merchantService.save(u);
				} else if (actor.getClass() == Sponsor.class) {
					Sponsor u = sponsorService.findOne(actor.getId());
					u.setName(editActorForm.getName());
					u.setEmail(editActorForm.getEmail());
					u.setPhone(editActorForm.getPhone());
					u.setAddress(editActorForm.getAddress());
					u.setPostalAddress(editActorForm.getPostalAddress());
					sponsorService.save(u);
				}

				result = new ModelAndView("redirect:/");

			} catch (Throwable oops) {
				result = createEditModelAndViewActor(editActorForm, "actor.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "admin/listBannedActor", method = RequestMethod.GET)
	public ModelAndView listBannedActors() {
		ModelAndView result;
		Collection<Actor> cA = actorService.actorBanneds();

		result = new ModelAndView("actor/admin/listBannedActor");
		result.addObject("banneds", cA);
		result.addObject("requestURI", "actor/admin/listBannedActor.do");

		return result;
	}

	@RequestMapping(value = "admin/bannedActor", method = RequestMethod.GET)
	public ModelAndView bannedActor(@RequestParam Integer idActor) {
		ModelAndView result;

		Actor actor = actorService.actorPerId(idActor);
		result = new ModelAndView("actor/admin/bannedActor");
		result.addObject("userAccount", actor.getUserAccount());
		result.addObject("requestURI", "actor/admin/bannedActor.do");
		return result;
	}

	@RequestMapping(value = "/admin/bannedActor", method = RequestMethod.POST, params = "bannedActorTrue")
	public ModelAndView bannedActor(@Valid UserAccountForm userAccount, RedirectAttributes redirectAttrs, BindingResult binding) {
		ModelAndView result;

		UserAccount res = actorService.findUserAccountId(userAccount.getId());
		Boolean resr = false;
		if (res == null) {
			resr = true;
		}
		Actor actor = actorService.findByUserAccount(res);

		if (binding.hasErrors()) {
			result = createEditModelAndViewUserAccount(userAccount);
		} else if (resr) {
			result = new ModelAndView("redirect:actor/admin/listActors.do");
			redirectAttrs.addFlashAttribute("message", "accessDenied");
		} else {
			try {
				Assert.isTrue(res != null);
				Assert.isTrue(actorService.authorityByActorId(actor.getId()) != "ADMIN");
				res.setBanned(userAccount.getBanned());
				actor.setUserAccount(res);
				actorService.save(actor);
				Collection<Actor> cA = actorService.actorBanneds();
				result = new ModelAndView("redirect:listActors.do");
				result.addObject("banneds", cA);
			} catch (Throwable oops) {
				if (actorService.authorityByActorId(actor.getId()) == "ADMIN") {
					result = new ModelAndView("redirect:actor/admin/listActors.do");
					redirectAttrs.addFlashAttribute("message", "accessDenied");
				} else if (res == null) {
					result = new ModelAndView("redirect:actor/admin/listActors.do");
					redirectAttrs.addFlashAttribute("message", "accessDenied");
				} else {
					result = createEditModelAndViewUserAccount(userAccount, "actor.commit.error");
				}

			}
		}
		return result;
	}

	@RequestMapping(value = "admin/listActors", method = RequestMethod.GET)
	public ModelAndView listSuspiciousActors() {
		ModelAndView result;
		Collection<Actor> cA = actorService.findAllActors();
		cA.removeAll(actorService.actorBanneds());

		result = new ModelAndView("actor/admin/listActors");
		result.addObject("suspicious", cA);
		result.addObject("requestURI", "actor/admin/listActors.do");

		return result;
	}

	//CREDIT CARD----------------------------------------------------------------
	@RequestMapping(value = "/createCreditCard", method = RequestMethod.GET)
	public ModelAndView createCreditCard(RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();
		try {

			if (actor.getClass() == User.class) {
				actor = userService.findOne(actor.getId());
				User u = userService.findOne(actor.getId());
				Assert.isTrue(u.getCreditCard() == null);
			} else if (actor.getClass() == Company.class) {
				actor = companyService.findOne(actor.getId());
				Company s = companyService.findOne(actor.getId());
				Assert.isTrue(s.getCreditCard() == null);
			}
			CreditCardForm creditCardForm;
			creditCardForm = new CreditCardForm();
			result = createEditModelAndViewCreditCard(creditCardForm);
			result.addObject("creditCardForm", creditCardForm);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:list.do");
			result.addObject("a", actor);
			result.addObject("requestURI", "actor/list.do");
			redirectAttrs.addFlashAttribute("message", "ustTar");
		}

		return result;
	}

	@RequestMapping(value = "/editCreditCard", method = RequestMethod.GET)
	public ModelAndView editCreditCard() {
		ModelAndView result;
		CreditCardForm creditCardForm;
		creditCardForm = new CreditCardForm();
		Actor actor = actorService.findByPrincipal();
		CreditCard creditCard = null;
		if (actor.getClass() == User.class) {
			User u = userService.findOne(actor.getId());
			creditCard = u.getCreditCard();
		} else if (actor.getClass() == Company.class) {
			Company u = companyService.findOne(actor.getId());
			creditCard = u.getCreditCard();
		}
		result = createEditModelAndViewCreditCard2(creditCardForm);

		result.addObject("creditCardForm", creditCardForm);
		result.addObject("creditCard", creditCard);

		return result;
	}

	@RequestMapping(value = "/createCreditCard", method = RequestMethod.POST, params = "saveCreditCard")
	public ModelAndView saveCreditCard(@Valid CreditCardForm creditCardForm, BindingResult binding) {
		ModelAndView result;
		Actor registeredActor = actorService.findByPrincipal();

		if (creditCardForm.getExpirationYear().trim().length() == 0) {
			creditCardForm.setExpirationYear("00");
		}
		if (creditCardForm.getExpirationMonth().trim().length() == 0) {
			creditCardForm.setExpirationMonth("00");
		}

		DateTime d = new DateTime(System.currentTimeMillis());
		int year = Integer.parseInt(creditCardForm.getExpirationYear());
		int month = Integer.parseInt(creditCardForm.getExpirationMonth());
		Integer n = d.getYear();
		Integer y = Integer.parseInt(n.toString().substring(2));
		Integer m = d.getMonthOfYear();

		if (binding.hasErrors()) {
			result = createEditModelAndViewCreditCard(creditCardForm);
		} else {
			try {
				Assert.isTrue(!(y > year));
				if (y == year && month < m) {
					Assert.isTrue(false, y + "==" + year + "---" + m + "::" + month);
				}

				if (registeredActor.getClass() == User.class) {
					User u = userService.findOne(registeredActor.getId());
					CreditCard creditCard = new CreditCard();
					creditCard.setBrandName(creditCardForm.getBrandName());
					creditCard.setCvvCode(creditCardForm.getCvvCode());
					creditCard.setExpirationMonth(creditCardForm.getExpirationMonth());
					creditCard.setExpirationYear(creditCardForm.getExpirationYear());
					creditCard.setHolderName(creditCardForm.getHolderName());
					creditCard.setNumber(creditCardForm.getNumber());
					u.setCreditCard(creditCard);
					userService.save(u);
				} else if (registeredActor.getClass() == Company.class) {
					Company u = companyService.findOne(registeredActor.getId());
					CreditCard creditCard = new CreditCard();
					creditCard.setBrandName(creditCardForm.getBrandName());
					creditCard.setCvvCode(creditCardForm.getCvvCode());
					creditCard.setExpirationMonth(creditCardForm.getExpirationMonth());
					creditCard.setExpirationYear(creditCardForm.getExpirationYear());
					creditCard.setHolderName(creditCardForm.getHolderName());
					creditCard.setNumber(creditCardForm.getNumber());
					u.setCreditCard(creditCard);
					companyService.save(u);
				}

				result = new ModelAndView("redirect:/");

			} catch (Throwable oops) {
				if ((y == year && month < m) | (year < y)) {
					result = createEditModelAndViewCreditCard(creditCardForm, "actor.creditCardError");
				} else {
					result = createEditModelAndViewCreditCard(creditCardForm, "actor.commit.error");
				}

			}
		}
		return result;
	}

	@RequestMapping(value = "/editCreditCard", method = RequestMethod.POST, params = "saveCreditCardEdit")
	public ModelAndView saveCreditCard2(@Valid CreditCardForm creditCardForm, BindingResult binding) {
		ModelAndView result;
		Actor registeredActor = actorService.findByPrincipal();

		if (creditCardForm.getExpirationYear().trim().length() == 0) {
			creditCardForm.setExpirationYear("00");
		}
		if (creditCardForm.getExpirationMonth().trim().length() == 0) {
			creditCardForm.setExpirationMonth("00");
		}

		DateTime d = new DateTime(System.currentTimeMillis());
		int year = Integer.parseInt(creditCardForm.getExpirationYear());
		int month = Integer.parseInt(creditCardForm.getExpirationMonth());
		Integer n = d.getYear();
		Integer y = Integer.parseInt(n.toString().substring(2));
		Integer m = d.getMonthOfYear();

		if (binding.hasErrors()) {
			result = createEditModelAndViewCreditCard2(creditCardForm);
		} else {
			try {
				Assert.isTrue(!(y > year));
				if (y == year && month < m) {
					Assert.isTrue(false, y + "==" + year + "---" + m + "::" + month);
				}

				if (registeredActor.getClass() == User.class) {
					User u = userService.findOne(registeredActor.getId());
					CreditCard creditCard = new CreditCard();
					creditCard.setBrandName(creditCardForm.getBrandName());
					creditCard.setCvvCode(creditCardForm.getCvvCode());
					creditCard.setExpirationMonth(creditCardForm.getExpirationMonth());
					creditCard.setExpirationYear(creditCardForm.getExpirationYear());
					creditCard.setHolderName(creditCardForm.getHolderName());
					creditCard.setNumber(creditCardForm.getNumber());
					u.setCreditCard(creditCard);
					userService.save(u);
				} else if (registeredActor.getClass() == Company.class) {
					Company u = companyService.findOne(registeredActor.getId());
					CreditCard creditCard = new CreditCard();
					creditCard.setBrandName(creditCardForm.getBrandName());
					creditCard.setCvvCode(creditCardForm.getCvvCode());
					creditCard.setExpirationMonth(creditCardForm.getExpirationMonth());
					creditCard.setExpirationYear(creditCardForm.getExpirationYear());
					creditCard.setHolderName(creditCardForm.getHolderName());
					creditCard.setNumber(creditCardForm.getNumber());
					u.setCreditCard(creditCard);
					companyService.save(u);
				}

				result = new ModelAndView("redirect:/");

			} catch (Throwable oops) {
				if ((y == year && month < m) | (year < y)) {
					result = createEditModelAndViewCreditCard2(creditCardForm, "actor.creditCardError");
				} else {
					result = createEditModelAndViewCreditCard2(creditCardForm, "actor.commit.error");
				}
			}
		}
		return result;
	}

	//CREDIT CARD----------------------------------------------------------------
	@RequestMapping(value = "/actorPRO", method = RequestMethod.GET)
	public ModelAndView actorPRO(RedirectAttributes redirectAttrs) {
		ModelAndView result = null;

		Actor actor = actorService.findByPrincipal();
		DateTime d = new DateTime(System.currentTimeMillis());
		int year = 0;
		int month = 0;
		Integer n = 0;
		Integer y = 0;
		Integer m = 0;
		if (actor.getClass() == User.class) {
			User u = userService.findOne(actor.getId());
			CreditCard c = u.getCreditCard();
			if (c.getExpirationYear().trim().length() == 0) {
				c.setExpirationYear("00");
			}
			if (c.getExpirationMonth().trim().length() == 0) {
				c.setExpirationMonth("00");
			}

			year = Integer.parseInt(c.getExpirationYear());
			month = Integer.parseInt(c.getExpirationMonth());
			n = d.getYear();
			y = Integer.parseInt(n.toString().substring(2));
			m = d.getMonthOfYear();

		} else if (actor.getClass() == Company.class) {
			Company u = companyService.findOne(actor.getId());
			CreditCard c = u.getCreditCard();
			if (c.getExpirationYear().trim().length() == 0) {
				c.setExpirationYear("00");
			}
			if (c.getExpirationMonth().trim().length() == 0) {
				c.setExpirationMonth("00");
			}
			year = Integer.parseInt(c.getExpirationYear());
			month = Integer.parseInt(c.getExpirationMonth());
			n = d.getYear();
			y = Integer.parseInt(n.toString().substring(2));
			m = d.getMonthOfYear();
		}

		try {

			Assert.isTrue(!(y > year));
			if (y == year && month < m) {
				Assert.isTrue(false, y + "==" + year + "---" + m + "::" + month);
			}

			if (actor.getClass() == User.class) {
				User u = userService.findOne(actor.getId());
				u.setPro(true);
				userService.save(u);
			} else if (actor.getClass() == Company.class) {
				Company u = companyService.findOne(actor.getId());
				u.setPro(true);
				companyService.save(u);
			}

			result = new ModelAndView("redirect:/actor/list.do");
			result.addObject("a", actor);
			result.addObject("requestURI", "actor/list.do");

		} catch (Throwable oops) {
			if ((y == year && month < m) | (year < y)) {
				result = new ModelAndView("redirect:/actor/list.do");
				result.addObject("a", actor);
				result.addObject("requestURI", "actor/list.do");
				redirectAttrs.addFlashAttribute("message", "creditCardError");
			} else {
				result = new ModelAndView("redirect:/actor/list.do");
				result.addObject("a", actor);
				result.addObject("requestURI", "actor/list.do");
				redirectAttrs.addFlashAttribute("message", "ERROR");
			}
		}

		return result;
	}

	@RequestMapping(value = "/actorNoPRO", method = RequestMethod.GET)
	public ModelAndView actorNoPRO() {
		ModelAndView result = null;
		Actor actor = actorService.findByPrincipal();

		if (actor.getClass() == User.class) {
			User u = userService.findOne(actor.getId());
			u.setPro(false);
			userService.save(u);
		} else if (actor.getClass() == Company.class) {
			Company u = companyService.findOne(actor.getId());
			u.setPro(false);
			companyService.save(u);
		}

		result = new ModelAndView("redirect:/actor/list.do");
		result.addObject("a", actor);
		result.addObject("requestURI", "actor/list.do");
		return result;
	}

	protected ModelAndView createEditModelAndViewPassword(EditActorPassword actorForm) {
		ModelAndView result;
		result = createEditModelAndViewPassword(actorForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewPassword(EditActorPassword actor, String message) {
		ModelAndView result;

		result = new ModelAndView("actor/editPassword");
		result.addObject("editActorPassword", actor);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewUser(EditUserForm editUserForm) {
		ModelAndView result;
		result = createEditModelAndViewUser(editUserForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewUser(EditUserForm editUserForm, String message) {
		ModelAndView result;

		result = new ModelAndView("actor/editUser");
		result.addObject("editUserForm", editUserForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewActor(EditActorForm editActorForm) {
		ModelAndView result;
		result = createEditModelAndViewActor(editActorForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewActor(EditActorForm editActorForm, String message) {
		ModelAndView result;

		result = new ModelAndView("actor/editActor");
		result.addObject("editActorForm", editActorForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewUserAccount(UserAccountForm userAccount) {
		ModelAndView result;
		result = createEditModelAndViewUserAccount(userAccount, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewUserAccount(UserAccountForm userAccount, String message) {
		ModelAndView result;

		UserAccount ua = actorService.findUserAccountId(userAccount.getId());
		Actor actor = actorService.findByUserAccount(ua);
		result = new ModelAndView("actor/admin/bannedActor.do?idActor=" + actor.getId());
		result.addObject("userAccount", userAccount);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewCreditCard(CreditCardForm creditCardForm) {
		ModelAndView result;
		result = createEditModelAndViewCreditCard(creditCardForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewCreditCard(CreditCardForm creditCardForm, String message) {
		ModelAndView result;

		result = new ModelAndView("actor/createCreditCard");
		result.addObject("creditCardForm", creditCardForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewCreditCard2(CreditCardForm creditCardForm) {
		ModelAndView result;
		result = createEditModelAndViewCreditCard2(creditCardForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewCreditCard2(CreditCardForm creditCardForm, String message) {
		ModelAndView result;

		result = new ModelAndView("actor/editCreditCard");
		result.addObject("creditCardForm", creditCardForm);
		result.addObject("message", message);

		return result;
	}
}
