/*
 * AdministratorController.java
 *
 * Copyright (C) 2017 Universidad de Sevilla
 *
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Actor;
import domain.Company;
import domain.Raffle;
import domain.User;
import services.ActorService;
import services.AdminService;
import services.CompanyService;
import services.UserService;

@Controller
@RequestMapping("/administrator")
public class AdministratorController extends AbstractController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private ActorService actorService;

	@Autowired
	private UserService userService;

	@Autowired
	private CompanyService companyService;


	// Constructors -----------------------------------------------------------

	public AdministratorController() {
		super();
	}

	@RequestMapping(value = "/listActorPRO", method = RequestMethod.GET)
	public ModelAndView listActorPRO() {
		ModelAndView result = null;

		Collection<Actor> actorListPRO = actorService.actorsPRO();
		result = new ModelAndView("administrator/listActorPRO");
		result.addObject("actorListPRO", actorListPRO);
		return result;
	}

	@RequestMapping(value = "/actorNoPRO", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("idActor") int idActor, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Collection<Actor> actorListPRO = actorService.actorsPRO();
		try {

			Actor actor = actorService.findOne(idActor);
			Assert.isTrue(actor.getClass() != User.class || actor.getClass() != Company.class);

			if (actor.getClass() == User.class) {
				User u = userService.findOne(idActor);
				Assert.isTrue(u.getPro() != false);
				u.setPro(false);
				userService.save(u);
			} else if (actor.getClass() == Company.class) {
				Company u = companyService.findOne(idActor);
				Assert.isTrue(u.getPro() != false);
				u.setPro(false);
				companyService.save(u);
			}

			result = new ModelAndView("redirect:/administrator/listActorPRO.do");
			result.addObject("actorListPRO", actorListPRO);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/administrator/listActorPRO.do");
			result.addObject("actorListPRO", actorListPRO);
			redirectAttrs.addFlashAttribute("message", "actorNoPRO");
		}

		return result;
	}

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public ModelAndView dashboard() {
		ModelAndView result;
		result = new ModelAndView("administrator/dashboard");

		/*
		 * Query 1 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero ofertas por startup.
		 */

		Object[] one = adminService.offerstPerStartup();
		Double avgOne = (Double) one[0];
		Integer maxOne = (Integer) one[1];
		Integer minOne = (Integer) one[2];
		Double stddevOne = (Double) one[3];
		Object[] tableOne = {
			1
		};
		result.addObject("tableOne", tableOne);
		result.addObject("avgOne", avgOne);
		result.addObject("stddevOne", stddevOne);
		result.addObject("maxOne", maxOne);
		result.addObject("minOne", minOne);

		/*
		 * Query 2 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de datos personales por oferta.
		 */

		Object[] two = adminService.offerstPerPersonalData();
		Double avgTwo = (Double) two[0];
		Integer maxTwo = (Integer) two[1];
		Integer minTwo = (Integer) two[2];
		Double stddevTwo = (Double) two[3];
		Object[] tableTwo = {
			2
		};
		result.addObject("tableTwo", tableTwo);
		result.addObject("avgTwo", avgTwo);
		result.addObject("maxTwo", maxTwo);
		result.addObject("minTwo", minTwo);
		result.addObject("stddevTwo", stddevTwo);

		/*
		 * Query 3 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de startups que tienen las compa�ias.
		 */

		Object[] three = adminService.startupsPerCompany();
		Double avgThree = (Double) three[0];
		Integer maxThree = (Integer) three[1];
		Integer minThree = (Integer) three[2];
		Double stddevThree = (Double) three[3];
		Object[] tableThree = {
			3
		};
		result.addObject("tableThree", tableThree);
		result.addObject("avgThree", avgThree);
		result.addObject("maxThree", maxThree);
		result.addObject("minThree", minThree);
		result.addObject("stddevThree", stddevThree);

		/*
		 * Query 1 - B
		 * La media, el total y la desviaci�n t�pica del n�mero de usuarios premium.
		 */

		Double avgFour = adminService.avgUsersPro();
		Integer totalFour = adminService.countUsersPro();
		Double stddevFour = adminService.stddevUsersPro();
		Object[] tableFour = {
			4
		};
		result.addObject("tableFour", tableFour);
		result.addObject("stddevFour", stddevFour);
		result.addObject("totalFour", totalFour);
		result.addObject("avgFour", avgFour);

		/*
		 * Query 2 - B
		 * La media, el total y la desviaci�n t�pica del n�mero de compa��as premium.
		 */

		Double avgFive = adminService.avgCompaniesPro();
		Integer totalFive = adminService.countCompaniesPro();
		Double stddevFive = adminService.stddevCompaniesPro();
		Object[] tableFive = {
			5
		};
		result.addObject("tableFive", tableFive);
		result.addObject("stddevFive", stddevFive);
		result.addObject("totalFive", totalFive);
		result.addObject("avgFive", avgFive);

		/*
		 * Query 4 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de comentarios por usuario.
		 */

		Object[] six = adminService.startupsPerCompany();
		Double avgSix = (Double) six[0];
		Integer maxSix = (Integer) six[1];
		Integer minSix = (Integer) six[2];
		Double stddevSix = (Double) six[3];
		Object[] tableSix = {
			6
		};
		result.addObject("tableSix", tableSix);
		result.addObject("stddevSix", stddevSix);
		result.addObject("minSix", minSix);
		result.addObject("maxSix", maxSix);
		result.addObject("avgSix", avgSix);

		/*
		 * Query 3 - B
		 * El porcentaje de empresas con al menos un �tem en venta.
		 */

		Double percentSeven = adminService.itemsPerCompanyEnVenta();
		Object[] tableSeven = {
			7
		};
		result.addObject("tableSeven", tableSeven);
		result.addObject("percentSeven", percentSeven);

		/*
		 * Query 4 - B
		 * El porcentaje de usuarios con al menos un �tem en su historial de compras.
		 */

		Double percentEight = adminService.itemsBuyStorePerUser();
		Object[] tableEight = {
			8
		};
		result.addObject("tableEight", tableEight);
		result.addObject("percentEight", percentEight);

		/*
		 * Query 9 - C
		 * El porcentaje de startups con al menos un 10% m�s de ofertas que la media.
		 */

		Double percentNine = adminService.avgOffersPerStartupAverage();
		Object[] tableNine = {
			9
		};
		result.addObject("tableNine", tableNine);
		result.addObject("percentNine", percentNine);

		/*
		 * Query 10 - C
		 * El porcentaje de startups con al menos un 10% m�s de novedades que la media
		 */

		Double percentTen = adminService.avgNewsPerStartupAverage();
		Object[] tableTen = {
			10
		};
		result.addObject("tableTen", tableTen);
		result.addObject("percentTen", percentTen);

		/*
		 * Query 1 - A
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de usuarios inscritos en el sorteo.
		 */

		Object[] eleven = adminService.usersPerRaffle();
		Double avgEleven = (Double) eleven[0];
		Integer maxEleven = (Integer) eleven[1];
		Integer minEleven = (Integer) eleven[2];
		Double stddevEleven = (Double) eleven[3];
		Object[] tableEleven = {
			11
		};
		result.addObject("tableEleven", tableEleven);
		result.addObject("stddevEleven", stddevEleven);
		result.addObject("minEleven", minEleven);
		result.addObject("maxEleven", maxEleven);
		result.addObject("avgEleven", avgEleven);

		/*
		 * Query 2 - A
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de comentarios que tienen las noticias
		 */

		Object[] twelve = adminService.usersPerRaffle();
		Double avgTwelve = (Double) twelve[0];
		Integer maxTwelve = (Integer) twelve[1];
		Integer minTwelve = (Integer) twelve[2];
		Double stddevTwelve = (Double) twelve[3];
		Object[] tableTwelve = {
			12
		};
		result.addObject("tableTwelve", tableTwelve);
		result.addObject("stddevTwelve", stddevTwelve);
		result.addObject("minTwelve", minTwelve);
		result.addObject("maxTwelve", maxTwelve);
		result.addObject("avgTwelve", avgTwelve);

		/*
		 * Query 3 - A
		 * Las rifas que ya han terminado a d�a de hoy.
		 */

		Collection<Raffle> listRaffle = adminService.rafflesEnds();
		Object[] tableThirteen = {
			13
		};
		result.addObject("listRaffle", listRaffle);
		result.addObject("tableThirteen", tableThirteen);

		/*
		 * Query 4 - A
		 * Las rifas que no han terminado a d�a de hoy.
		 */

		Collection<Raffle> listRaffleNo = adminService.rafflesNoEnd();
		Object[] tableFourteen = {
			14
		};
		result.addObject("listRaffleNo", listRaffleNo);
		result.addObject("tableFourteen", tableFourteen);

		/*
		 * Query 5 - C
		 * Tantos por ciento de intereses por Trabajo y Educaci�n.
		 */

		Double percentWork = adminService.percentWorksInterestingData();
		Double percentEducation = adminService.percentEducationsInterestingData();
		Object[] tableFiveteen = {
			15
		};
		result.addObject("percentWork", percentWork);
		result.addObject("percentEducation", percentEducation);
		result.addObject("tableFiveteen", tableFiveteen);

		/*
		 * Query 6 - C
		 * El porcentaje de Usuarios, Compa��as, Vendedores y Sponsors en el sistema.
		 */

		Double percentUsers = adminService.percentUsers();
		Double percentSponsors = adminService.percentSponsors();
		Double percentCompanies = adminService.percentCompanies();
		Double percentMerchants = adminService.percentMerchants();
		Object[] tableSixteen = {
			16
		};

		result.addObject("percentUsers", percentUsers);
		result.addObject("percentSponsors", percentSponsors);
		result.addObject("percentCompanies", percentCompanies);
		result.addObject("percentMerchants", percentMerchants);
		result.addObject("tableSixteen", tableSixteen);

		/*
		 * Query 7 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de ventas de los vendedores.
		 */

		Object[] seventeen = adminService.sellsPerMerchants();
		Double avgSeventeen = (Double) seventeen[0];
		Integer maxSeventeen = (Integer) seventeen[1];
		Integer minSeventeen = (Integer) seventeen[2];
		Double stddevSeventeen = (Double) seventeen[3];
		Object[] tableSeventeen = {
			17
		};
		result.addObject("avgSeventeen", avgSeventeen);
		result.addObject("maxSeventeen", maxSeventeen);
		result.addObject("minSeventeen", minSeventeen);
		result.addObject("stddevSeventeen", stddevSeventeen);
		result.addObject("tableSeventeen", tableSeventeen);

		/*
		 * Query 8 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de ventas de las compa��as.
		 */

		Object[] eighteen = adminService.sellsPerCompanies();
		Double avgEighteen = (Double) eighteen[0];
		Integer maxEighteen = (Integer) eighteen[1];
		Integer minEighteen = (Integer) eighteen[2];
		Double stddevEighteen = (Double) eighteen[3];
		Object[] tableEighteen = {
			18
		};
		result.addObject("avgEighteen", avgEighteen);
		result.addObject("maxEighteen", maxEighteen);
		result.addObject("minEighteen", minEighteen);
		result.addObject("stddevEighteen", stddevEighteen);
		result.addObject("tableEighteen", tableEighteen);

		/*
		 * Query 9 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de Anuncios por Sponsor.
		 */

		Object[] nineteen = adminService.announcementsPerSponsor();
		Double avgNineteen = (Double) nineteen[0];
		Integer maxNineteen = (Integer) nineteen[1];
		Integer minNineteen = (Integer) nineteen[2];
		Double stddevNineteen = (Double) nineteen[3];
		Object[] tableNineteen = {
			19
		};
		result.addObject("avgNineteen", avgNineteen);
		result.addObject("maxNineteen", maxNineteen);
		result.addObject("minNineteen", minNineteen);
		result.addObject("stddevNineteen", stddevNineteen);
		result.addObject("tableNineteen", tableNineteen);

		/*
		 * Query 10 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de items comprados por Usuario.
		 */

		Object[] twenty = adminService.itemsPerUser();
		Double avgTwenty = (Double) twenty[0];
		Integer maxTwenty = (Integer) twenty[1];
		Integer minTwenty = (Integer) twenty[2];
		Double stddevTwenty = (Double) twenty[3];
		Object[] tableTwenty = {
			20
		};
		result.addObject("avgTwenty", avgTwenty);
		result.addObject("maxTwenty", maxTwenty);
		result.addObject("minTwenty", minTwenty);
		result.addObject("stddevTwenty", stddevTwenty);
		result.addObject("tableTwenty", tableTwenty);

		/*
		 * Query 11 - C
		 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de items comprados por Sponsor.
		 */

		Object[] twentyOne = adminService.itemsPerSponsor();
		Double avgTwentyOne = (Double) twentyOne[0];
		Integer maxTwentyOne = (Integer) twentyOne[1];
		Integer minTwentyOne = (Integer) twentyOne[2];
		Double stddevTwentyOne = (Double) twentyOne[3];
		Object[] tableTwentyOne = {
			21
		};
		result.addObject("avgTwentyOne", avgTwentyOne);
		result.addObject("maxTwentyOne", maxTwentyOne);
		result.addObject("minTwentyOne", minTwentyOne);
		result.addObject("stddevTwentyOne", stddevTwentyOne);
		result.addObject("tableTwentyOne", tableTwentyOne);

		return result;
	}

}
