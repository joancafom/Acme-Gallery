package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Admin;
import domain.Announcement;
import domain.CreditCard;
import domain.Sponsor;
import forms.AnnouncementForm;
import services.AnnouncementService;
import services.SponsorService;

@Controller
@RequestMapping("/announcement")
public class AnnouncementController extends AbstractController {

	@Autowired
	private AnnouncementService announcementService;
	
	@Autowired
	private SponsorService sponsorService;
	


	// Constructors -----------------------------------------------------------
	public AnnouncementController() {
		super();
	}
	
	
	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/sponsor/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Sponsor a = sponsorService.findByPrincipal();
		
		Collection<Announcement> announcements = new ArrayList<Announcement>();
		announcements =a.getAnnouncements();

		result = new ModelAndView("announcement/my/list");
		result.addObject("announcements", announcements);
		result.addObject("requestURI", "announcement/sponsor/list.do");

		return result;
	}
	
	
	
	// New advertisement --------------------------------------
	@RequestMapping(value = "/sponsor/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;

		
		AnnouncementForm announcementForm = new AnnouncementForm();
		Announcement res = announcementService.create();
		announcementForm.setId(res.getId());
		result = new ModelAndView("announcement/edit");
		result.addObject("requestURI", "announcement/sponsor/create.do");
		result.addObject("announcementForm", announcementForm);

		return result;
	}	
	
	//Save create-----------------------------------------------
	@RequestMapping(value = "/sponsor/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid AnnouncementForm announcementForm, BindingResult binding) {
		ModelAndView result;
		
		DateTime d = new DateTime(System.currentTimeMillis());
		Integer n = d.getYear();
		Integer y = Integer.parseInt(n.toString().substring(2));
		Integer m = d.getMonthOfYear();
		
		int year= 0;
		int month = 0;
		
		if (binding.hasErrors()) {
			result = createEditModelAndView(announcementForm);
		} else {
			try {
				year = Integer.parseInt(announcementForm.getExpirationYear());
				month = Integer.parseInt(announcementForm.getExpirationMonth());
				
				CreditCard creditCard = new CreditCard();
				creditCard.setBrandName(announcementForm.getBrandName());
				creditCard.setCvvCode(announcementForm.getCvvCode());
				creditCard.setExpirationMonth(announcementForm.getExpirationMonth());
				creditCard.setExpirationYear(announcementForm.getExpirationYear());
				creditCard.setHolderName(announcementForm.getHolderName());
				creditCard.setNumber(announcementForm.getNumber());

				
				Assert.isTrue(!(y > year));
				if (y == year && month <= m) {
					Assert.isTrue(false);
				}

				Announcement res = new Announcement();

				res.setLink(announcementForm.getLink());
				res.setBanner(announcementForm.getBanner());
				res.setCreditCard(creditCard);

				res = announcementService.save(res);
				
				

				result = new ModelAndView("redirect:/announcement/sponsor/list.do");
			} catch (Throwable oops) {
				if ((y == year && month <= m) | (year < y)) {
					result = createEditModelAndView(announcementForm, "advertisement.commit.creditCard");

				} else {
					result = createEditModelAndView(announcementForm, "advertisement.commit.error");
				}
			}
		}
		return result;
	}	
	
	
	@RequestMapping(value = "/sponsor/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam int announcementId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Announcement res;
		res = announcementService.findOne(announcementId);
		Sponsor a = sponsorService.findByPrincipal();
		
		Sponsor creador = announcementService.sponsorPerAnnouncement(announcementId);

		try {
			Assert.isTrue(a.equals(creador));
			Assert.notNull(a);
			announcementService.delete(res);
			result = new ModelAndView("redirect:/announcement/sponsor/list.do");

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/announcement/sponsor/list.do");
			redirectAttrs.addFlashAttribute("message", "advertisement.commit.error");
		}
		return result;
	}
	
	
	
	
	

	
	


		
		
		
	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(AnnouncementForm announcementForm) {
		ModelAndView result;
		result = createEditModelAndView(announcementForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(AnnouncementForm announcementForm, String message) {
		ModelAndView result;
		
		result = new ModelAndView("announcement/edit");
		result.addObject("announcementForm", announcementForm);
		result.addObject("message", message);


		return result;
	}
}
