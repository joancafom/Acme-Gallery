package controllers;

import java.text.Normalizer;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Basket;
import domain.CreditCard;
import domain.Sponsor;
import domain.User;
import forms.PayBasketForm;
import services.BasketService;
import services.SponsorService;
import services.UserService;

@Controller
@RequestMapping("/basket")
public class BasketController extends AbstractController {

	@Autowired
	private BasketService basketService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SponsorService sponsorService;
	
	public BasketController() {
		super();
	}
	
	@RequestMapping(value = "/user/display", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Basket basket;
		
		basket = this.basketService.findByPrincipal();
		
		result = new ModelAndView("basket/display");
		result.addObject("requestURI", "basket/user");
		result.addObject("basket", basket);

		return result;
	}
	
	@RequestMapping(value = "/sponsor/display", method = RequestMethod.GET)
	public ModelAndView listSponsor() {
		ModelAndView result;
		Basket basket;
		
		basket = this.basketService.findByPrincipal();
		
		result = new ModelAndView("basket/display");
		result.addObject("requestURI", "basket/sponsor");
		result.addObject("basket", basket);

		return result;
	}
	
	@RequestMapping(value = "/user/add", method = RequestMethod.GET)
	public ModelAndView add(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.basketService.addProduct(itemId);
			
			result = this.list();
			
//			result = new ModelAndView("redirect:/basket/user/display.do");
//			result.addObject("requestURI", "basket/user");
//			result.addObject("basket", basket);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/basket/user/display.do");
			
			if (oops.getLocalizedMessage().equals("Este item no esta disponible")) {
				message = "item.available";
			} else {
				message = "item.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/sponsor/add", method = RequestMethod.GET)
	public ModelAndView addSponsor(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.basketService.addProduct(itemId);
			
			result = this.listSponsor();
			
//			result = new ModelAndView("redirect:/basket/sponsor/display.do");
//			result.addObject("requestURI", "basket/sponsor");
//			result.addObject("basket", basket);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/basket/sponsor/display.do");
			
			if (oops.getLocalizedMessage().equals("Este item no esta disponible")) {
				message = "item.available";
			} else {
				message = "item.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		
		return result;
	}
	
	@RequestMapping(value = "/user/remove", method = RequestMethod.GET)
	public ModelAndView remove(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.basketService.deleteProduct(itemId);
			
			result = this.list();
			
//			result = new ModelAndView("redirect:/basket/user/display.do");
//			result.addObject("requestURI", "basket/user");
//			result.addObject("basket", basket);
		}catch (Throwable oops ) {
			String message;
			result = new ModelAndView("redirect:/basket/user/display.do");
			
			if (oops.getLocalizedMessage().equals("La cesta no contiene el item")) {
				message = "item.available";
			} else {
				message = "item.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/sponsor/remove", method = RequestMethod.GET)
	public ModelAndView removeSponsor(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.basketService.deleteProduct(itemId);
			
			result = this.listSponsor();
			
//			result = new ModelAndView("redirect:/basket/sponsor/display.do");
//			result.addObject("requestURI", "basket/sponsor");
//			result.addObject("basket", basket);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/basket/sponsor/display.do");
			
			if (oops.getLocalizedMessage().equals("La cesta no contiene el item")) {
				message = "item.available";
			} else {
				message = "item.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		
		return result;
	}
	
	@RequestMapping(value = "/user/pay", method = RequestMethod.GET)
	public ModelAndView pay(@CookieValue(value = "creditCard", required = false, defaultValue = "") String creditCard, RedirectAttributes redirAttrs) throws Throwable {
		ModelAndView result;
		Basket basket;
		String[] creditCardValues;
		PayBasketForm payBasketForm;
		
		try {
			basket = this.basketService.findByPrincipal();
			Assert.isTrue(!basket.getItems().isEmpty(), "Cesta vacia");
			
			payBasketForm = new PayBasketForm();
			if(!creditCard.equals("")) {
				creditCardValues = this.decodeCreditCard(creditCard);
				
				payBasketForm.setHolderName(creditCardValues[0]);
				payBasketForm.setBrandName(creditCardValues[1]);
				payBasketForm.setNumber(creditCardValues[2]);
				payBasketForm.setExpirationMonth(creditCardValues[3]);
				payBasketForm.setExpirationYear(creditCardValues[4]);
				payBasketForm.setCvvCode(creditCardValues[5]);
			}
			
			result = new ModelAndView("basket/pay");
			result.addObject("payBasketForm", payBasketForm);
			result.addObject("total", basket.getTotal());
			result.addObject("requestURI", "basket/user");
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/basket/user/display.do");
			
			if (oops.getLocalizedMessage().equals("Cesta vacia")) {
				message = "basket.empty";
			} else {
				message = "basket.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/user/pay", method = RequestMethod.POST)
	public ModelAndView paySave(@Valid PayBasketForm payBasketForm, BindingResult binding, RedirectAttributes redirectAttrs, HttpServletResponse response) {
		ModelAndView result;
		Basket basket = this.basketService.findByPrincipal();
		CreditCard creditCard;
		User user;
		Cookie cookie;
		String cookieValue;
		byte[] encode;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("basket/pay");
			result.addObject("payBasketForm", payBasketForm);
			result.addObject("total", basket.getTotal());
			result.addObject("requestURI", "basket/user");
		} else {
			try {
				Assert.isTrue(!basket.getItems().isEmpty(), "Cesta vacia");
				
				cookieValue = payBasketForm.getHolderName() + "," + payBasketForm.getBrandName() +"," + payBasketForm.getNumber() + "," + payBasketForm.getExpirationMonth()
				+ "," + payBasketForm.getExpirationYear() + "," + payBasketForm.getCvvCode();
				
				cookieValue = Normalizer.normalize(cookieValue, Normalizer.Form.NFD);
				cookieValue = new String(cookieValue.getBytes(), "UTF-8");
				cookieValue = cookieValue.replaceAll("\\?", "");
				encode = Base64.encode(cookieValue.getBytes("UTF-8"));
				
				cookieValue = new String(encode);
				cookie = new Cookie("creditCard", cookieValue);
				response.addCookie(cookie);
				
				creditCard = new CreditCard();
				creditCard.setBrandName(payBasketForm.getBrandName());
				creditCard.setCvvCode(payBasketForm.getCvvCode());
				creditCard.setExpirationMonth(payBasketForm.getExpirationMonth());
				creditCard.setExpirationYear(payBasketForm.getExpirationYear());
				creditCard.setHolderName(payBasketForm.getHolderName());
				creditCard.setNumber(payBasketForm.getNumber());
				this.basketService.isValidCreditCard(creditCard);
				
				user = this.userService.findByPrincipal();
				user.getBuyStore().getItems().addAll(basket.getItems());
				
				this.basketService.pay(creditCard, payBasketForm.getDirection());
				
				result = new ModelAndView("redirect:/basket/user/display.do");
			} catch (Throwable oops) {
				String message;
				result = new ModelAndView("redirect:/basket/user/display.do");
				
				if (oops.getLocalizedMessage().equals("La tarjeta ha caducado")) {
					message = "creditCard.error";
				} else if (oops.getLocalizedMessage().equals("La cesta est� vac�a") || oops.getLocalizedMessage().equals("Cesta vacia")) {
					message = "basket.empty";
				} else {
					message = "basket.error";
				}
				redirectAttrs.addFlashAttribute("message", message);
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/sponsor/pay", method = RequestMethod.GET)
	public ModelAndView paySponsor(@CookieValue(value = "creditCard", required = false, defaultValue = "") String creditCard, RedirectAttributes redirAttrs) throws Throwable {
		ModelAndView result;
		Basket basket;
		String[] creditCardValues;
		PayBasketForm payBasketForm;
		
		try {
			basket = this.basketService.findByPrincipal();
			Assert.isTrue(!basket.getItems().isEmpty(), "Cesta vacia");
			
			payBasketForm = new PayBasketForm();
			if(!creditCard.equals("")) {
				creditCardValues = this.decodeCreditCard(creditCard);
				
				payBasketForm.setHolderName(creditCardValues[0]);
				payBasketForm.setBrandName(creditCardValues[1]);
				payBasketForm.setNumber(creditCardValues[2]);
				payBasketForm.setExpirationMonth(creditCardValues[3]);
				payBasketForm.setExpirationYear(creditCardValues[4]);
				payBasketForm.setCvvCode(creditCardValues[5]);
			}
			
			result = new ModelAndView("basket/pay");
			result.addObject("payBasketForm", new PayBasketForm());
			result.addObject("total", basket.getTotal());
			result.addObject("requestURI", "basket/sponsor");
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/basket/user/display.do");
			
			if (oops.getLocalizedMessage().equals("Cesta vacia")) {
				message = "basket.empty";
			} else {
				message = "basket.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/sponsor/pay", method = RequestMethod.POST)
	public ModelAndView paySaveSponsor(@Valid PayBasketForm payBasketForm, BindingResult binding, RedirectAttributes redirectAttrs, HttpServletResponse response) {
		ModelAndView result;
		Basket basket = this.basketService.findByPrincipal();
		CreditCard creditCard;
		Sponsor sponsor;
		Cookie cookie;
		String cookieValue;
		byte[] encode;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("basket/pay");
			result.addObject("payBasketForm", payBasketForm);
			result.addObject("total", basket.getTotal());
			result.addObject("requestURI", "basket/sponsor");
		} else {
			try {
				cookieValue = payBasketForm.getHolderName() + "," + payBasketForm.getBrandName() +"," + payBasketForm.getNumber() + "," + payBasketForm.getExpirationMonth()
				+ "," + payBasketForm.getExpirationYear() + "," + payBasketForm.getCvvCode();
				
				cookieValue = Normalizer.normalize(cookieValue, Normalizer.Form.NFD);
				cookieValue = new String(cookieValue.getBytes(), "UTF-8");
				cookieValue = cookieValue.replaceAll("\\?", "");
				encode = Base64.encode(cookieValue.getBytes("UTF-8"));
				
				cookieValue = new String(encode);
				cookie = new Cookie("creditCard", cookieValue);
				response.addCookie(cookie);
				
				creditCard = new CreditCard();
				creditCard.setBrandName(payBasketForm.getBrandName());
				creditCard.setCvvCode(payBasketForm.getCvvCode());
				creditCard.setExpirationMonth(payBasketForm.getExpirationMonth());
				creditCard.setExpirationYear(payBasketForm.getExpirationYear());
				creditCard.setHolderName(payBasketForm.getHolderName());
				creditCard.setNumber(payBasketForm.getNumber());
				this.basketService.isValidCreditCard(creditCard);
				
				sponsor = this.sponsorService.findByPrincipal();
				sponsor.getBuyStore().getItems().addAll(basket.getItems());
				
				this.basketService.pay(creditCard, payBasketForm.getDirection());
				
				result = new ModelAndView("redirect:/basket/sponsor/display.do");
			} catch (Throwable oops) {
				String message;
				result = new ModelAndView("redirect:/basket/sponsor/display.do");
				
				if (oops.getLocalizedMessage().equals("La tarjeta ha caducado")) {
					message = "creditCard.error";
				} else if (oops.getLocalizedMessage().equals("La cesta est� vac�a") || oops.getLocalizedMessage().equals("Cesta vacia")) {
					message = "basket.empty";
				} else {
					message = "basket.error";
				}
				redirectAttrs.addFlashAttribute("message", message);
			}
		}
		return result;
	}
	
	protected String[] decodeCreditCard(String creditCard) {
		Assert.notNull(creditCard, "Tarjeta de credito nula");
		String[] result;
		String decode;
		
		try {
			decode = new String(Base64.decode(creditCard.getBytes("UTF-8"))).toString();
			result = decode.split(",");
		} catch(Throwable oops) {
			result = new String[100];
		}
		return result;
	}
}
