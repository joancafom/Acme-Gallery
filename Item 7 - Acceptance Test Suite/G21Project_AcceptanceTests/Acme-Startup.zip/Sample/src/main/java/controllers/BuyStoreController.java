package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Item;
import domain.Sponsor;
import domain.User;
import services.SponsorService;
import services.UserService;

@Controller
@RequestMapping("/buyStore")
public class BuyStoreController extends AbstractController {

	// Services ---------------------------------------------------------------

	@Autowired
	private UserService userService;

	@Autowired
	private SponsorService sponsorService;

	// Constructors -----------------------------------------------------------
	public BuyStoreController() {
		super();
	}

	// Listing user ----------------------------------------------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView result;

		Collection<Item> items;

		User principal = userService.findByPrincipal();
		items = principal.getBuyStore().getItems();

		result = new ModelAndView("buyStore/user/list");
		result.addObject("items", items);
		result.addObject("requestURI", "buyStore/user/list.do");

		return result;

	}

	// Listing sponsor
	// --------------------------------------------------------------
	@RequestMapping(value = "/sponsor/list", method = RequestMethod.GET)
	public ModelAndView listSponsor() {

		ModelAndView result;

		Collection<Item> items;

		Sponsor principal = sponsorService.findByPrincipal();
		items = principal.getBuyStore().getItems();

		result = new ModelAndView("buyStore/sponsor/list");
		result.addObject("items", items);
		result.addObject("requestURI", "buyStore/sponsor/list.do");

		return result;

	}

}
