package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Category;
import forms.CategoryForm;
import services.CategoryService;

@Controller
@RequestMapping("/admin/category")
public class CategoryController extends AbstractController{
	
	// Services ---------------------------------------------------------------
	@Autowired
	private CategoryService categoryService;
	
	// Constructors -----------------------------------------------------------
	public CategoryController() {
		super();
	}
	
	
	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Category> categories;

		categories = categoryService.findAll();
		result = new ModelAndView("admin/category/list");
		result.addObject("category", categories);
		result.addObject("requestURI", "admin/category/list.do");

		return result;
	}
	
	
	// New Category --------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Collection<Category> categories;
		CategoryForm categoryForm = new CategoryForm();
		Category res = categoryService.create();
		categoryForm.setId(res.getId());
		categoryForm.setFatherId(res.getFather().getId());
		categories = categoryService.findAll();
		result = new ModelAndView("admin/category/create");
		result.addObject("categoryForm", categoryForm);
		result.addObject("categories", categories);

		return result;
	}	
	
	
	//Save create-----------------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid CategoryForm categoryForm, BindingResult binding) {
		ModelAndView result;
		Collection<Category> cats = new ArrayList<Category>();
		cats = categoryService.findAll();
		boolean aux1= false;
		if (binding.hasErrors()) {
			result = createEditModelAndView(categoryForm);
		} else {
			try {
				for(Category cat:cats){
					if(cat.getName().equals(categoryForm.getName())){
						if(cat.getFather().getId()==categoryForm.getFatherId()){
							aux1=true;
							Assert.notNull(null);
						}
					}
				}
				
				Category res = new Category();
				res.setName(categoryForm.getName());
				res.setFather(categoryService.findOne(categoryForm.getFatherId()));

				res = categoryService.save(res);
				
				Category padre = res.getFather();
				Collection<Category> aux = new ArrayList<Category>();
				aux=padre.getSons();
				aux.add(res);
				padre.setSons(aux);
				categoryService.save(padre);

				result = new ModelAndView("redirect:/admin/category/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(categoryForm, "category.commit.error");
				if(aux1==true){
					result = createEditModelAndView(categoryForm, "category.commit.errorExits");

				}
			}
		}
		return result;
	}	
	
	
	// Modify------------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("categoryId") int categoryId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		CategoryForm categoryForm = new CategoryForm();

		try {
			Assert.isTrue(categoryId != categoryService.getCategoryPrincipal().getId());
			Collection<Category> categories;
			result = new ModelAndView("admin/category/edit");

			categories = categoryService.findAll();
			Category category = categoryService.findOne(categoryId);

			categoryForm.setId(category.getId());
			categoryForm.setName(category.getName());

			categoryForm.setFatherId(category.getFather().getId());
			
			//Se quitan los hijos de la categoria a modificar 
			//para que no se puedan poner sus hijos como padre
			categories.removeAll(category.getSons());

			result.addObject("categoryForm", categoryForm);
			result.addObject("categories", categories);
			result.addObject("requestURI", "admin/category/edit.do?categoryId=" + categoryId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/admin/category/list.do");
			if (categoryService.getCategoryPrincipal().getId() == categoryId) {
				redirectAttrs.addFlashAttribute("message", "category.commit.accessError");
			} else {
				redirectAttrs.addFlashAttribute("message", "category.commit.noExist");
			}

		}

		return result;
	}	
	
	
	//Save edit---------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid CategoryForm categoryForm, BindingResult binding) {
		ModelAndView result;
		Collection<Category> cats = new ArrayList<Category>();
		cats = categoryService.findAll();
		boolean aux1= false;

		if (binding.hasErrors()) {
			result = createEditModelAndView(categoryForm);

		} else {
			try {
				for(Category cat:cats){
					if(cat.getName().equals(categoryForm.getName())){
						if(cat.getFather().getId()==categoryForm.getFatherId()){
							aux1=true;
							Assert.notNull(null);
						}
					}
				}
				
				/*
				 * res : Categor�a a modificar
				 * nueva : nueva categor�a padre de res
				 * vieja : vieja categor�a padre de res
				 */
				Category res = categoryService.findOne(categoryForm.getId());
				Category nueva = categoryService.findOne(categoryForm.getFatherId());
				Category vieja = (categoryService.findOne(categoryForm.getId())).getFather();
				res.setName(categoryForm.getName());
				res.setFather(nueva);

				vieja.getSons().remove(res);
				categoryService.save(vieja);

				nueva.getSons().add(res);
				res.setFather(nueva);
				categoryService.save(nueva);
				categoryService.save(res);

				result = new ModelAndView("redirect:/admin/category/list.do");
			} catch (Throwable oops) {
				if(aux1==true){
					result = createEditModelAndView(categoryForm, "category.commit.errorExits");
				}else{
					result = createEditModelAndView(categoryForm, "category.commit.error");

				}
			}
		}
		return result;
	}	
	
	
	
	// Delete----------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid CategoryForm categoryForm, BindingResult binding) {
		ModelAndView result;
		Category res;
		res = categoryService.findOne(categoryForm.getId());

		if (binding.hasErrors()) {
			result = createEditModelAndView(categoryForm);
		} else {
			try {
				
				categoryService.delete(res);
				result = new ModelAndView("redirect:/admin/category/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(categoryForm, "category.commit.error");
			}
		}
		return result;
	}
	
	
	
	// Ancillary methods -----------------------------
	protected ModelAndView createEditModelAndView(CategoryForm categoryForm) {
		ModelAndView result;
		result = createEditModelAndView(categoryForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(CategoryForm categoryForm, String message) {
		ModelAndView result;
		Collection<Category> categories;
		categories = categoryService.findAll();
		if (categoryForm.getId()==0){
			result = new ModelAndView("admin/category/create");

		}else{
			result = new ModelAndView("admin/category/edit");
			Category category = categoryService.findOne(categoryForm.getId());
			categories.removeAll(category.getSons());

		}		
		result.addObject("categories", categories);
		result.addObject("categoryForm", categoryForm);
		result.addObject("message", message);

		return result;
	}
}
