package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import services.CommentService;

@Controller
@RequestMapping("/comment/admin")
public class CommentAdminController extends AbstractController {

	@Autowired
	private CommentService commentService;
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int commentId, @RequestParam final int previousComment, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:/comment/display.do?commentId=" + previousComment);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/comment/display.do?commentId=" + previousComment);
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/deleteNew", method = RequestMethod.GET)
	public ModelAndView deleteNew(@RequestParam final int commentId, @RequestParam final int newId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:/news/display.do?newId=" + newId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/news/display.do?newId=" + newId);
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/deleteItem", method = RequestMethod.GET)
	public ModelAndView deleteItem(@RequestParam final int commentId, @RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		
		try {
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:/item/display.do?itemId=" + itemId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/item/display.do?itemId=" + itemId);
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
}
