package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Comment;
import services.CommentService;
import services.NewsService;

@Controller
@RequestMapping("/comment")
public class CommentController extends AbstractController {

	@Autowired
	private CommentService commentService;
	
	@Autowired
	private NewsService newsService;
	
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int commentId) {
		ModelAndView result;
		Comment comment;
		
		comment = this.commentService.findOne(commentId);
		
		result = new ModelAndView("comment/display");
		result.addObject("comment", comment);
		result.addObject("canDo", this.newsService.newsPerCommentInt(commentId) == 0);
		
		return result;
	}
}
