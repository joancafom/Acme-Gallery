package controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Comment;
import domain.User;
import forms.CommentForm;
import services.CommentService;
import services.NewsService;
import services.UserService;

@Controller
@RequestMapping("/comment/user")
public class CommentUserController extends AbstractController {

	@Autowired
	private CommentService commentService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int commentId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		CommentForm comment;
		
		try {
			Assert.isTrue(this.newsService.newsPerCommentInt(commentId) == 0, "No puedes realizar esta accion");
			
			comment = new CommentForm();
			
			result = new ModelAndView("comment/edit");
			result.addObject("comment", comment);
			result.addObject("requestURI", "comment/user/create.do?commentId=" + commentId);
			result.addObject("baseURI", "comment/display.do?commentId=" + commentId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/comment/display.do?commentId=" + commentId);
			
			if (oops.getLocalizedMessage().equals("No puedes realizar esta accion")) {
				message = "comment.action";
			} else {
				message = "comment.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		
		
		
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ModelAndView saveComment(@RequestParam final int commentId, @Valid final CommentForm commentForm, BindingResult binding, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Comment comment;
		Date creationDate;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("comment/edit");
			result.addObject("comment", commentForm);
			result.addObject("requestURI", "comment/user/create.do?commentId=" + commentId);
			result.addObject("baseURI", "comment/display.do?commentId=" + commentId);
			result.addObject("message", "comment.body.empty");
		} else {
			try {
				Assert.isTrue(this.newsService.newsPerCommentInt(commentId) == 0, "No puedes realizar esta accion");
				
				creationDate = new Date(System.currentTimeMillis());
				
				comment = this.commentService.create();
				comment.setBody(commentForm.getBody());
				comment.setCreationDate(creationDate);
				
				this.commentService.saveComment(comment, commentId);
				
				result = new ModelAndView("redirect:/comment/display.do?commentId=" + commentId);
			} catch (Throwable oops) {
				String message;
				result = new ModelAndView("redirect:/comment/display.do?commentId=" + commentId);
				
				if (oops.getLocalizedMessage().equals("No puedes realizar esta accion")) {
					message = "comment.action";
				} else {
					message = "comment.error";
				}
				redirAttrs.addFlashAttribute("message", message);
			}
			
		}
		
		return result;
	}
	
	@RequestMapping(value = "/createNew", method = RequestMethod.GET)
	public ModelAndView createNew(@RequestParam final int newId) {
		ModelAndView result;
		CommentForm comment;
		
		comment = new CommentForm();
		
		result = new ModelAndView("comment/edit");
		result.addObject("comment", comment);
		result.addObject("requestURI", "comment/user/createNew.do?newId=" + newId);
		result.addObject("baseURI", "news/display.do?newId=" + newId);
		
		return result;
	}
	
	@RequestMapping(value = "/createNew", method = RequestMethod.POST)
	public ModelAndView saveNews(@RequestParam final int newId, @Valid final CommentForm commentForm, BindingResult binding) {
		ModelAndView result;
		Comment comment;
		Date date;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("comment/edit");
			result.addObject("comment", commentForm);
			result.addObject("requestURI", "comment/user/createNew.do?newId=" + newId);
			result.addObject("baseURI", "news/display.do?newId=" + newId);
			result.addObject("message", "comment.body.empty");
		} else {
			date = new Date(System.currentTimeMillis());
			
			comment = this.commentService.create();
			comment.setBody(commentForm.getBody());
			comment.setCreationDate(date);
			
			this.commentService.saveCommentNew(comment, newId);
			
			result = new ModelAndView("redirect:/news/display.do?newId=" + newId);
		}
		
		return result;
	}

	@RequestMapping(value = "/createItem", method = RequestMethod.GET)
	public ModelAndView createItem(@RequestParam final int itemId) {
		ModelAndView result;
		CommentForm comment;
		
		comment = new CommentForm();
		
		result = new ModelAndView("comment/edit");
		result.addObject("comment", comment);
		result.addObject("requestURI", "comment/user/createItem.do?itemId=" + itemId);
		result.addObject("baseURI", "item/display.do?itemId=" + itemId);
		
		return result;
	}
	
	@RequestMapping(value = "/createItem", method = RequestMethod.POST)
	public ModelAndView createItem(@RequestParam final int itemId, @Valid final CommentForm commentForm, BindingResult binding) {
		ModelAndView result;
		Comment comment;
		Date date;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("comment/edit");
			result.addObject("comment", commentForm);
			result.addObject("requestURI", "comment/user/createItem.do?itemId=" + itemId);
			result.addObject("baseURI", "item/display.do?itemId=" + itemId);
			result.addObject("message", "comment.body.empty");
		} else {
			try {
				date = new Date(System.currentTimeMillis());
				
				comment = this.commentService.create();
				comment.setBody(commentForm.getBody());
				comment.setCreationDate(date);
				
				this.commentService.saveCommentItem(comment, itemId);
				
				result = new ModelAndView("redirect:/item/display.do?itemId=" + itemId);
			} catch (Throwable oops) {
				result = this.createEditModelAndView(commentForm, "comment.error");
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int commentId, RedirectAttributes redirectAttrs, HttpServletRequest request) {
		ModelAndView result;
		CommentForm commentForm;
		User user;
		Comment comment = this.commentService.findOne(commentId);
		
		try {
			
			user = this.userService.findByPrincipal();
			Assert.isTrue(user.getComments().contains(comment), "No puedes realizar esta accion");
			
			commentForm = new CommentForm();
			commentForm.setBody(comment.getBody());
			
			result = new ModelAndView("comment/edit");
			result.addObject("comment", commentForm);
			result.addObject("requestURI", "comment/user/edit.do?commentId=" + commentId);
			result.addObject("baseURI", "comment/display.do?commentId=" + commentId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:" + request.getHeader("Referer"));
			
			if (oops.getLocalizedMessage().equals("No puedes realizar esta accion")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		
		
		
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView editComment(@RequestParam final int commentId, @Valid final CommentForm commentForm, BindingResult binding, RedirectAttributes redirAttrs, HttpServletRequest request) {
		ModelAndView result;
		Comment comment = this.commentService.findOne(commentId);
		Date creationDate;
		User user;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("comment/edit");
			result.addObject("comment", commentForm);
			result.addObject("requestURI", "comment/user/create.do?commentId=" + commentId);
			result.addObject("baseURI", "comment/display.do?commentId=" + commentId);
			result.addObject("message", "comment.body.empty");
		} else {
			try {
				
				user = this.userService.findByPrincipal();
				Assert.isTrue(user.getComments().contains(comment), "No puedes realizar esta accion");
				
				creationDate = new Date(System.currentTimeMillis());
				
				comment.setBody(commentForm.getBody());
				comment.setCreationDate(creationDate);
				
				this.commentService.save(comment);
				
				result = new ModelAndView("redirect:/comment/display.do?commentId=" + commentId);
			} catch (Throwable oops) {
				String message;
				result = new ModelAndView("redirect:" + request.getHeader("Referer"));
				
				if (oops.getLocalizedMessage().equals("No puedes realizar esta accion")) {
					message = "comment.user.error";
				} else {
					message = "comment.error";
				}
				redirAttrs.addFlashAttribute("message", message);
			}
			
		}
		
		return result;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int commentId, RedirectAttributes redirAttrs, HttpServletRequest request) {
		ModelAndView result;
		Comment comment = this.commentService.findOne(commentId);
		User user;
		
		try {
			user = this.userService.findByPrincipal();
			Assert.isTrue(user.getComments().contains(comment), "No eres el creador");
			
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:" + request.getHeader("Referer"));
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:" + request.getHeader("Referer"));
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/deleteNew", method = RequestMethod.GET)
	public ModelAndView deleteNew(@RequestParam final int commentId, @RequestParam final int newId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		User user;
		Comment comment = this.commentService.findOne(commentId);
		
		try {
			user = this.userService.findByPrincipal();
			Assert.isTrue(user.getComments().contains(comment), "No eres el creador");
			
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:/news/display.do?newId=" + newId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/news/display.do?newId=" + newId);
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/deleteItem", method = RequestMethod.GET)
	public ModelAndView deleteItem(@RequestParam final int commentId, @RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		User user;
		Comment comment = this.commentService.findOne(commentId);
		
		try {
			user = this.userService.findByPrincipal();
			Assert.isTrue(user.getComments().contains(comment), "No eres el creador");
			
			this.commentService.deleteComplete(commentId);
			
			result = new ModelAndView("redirect:/item/display.do?itemId=" + itemId);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/item/display.do?itemId=" + itemId);
			
			if (oops.getLocalizedMessage().equals("No eres el creador")) {
				message = "comment.user.error";
			} else {
				message = "comment.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	public ModelAndView createEditModelAndView(CommentForm comment) {
		ModelAndView result;
		
		result = this.createEditModelAndView(comment, null);
		
		return result;
	}
	
	public ModelAndView createEditModelAndView(CommentForm comment, String message) {
		ModelAndView result;
		
		result = new ModelAndView("comment/edit");
		result.addObject("comment", comment);
		result.addObject("message", message);
		result.addObject("requestURI", "comment/user");
		result.addObject("baseURI", "comment/user/create.do?commentId=" + comment);
		
		return result;
	}
}
