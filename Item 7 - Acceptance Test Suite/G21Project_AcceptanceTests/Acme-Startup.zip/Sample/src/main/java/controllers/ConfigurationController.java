
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Configuration;
import forms.ConfigurationForm;
import services.ConfigurationService;

@Controller
@RequestMapping("/configuration")
public class ConfigurationController extends AbstractController {

	@Autowired
	private ConfigurationService configurationService;


	// Constructors -----------------------------------------------------------
	public ConfigurationController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Configuration> confs;

		confs = configurationService.findAll();
		result = new ModelAndView("configuration/list");
		result.addObject("configurationForm", confs);
		result.addObject("requestURI", "configuration/list.do");

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("configurationId") int configurationId) {
		ModelAndView result;
		Configuration configuration;
		// Integer i = Integer.parseInt(survivalClassId);

		configuration = configurationService.findOne(configurationId);
		result = new ModelAndView("configuration/edit");
		result.addObject("configurationForm", configuration);
		result.addObject("requestURI", "configuration/edit.do?configurationId=" + configurationId);
		//result.addObject("URI", "configuration/list.do");

		return result;
	}



	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid ConfigurationForm configurationForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(configurationForm);

		} else {
			try {
				
				
				Configuration res = configurationService.findOne(configurationForm.getId());
				res.setBanner(configurationForm.getBanner());
				res.setCompany(configurationForm.getCompany());
				res.setWelcome(configurationForm.getWelcome());
				res.setBienvenida(configurationForm.getBienvenida());
				res.setCountryCode(configurationForm.getCountryCode());

				configurationService.save(res);
				result = new ModelAndView("redirect:/configuration/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(configurationForm, "configuration.commit.error");
			}
		}
		return result;

	}

	// Creation --------------------------------------
	//Creation --------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;

		Configuration c;
		c = configurationService.create();
		ConfigurationForm res = new ConfigurationForm();
		res.setId(c.getId());
		result = createEditModelAndView(res);
		result.addObject("configurationForm", res);

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid ConfigurationForm configurationForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Configuration c = new Configuration();

		if (binding.hasErrors()) {
			result = createEditModelAndView(configurationForm);
		} else {
			try {
				c.setBanner(configurationForm.getBanner());
				c.setCompany(configurationForm.getCompany());
				c.setWelcome(configurationForm.getWelcome());
				c.setBienvenida(configurationForm.getBienvenida());
				c.setCountryCode(configurationForm.getCountryCode());
				
				
				configurationService.save(c);
				result = new ModelAndView("redirect:/configuration/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(configurationForm, "configuration.commit.error");
			}
		}

		return result;
	}

	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(ConfigurationForm configurationForm) {
		ModelAndView result;
		result = createEditModelAndView(configurationForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(ConfigurationForm configurationForm, String message) {
		ModelAndView result;

		result = new ModelAndView("configuration/edit");
		result.addObject("configurationForm", configurationForm);
		result.addObject("message", message);

		return result;
	}

}
