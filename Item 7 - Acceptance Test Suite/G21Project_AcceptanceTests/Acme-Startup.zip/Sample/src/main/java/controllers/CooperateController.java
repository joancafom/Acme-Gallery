package controllers;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Cooperate;
import domain.Startup;
import services.StartupService;

@Controller
@RequestMapping("/cooperate")
public class CooperateController extends AbstractController{
	
	@Autowired
	private StartupService startupService;
	
	public CooperateController() {
		super();
	}
	
	
	
	//List ----------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam("startupId") int startupId) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(startupId);
		Collection<Cooperate> cooperates= new ArrayList<Cooperate>();

		cooperates = startup.getCooperates();

		result = new ModelAndView("cooperate/list");
		result.addObject("cooperates", cooperates);
			

		return result;
	}

}
