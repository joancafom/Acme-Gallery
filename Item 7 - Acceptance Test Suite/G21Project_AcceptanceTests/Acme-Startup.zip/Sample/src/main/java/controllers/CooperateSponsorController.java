package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Cooperate;
import domain.CreditCard;
import domain.Startup;
import forms.CooperateForm;
import forms.EditCooperateForm;
import services.CooperateService;
import services.StartupService;

@Controller
@RequestMapping("/cooperate/sponsor")
public class CooperateSponsorController extends AbstractController {

	@Autowired
	private CooperateService cooperateService;
	
	@Autowired
	private StartupService startupService;
	
	public CooperateSponsorController() {
		super();
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Cooperate> cooperates;
		
		cooperates = this.cooperateService.findCooperatesByPrincipal();
		
		result = new ModelAndView("cooperate/list");
		result.addObject("requestURI", "cooperate/sponsor");
		result.addObject("cooperates", cooperates);

		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		CooperateForm cooperateForm;
		Collection<Startup> startups;
		
		cooperateForm = new CooperateForm();
		
		startups = this.startupService.findAll();
		
		result = new ModelAndView("cooperate/create");
		result.addObject("requestURI", "cooperate/sponsor");
		result.addObject("cooperateForm", cooperateForm);
		result.addObject("startups", startups);

		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ModelAndView save(@Valid CooperateForm cooperateForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Cooperate cooperate;
		CreditCard creditCard;
		Startup startup;

		if (binding.hasErrors()) {
			Collection<Startup> startups = this.startupService.findAll();
			
			result = new ModelAndView("cooperate/create");
			result.addObject("requestURI", "cooperate/sponsor");
			result.addObject("startups", startups);
		} else {
			try {
				Assert.isTrue(cooperateForm.getStartupId() != 0, "Debe escoger una startup");
				
				creditCard = new CreditCard();
				creditCard.setBrandName(cooperateForm.getBrandName());
				creditCard.setCvvCode(cooperateForm.getCvvCode());
				creditCard.setExpirationMonth(cooperateForm.getExpirationMonth());
				creditCard.setExpirationYear(cooperateForm.getExpirationYear());
				creditCard.setHolderName(cooperateForm.getHolderName());
				creditCard.setNumber(cooperateForm.getNumber());
				this.cooperateService.isValidCreditCard(creditCard);
				
				startup = this.startupService.findOne(cooperateForm.getStartupId());
				
				cooperate = new Cooperate();
				cooperate.setBanner(cooperateForm.getBanner());
				cooperate.setCompany(cooperateForm.getCompany());
				cooperate.setCreditCard(creditCard);
				cooperate.setDescription(cooperateForm.getDescription());
				cooperate.setLink(cooperateForm.getLink());
				
				this.cooperateService.save(cooperate, startup);
				
				result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
			} catch (Throwable oops) {
				String message;
				Collection<Startup> startups = this.startupService.findAll();
				
				if (oops.getLocalizedMessage().equals("La tarjeta ha caducado")) {
					message = "creditCard.error";
				} else if (oops.getLocalizedMessage().equals("Debe escoger una startup")) {
					message = "cooperate.startup.error";
				} else {
					message = "cooperate.error";
				}
				result = new ModelAndView("cooperate/create");
				result.addObject("message", message);
				result.addObject("requestURI", "cooperate/sponsor");
				result.addObject("startups", startups);
			}
		}

		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int cooperateId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		EditCooperateForm editCooperateForm;
		Cooperate cooperate;
		
		try {
			cooperate = this.cooperateService.find(cooperateId);
			
			editCooperateForm = new EditCooperateForm();
			editCooperateForm.setId(cooperate.getId());
			editCooperateForm.setBanner(cooperate.getBanner());
			editCooperateForm.setBrandName(cooperate.getCreditCard().getBrandName());
			editCooperateForm.setCompany(cooperate.getCompany());
			editCooperateForm.setCvvCode(cooperate.getCreditCard().getCvvCode());
			editCooperateForm.setDescription(cooperate.getDescription());
			editCooperateForm.setExpirationMonth(cooperate.getCreditCard().getExpirationMonth());
			editCooperateForm.setExpirationYear(cooperate.getCreditCard().getExpirationYear());
			editCooperateForm.setHolderName(cooperate.getCreditCard().getHolderName());
			editCooperateForm.setLink(cooperate.getLink());
			editCooperateForm.setNumber(cooperate.getCreditCard().getNumber());
			
			result = new ModelAndView("cooperate/edit");
			result.addObject("requestURI", "cooperate/sponsor");
			result.addObject("editCooperateForm", editCooperateForm);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
			
			if (oops.getLocalizedMessage().equals("No puede acceder a esta cooperacion")) {
				message = "cooperate.access";
			} else {
				message = "cooperate.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		
		

		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView saveEdit(@Valid EditCooperateForm editCooperateForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Cooperate cooperate;
		CreditCard creditCard;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("cooperate/edit");
			result.addObject("requestURI", "cooperate/sponsor");
		} else {
			try {
				creditCard = new CreditCard();
				creditCard.setBrandName(editCooperateForm.getBrandName());
				creditCard.setCvvCode(editCooperateForm.getCvvCode());
				creditCard.setExpirationMonth(editCooperateForm.getExpirationMonth());
				creditCard.setExpirationYear(editCooperateForm.getExpirationYear());
				creditCard.setHolderName(editCooperateForm.getHolderName());
				creditCard.setNumber(editCooperateForm.getNumber());
				this.cooperateService.isValidCreditCard(creditCard);
				
				cooperate = this.cooperateService.findOne(editCooperateForm.getId());
				cooperate.setBanner(editCooperateForm.getBanner());
				cooperate.setCompany(editCooperateForm.getCompany());
				cooperate.setCreditCard(creditCard);
				cooperate.setDescription(editCooperateForm.getDescription());
				cooperate.setLink(editCooperateForm.getLink());
				this.cooperateService.checkCooperate(cooperate);
				
				this.cooperateService.save(cooperate);
				
				result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
			} catch (Throwable oops) {
				String message;
				
				if (oops.getLocalizedMessage().equals("La tarjeta ha caducado")) {
					message = "creditCard.error";
				} else if (oops.getLocalizedMessage().equals("No puede acceder a esta cooperacion")) {
					message = "cooperate.access";
					result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
					redirectAttrs.addFlashAttribute("message", message);
					return result;
				} else {
					message = "cooperate.error";
				}
				result = new ModelAndView("cooperate/edit");
				result.addObject("message", message);
				result.addObject("requestURI", "cooperate/sponsor");
			}
		}
		return result;
	}
	
	//TODO delete
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int cooperateId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		
		try {
			startup = this.startupService.startupPerCooperate(cooperateId);
			
			this.cooperateService.deleteCooperate(cooperateId, startup);
			
			result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/cooperate/sponsor/list.do");
			
			if (oops.getLocalizedMessage().equals("No puede acceder a esta cooperacion")) {
				message = "cooperate.access";
			} else {
				message = "cooperate.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
}
