package controllers;

import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Education;
import domain.InterestData;
import domain.PersonalData;
import domain.User;
import forms.EducationForm;
import services.EducationService;
import services.PersonalDataService;
import services.UserService;

@Controller
@RequestMapping("/education")
public class EducationController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private EducationService educationService;

	@Autowired
	private PersonalDataService personalDataService;

	@Autowired
	private UserService userService;

	// Constructors -----------------------------------------------------------
	public EducationController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int personalDataId) {

		ModelAndView result;
		Collection<Education> educations;

		educations = educationService.educationPerPersonalData(personalDataId);

		result = new ModelAndView("education/user/list");
		result.addObject("requestURI", "education/user/list.do");
		result.addObject("educations", educations);
		result.addObject("personalDataId", personalDataId);

		return result;
	}

	// Editing ----------------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int educationId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		EducationForm educationForm;
		User principal = userService.findByPrincipal();

		Education education;
		User userpd = educationService.userByEducationId(educationId);

		PersonalData pd = educationService.personalDataByEducationId(educationId);

		try {
			Assert.isTrue(principal.equals(userpd), "Usted no tiene acceso a datos acad�micos que no son suyos");
			education = educationService.findOne(educationId);

			educationForm = new EducationForm();
			educationForm.setEducationId(education.getId());
			educationForm.setDateStart(education.getDateStart());
			educationForm.setDateEnd(education.getDateEnd());
			educationForm.setAttachment(education.getAttachment());
			educationForm.setComments(education.getComments());
			educationForm.setTitle(education.getTitle());
			educationForm.setInstitution(education.getInstitution());
			educationForm.setPersonalDataId(pd.getId());

			result = new ModelAndView("education/user/edit");
			result.addObject("educationForm", educationForm);
			result.addObject("personalDataId", pd.getId());
			result.addObject("requestURI", "./education/user/edit.do?educationId=" + educationId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/education/user/list.do?personalDataId=" + pd.getId());
			if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos acad�micos que no son suyos")) {
				redirectAttrs.addFlashAttribute("message", "education.user.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "education.error");
			}
		}

		return result;
	}

	@RequestMapping(value = "/user/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid EducationForm educationForm, BindingResult binding,
			RedirectAttributes redirectAttrs) {

		ModelAndView result;
		Education education;

		User principal = userService.findByPrincipal();
		User userPd = educationService.userByEducationId(educationForm.getEducationId());
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = editModelAndView(educationForm);
		} else {
			try {
				Assert.notNull(educationForm);
				Assert.isTrue(principal.equals(userPd), "Usted no tiene acceso a datos acad�micos que no son suyos");
				
				if (educationForm.getDateEnd() != null) {
					Assert.isTrue(educationForm.getDateStart().before(educationForm.getDateEnd()),
							"La fecha de comienzo debe ser anterior a la fecha fin");
					Assert.isTrue(educationForm.getDateEnd().before(momento),
							"La fecha fin debe ser anterior a la fecha actual");
				}
				
				int personalDataId = educationService.personalDataByEducationId(educationForm.getEducationId()).getId();

				education = educationService.findOne(educationForm.getEducationId());
				education.setDateStart(educationForm.getDateStart());
				education.setDateEnd(educationForm.getDateEnd());
				education.setAttachment(educationForm.getAttachment());
				education.setComments(educationForm.getComments());
				education.setTitle(educationForm.getTitle());
				education.setInstitution(educationForm.getInstitution());
				educationService.save(education);

				result = new ModelAndView("redirect:/education/user/list.do?personalDataId=" + personalDataId);
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos acad�micos que no son suyos")) {
					result = editModelAndView(educationForm, "education.user.error");
				} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result= editModelAndView(educationForm, "education.date.error");
				} else if (oops.getLocalizedMessage().equals("La fecha fin debe ser anterior a la fecha actual")) {
					result= editModelAndView(educationForm, "education.dateactual.error");
				} else {
					result = editModelAndView(educationForm, "education.error");
				}
				result.addObject("personalDataId", educationForm.getPersonalDataId());
			}
		}
		return result;
	}

	// Creating
	// ----------------------------------------------------------------------

	@RequestMapping(value = "/user/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam int personalDataId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;

		EducationForm educationForm = new EducationForm();
		educationForm.setPersonalDataId(personalDataId);
		User userpd = personalDataService.userByPersonalDataId(personalDataId);
		User principal = userService.findByPrincipal();

		try {
			Assert.isTrue(principal.equals(userpd), "Usted no tiene acceso a datos acad�micos que no son suyos");
			result = new ModelAndView("education/user/create");
			result.addObject("educationForm", educationForm);
			result.addObject("requestURI", "./education/user/create.do");
			result.addObject("personalDataId", personalDataId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/personalData/user/list.do");
			if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos acad�micos que no son suyos")) {
				redirectAttrs.addFlashAttribute("message", "education.user.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "education.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/user/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid EducationForm educationForm, BindingResult binding,
			RedirectAttributes redirectAttrs) {
		ModelAndView result;

		educationForm.setPersonalDataId(educationForm.getPersonalDataId());
		User principal = userService.findByPrincipal();
		User userpd = personalDataService.userByPersonalDataId(educationForm.getPersonalDataId());
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = createModelAndView(educationForm);
		} else
			try {
				Assert.isTrue(principal.equals(userpd), "Usted no tiene acceso a datos acad�micos que no son suyos");
				Assert.notNull(educationForm);
				
				if (educationForm.getDateEnd() != null) {
					Assert.isTrue(educationForm.getDateStart().before(educationForm.getDateEnd()),
							"La fecha de comienzo debe ser anterior a la fecha fin");
					Assert.isTrue(educationForm.getDateEnd().before(momento),
							"La fecha fin debe ser anterior a la fecha actual");
				}
				
				int personalDataId = educationForm.getPersonalDataId();

				Education res = educationService.create();
				res.setDateStart(educationForm.getDateStart());
				res.setDateEnd(educationForm.getDateEnd());
				res.setAttachment(educationForm.getAttachment());
				res.setComments(educationForm.getComments());
				res.setTitle(educationForm.getTitle());
				res.setInstitution(educationForm.getInstitution());
				Education saved = educationService.save(res);

				PersonalData p = personalDataService.findOne(personalDataId);
				p.getInterestDatas().add(saved);
				personalDataService.save(p);

				result = new ModelAndView("redirect:/education/user/list.do?personalDataId=" + personalDataId);
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos acad�micos que no son suyos")) {
					result = createModelAndView(educationForm, "education.user.error");
				} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result= createModelAndView(educationForm, "education.date.error");
				} else if (oops.getLocalizedMessage().equals("La fecha fin debe ser anterior a la fecha actual")) {
					result= createModelAndView(educationForm, "education.dateactual.error");
				} else {
					result = createModelAndView(educationForm, "education.error");
				}
				result.addObject("personalDataId", educationForm.getPersonalDataId());
			}
		return result;
	}

	// Deleting
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(EducationForm educationForm, BindingResult binding) {
		ModelAndView result;

		try {
			Assert.notNull(educationService.findOne(educationForm.getEducationId()));
			Education res = educationService.findOne(educationForm.getEducationId());

			PersonalData p = educationService.personalDataByEducationId(educationForm.getEducationId());
			Collection<InterestData> educations = p.getInterestDatas();
			educations.remove(res);
			p.setInterestDatas(educations);
			personalDataService.save(p);

			educationService.delete(res);

			result = new ModelAndView("redirect:/education/user/list.do?personalDataId=" + p.getId());
		} catch (Throwable oops) {
			result = editModelAndView(educationForm, "education.error");
		}

		return result;
	}

	// Ancilliary methods
	// ----------------------------------------------------------------

	protected ModelAndView createModelAndView(EducationForm educationForm) {
		ModelAndView result;
		result = createModelAndView(educationForm, null);
		return result;
	}

	protected ModelAndView createModelAndView(EducationForm educationForm, String message) {
		ModelAndView result;

		result = new ModelAndView("education/user/create");
		result.addObject("educationForm", educationForm);
		result.addObject("personalDataId", educationForm.getPersonalDataId());
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView editModelAndView(EducationForm educationForm) {
		ModelAndView result;
		result = editModelAndView(educationForm, null);
		return result;
	}

	protected ModelAndView editModelAndView(EducationForm educationForm, String message) {
		ModelAndView result;

		result = new ModelAndView("education/user/edit");
		result.addObject("educationForm", educationForm);
		result.addObject("personalDataId", educationForm.getPersonalDataId());
		result.addObject("message", message);

		return result;
	}

}
