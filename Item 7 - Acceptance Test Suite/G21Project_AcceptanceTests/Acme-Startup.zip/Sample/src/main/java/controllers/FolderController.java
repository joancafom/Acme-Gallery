
package controllers;

import java.util.Collection;
import java.util.HashSet;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Actor;
import domain.Admin;
import domain.Company;
import domain.Folder;
import domain.Merchant;
import domain.Message;
import domain.Sponsor;
import domain.User;
import forms.FolderForm;
import forms.MessageForm;
import forms.MessageNotificationForm;
import services.ActorService;
import services.AdminService;
import services.CompanyService;
import services.FolderService;
import services.MerchantService;
import services.MessageService;
import services.SponsorService;
import services.UserService;

@Controller
@RequestMapping("/folder/actor")
public class FolderController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private ActorService actorService;

	@Autowired
	private AdminService adminService;

	@Autowired
	private UserService userService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private SponsorService sponsorService;

	@Autowired
	private FolderService folderService;

	@Autowired
	private MessageService messageService;


	public FolderController() {
		super();
	}

	// FOLDER ------------------------------------------------------------------------

	/*
	 * Se muestra el formulario para crear una folder
	 * En el solo se puede incluir el nombre pues las carpetas del sistema
	 * ya se crean cuando se registra el usuario por lo tanto esta folder sera
	 * de tipo system false.
	 */
	@RequestMapping(value = "create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		FolderForm folderForm;

		folderForm = new FolderForm();
		result = createEditModelAndViewCreate(folderForm);

		return result;
	}

	@RequestMapping(value = "edit", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam String folderId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		result = new ModelAndView("edit");
		try {
			Actor actor = actorService.findByPrincipal();
			Integer foderID = Integer.parseInt(folderId);
			Folder f = folderService.findOne(foderID);

			//La folder no puede ser del sistema
			Assert.isTrue(!f.getSystem());

			//Si no contiene esa folder el actor
			Assert.isTrue(actor.getFolders().contains(f));
			FolderForm folderForm = new FolderForm();
			folderForm.setId(foderID);
			folderForm.setName(f.getName());

			Collection<Folder> cF = new HashSet<Folder>();
			cF.addAll(actor.getFolders());

			result.addObject("folders", cF);
			result.addObject("folderForm", folderForm);
			result.addObject("requestURI", "folder/actor/edit.do?folderId=" + folderForm.getId());
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:list.do");
			redirectAttrs.addFlashAttribute("message", "accessDenied");
		}

		return result;
	}

	@RequestMapping(value = "editMessageFolder", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam int messageId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();
		result = new ModelAndView("editMessageFolder");
		try {
			Assert.isTrue(messageService.messageActorYesNo(actor, messageId));
			Message folderForm = messageService.findOne(messageId);
			result.addObject("folderForm", folderForm);
			result.addObject("m", folderForm);
			result.addObject("folders", actor.getFolders());
			result.addObject("requestURI", "folder/actor/editMessageFolder.do?messageId=" + folderForm.getId());
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:list.do");
			redirectAttrs.addFlashAttribute("message", "accessDenied");
		}

		return result;
	}

	@RequestMapping(value = "create", method = RequestMethod.POST, params = "create")
	public ModelAndView save(@Valid FolderForm folderForm, BindingResult binding) {
		ModelAndView result;

		Actor actor = actorService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createEditModelAndViewCreate(folderForm);
		} else if (!folderService.findFolderBoolean(actor, folderForm.getName())) {
			result = createEditModelAndViewCreate(folderForm, "folder.errorFolder.name");
		} else {
			try {

				Folder f = folderService.create();
				f.setName(folderForm.getName());
				f.setSystem(false);
				f.setFolder(null);
				Folder ff = folderService.save(f);
				actor.getFolders().add(ff);
				if (actor.getClass() == User.class) {
					actor = userService.findOne(actor.getId());
					User r = (User) actor;
					userService.save(r);
				} else if (actor.getClass() == Admin.class) {
					actor = adminService.findOne(actor.getId());
					Admin a = (Admin) actor;
					adminService.save(a);
				} else if (actor.getClass() == Company.class) {
					actor = companyService.findOne(actor.getId());
					Company a = (Company) actor;
					companyService.save(a);
				} else if (actor.getClass() == Sponsor.class) {
					actor = sponsorService.findOne(actor.getId());
					Sponsor m = (Sponsor) actor;
					sponsorService.save(m);
				} else if (actor.getClass() == Merchant.class) {
					actor = merchantService.findOne(actor.getId());
					Merchant m = (Merchant) actor;
					merchantService.save(m);
				}

				result = new ModelAndView("redirect:list.do");

			} catch (Throwable oops) {
				result = createEditModelAndViewCreate(folderForm, "security.error");
			}
		}

		return result;
	}

	@RequestMapping(value = "edit", method = RequestMethod.POST, params = "edit")
	public ModelAndView editFolder(@Valid FolderForm folderForm, BindingResult binding) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();
		Folder f = folderService.findOne(folderForm.getId());
		Folder ff = folderForm.getFolder();

		if (binding.hasErrors()) {
			result = createEditModelAndViewEdit(folderForm);
		} else if (!folderService.findFolderBoolean(actor, folderForm.getName()) && !folderForm.getName().toLowerCase().equals(f.getName().toLowerCase())) {
			result = createEditModelAndViewEdit(folderForm, "folder.errorFolder.name");
		} else {
			try {
				Assert.isTrue(actor.getFolders().contains(f));
				if (ff != null || ff != f) {
					f.setFolder(ff);
				}
				f.setName(folderForm.getName());
				folderService.save(f);
				actorService.save(actor);
				result = new ModelAndView("redirect:list.do");

			} catch (Throwable oops) {
				if (!actor.getFolders().contains(f)) {
					result = createEditModelAndViewEdit(folderForm, "security.errorFolderActor");
				} else {
					result = createEditModelAndViewEdit(folderForm, "folder.editError");
				}
			}
		}

		return result;
	}

	@RequestMapping(value = "edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(FolderForm folderForm, BindingResult binding) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();
		Folder f = folderService.findOne(folderForm.getId());
		try {
			Assert.isTrue(actor.getFolders().contains(f));
			Assert.isTrue(!f.getSystem());
			f.setFolder(null);

			if (folderService.foldersFather(actor.getId(), f.getName()).size() > 0) {
				for (Folder folders : folderService.foldersFather(actor.getId(), f.getName())) {
					folders.setFolder(null);
					folderService.save(folders);
				}
			}

			folderService.delete(f);
			result = new ModelAndView("redirect:list.do");
		} catch (Throwable oops) {
			result = createEditModelAndViewDelete(folderForm, "folder.error");
		}
		return result;
	}

	@RequestMapping(value = "editMessageFolder", method = RequestMethod.POST, params = "changefolder")
	public ModelAndView changeFolder(Message folderForm, BindingResult binding) {
		ModelAndView result;
		Message m = messageService.findOne(folderForm.getId());
		Folder nuevaFolder = folderForm.getFolder();
		Folder antiguaFolder = m.getFolder();

		try {
			antiguaFolder.getMessages().remove(m);
			nuevaFolder.getMessages().add(m);
			m.setFolder(nuevaFolder);
			folderService.save(nuevaFolder);
			folderService.save(antiguaFolder);
			result = new ModelAndView("redirect:message.do?messageId=" + m.getId());
		} catch (Throwable oops) {
			result = createEditModelAndViewD(folderForm, "actor.error");
		}

		return result;
	}

	/*
	 * Se listan las folder que tiene el actor logueado
	 */

	@RequestMapping(value = "list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();

		if (actor.getClass() == User.class) {
			actor = userService.findOne(actor.getId());
		} else if (actor.getClass() == Admin.class) {
			actor = adminService.findOne(actor.getId());
		} else if (actor.getClass() == Company.class) {
			actor = companyService.findOne(actor.getId());
		} else if (actor.getClass() == Merchant.class) {
			actor = merchantService.findOne(actor.getId());
		} else if (actor.getClass() == Sponsor.class) {
			actor = sponsorService.findOne(actor.getId());
		}

		Collection<Folder> cF = new HashSet<Folder>();
		cF.addAll(actor.getFolders());

		result = new ModelAndView("list");
		result.addObject("folders", cF);
		result.addObject("requestURI", "folder/actor/list.do");

		return result;
	}

	//MESSAGE--------------------------------------------------------------------------

	/*
	 * Se muestran en la vista listMessages todos los mensajes de
	 * la folderId en la cual se ha pinchado.
	 */
	@RequestMapping(value = "listMessages", method = RequestMethod.GET)
	public ModelAndView listMessages(@RequestParam int folderId, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Actor actor = actorService.findByPrincipal();

		if (actor.getClass() == User.class) {
			actor = userService.findOne(actor.getId());
		} else if (actor.getClass() == Admin.class) {
			actor = adminService.findOne(actor.getId());
		} else if (actor.getClass() == Company.class) {
			actor = companyService.findOne(actor.getId());
		} else if (actor.getClass() == Merchant.class) {
			actor = merchantService.findOne(actor.getId());
		} else if (actor.getClass() == Sponsor.class) {
			actor = sponsorService.findOne(actor.getId());
		}

		try {
			Folder ff = folderService.findFolder(actor, folderService.findOne(folderId).getName());
			Collection<Message> cM = new HashSet<Message>();
			cM.addAll(ff.getMessages());

			result = new ModelAndView("listMessages");
			result.addObject("messages", cM);
			result.addObject("requestURI", "folder/actor/listMessages.do");
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:list.do");
			redirectAttrs.addFlashAttribute("message", "accessDenied");
		}

		return result;
	}

	@RequestMapping(value = "createMessage", method = RequestMethod.GET)
	public ModelAndView createMessage() {
		ModelAndView result;

		MessageForm messageForm = new MessageForm();

		result = new ModelAndView("createMessage");
		result.addObject("messageForm", messageForm);
		result.addObject("requestURI", "folder/actor/createMessage.do");
		return result;
	}

	@RequestMapping(value = "message", method = RequestMethod.GET)
	public ModelAndView message(@RequestParam int messageId, RedirectAttributes redirectAttrs) {
		ModelAndView result;

		try {
			Actor actor = actorService.findByPrincipal();
			Message message = messageService.messageActor(actor.getId(), messageId);
			Collection<Folder> cF = actor.getFolders();
			cF.remove(message.getFolder());
			FolderForm folderForm = new FolderForm();
			result = new ModelAndView("message");
			result.addObject("folders", cF);
			result.addObject("messageForm", message);
			result.addObject("folderForm", folderForm);
			result.addObject("requestURI", "folder/actor/message.do?messageId=" + messageId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:list.do");
			redirectAttrs.addFlashAttribute("message", "accessDenied");
		}

		return result;
	}

	//NOTIFICACION MENSAJE
	@RequestMapping(value = "createMessageNotification", method = RequestMethod.GET)
	public ModelAndView createMessageNotification() {
		ModelAndView result;

		MessageNotificationForm messageNotificationForm = new MessageNotificationForm();

		result = new ModelAndView("createMessageNotification");
		result.addObject("messageNotificationForm", messageNotificationForm);
		result.addObject("requestURI", "folder/actor/createMessageNotification.do");
		return result;
	}

	@RequestMapping(value = "createMessageNotification", method = RequestMethod.POST, params = "sendMessageNotification")
	public ModelAndView saveNotification(@Valid MessageNotificationForm messageNotificationForm, BindingResult binding) {
		ModelAndView result;
		Actor actorFrom = actorService.findByPrincipal();
		if (binding.hasErrors()) {
			result = createEditModelAndViewNotification(messageNotificationForm);
		} else {
			try {
				actorFrom = adminService.findOne(actorFrom.getId());
				messageService.sendBroadcastMessage(actorFrom, messageNotificationForm.getBody(), messageNotificationForm.getPriority(), messageNotificationForm.getSubject());

				result = new ModelAndView("redirect:/folder/actor/list.do");
			} catch (Throwable oops) {
				if (messageNotificationForm.getBody().toString().length() > 255) {
					result = createEditModelAndViewNotification(messageNotificationForm, "actor.message.errorMessageBody");
				} else if (messageNotificationForm.getSubject().toString().length() > 255) {
					result = createEditModelAndViewNotification(messageNotificationForm, "actor.message.errorMessageSubject");
				} else {
					result = createEditModelAndViewNotification(messageNotificationForm, "actor.message.error");
				}
			}
		}
		return result;
	}

	@RequestMapping(value = "message", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(Message messageForm, BindingResult binding) {
		ModelAndView result;

		try {
			Message m = messageService.findOne(messageForm.getId());
			messageService.delete(m);
			result = new ModelAndView("redirect:list.do");
		} catch (Throwable oops) {
			result = createEditModelAndViewD(messageForm, "actor.error");
		}
		return result;
	}

	@RequestMapping(value = "createMessage", method = RequestMethod.POST, params = "sendMessage")
	public ModelAndView save(@Valid MessageForm messageForm, BindingResult binding) {
		ModelAndView result;
		Actor actorFrom = actorService.findByPrincipal();
		if (binding.hasErrors()) {
			result = createEditModelAndView(messageForm);
		} else {
			try {
				Assert.isTrue(actorService.existEmail(messageForm.getEmail()));
				Message s = messageService.create();
				s.setActorFrom(actorFrom);
				s.setBody(messageForm.getBody());
				s.setPriority(messageForm.getPriority());
				s.setSubject(messageForm.getSubject());
				s.setActorTo(actorService.findActorForEmail(messageForm.getEmail()));
				messageService.save(s);
				result = new ModelAndView("redirect:/folder/actor/list.do");
			} catch (Throwable oops) {
				if (!actorService.existEmail(messageForm.getEmail())) {
					result = createEditModelAndView(messageForm, "actor.message.errorEmail");
				} else if (messageForm.getBody().toString().length() > 255) {
					result = createEditModelAndView(messageForm, "actor.message.errorMessageBody");
				} else if (messageForm.getSubject().toString().length() > 255) {
					result = createEditModelAndView(messageForm, "actor.message.errorMessageSubject");
				} else {
					result = createEditModelAndView(messageForm, "actor.message.error");
				}
			}
		}
		return result;
	}

	protected ModelAndView createEditModelAndView(MessageForm messageForm) {
		ModelAndView result;
		result = createEditModelAndView(messageForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewEdit(FolderForm folderForm) {
		ModelAndView result;
		result = createEditModelAndViewEdit(folderForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewCreate(FolderForm folderForm) {
		ModelAndView result;
		result = createEditModelAndViewCreate(folderForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewDelete(FolderForm folderForm) {
		ModelAndView result;
		result = createEditModelAndViewDelete(folderForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(MessageForm messageForm, String message) {
		ModelAndView result;

		result = new ModelAndView("createMessage");
		result.addObject("messageForm", messageForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewEdit(FolderForm folderForm, String message) {
		ModelAndView result;

		Actor actor = actorService.findByPrincipal();
		Collection<Folder> cF = actor.getFolders();

		result = new ModelAndView("edit");
		result.addObject("folders", cF);
		result.addObject("folderForm", folderForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewD(Message message) {
		ModelAndView result;
		result = createEditModelAndViewD(message, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewD(Message messageForm, String message) {
		ModelAndView result;

		result = new ModelAndView("message");
		result.addObject("messageForm", messageForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewCreate(FolderForm folderForm, String message) {
		ModelAndView result;

		result = new ModelAndView("create");
		result.addObject("folderForm", folderForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewDelete(FolderForm folderForm, String message) {
		ModelAndView result;

		result = new ModelAndView("edit");
		result.addObject("folderForm", folderForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewNotification(MessageNotificationForm messageNotificationForm) {
		ModelAndView result;
		result = createEditModelAndViewNotification(messageNotificationForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewNotification(MessageNotificationForm messageNotificationForm, String message) {
		ModelAndView result;

		result = new ModelAndView("createMessageNotification");
		result.addObject("messageNotificationForm", messageNotificationForm);
		result.addObject("message", message);

		return result;
	}
}
