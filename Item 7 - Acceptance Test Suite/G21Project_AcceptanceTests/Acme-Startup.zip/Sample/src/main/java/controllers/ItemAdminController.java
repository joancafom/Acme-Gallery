package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Item;
import services.ItemService;

@Controller
@RequestMapping("/item/admin")
public class ItemAdminController extends AbstractController {

	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Item item;
		
		try {
			item = this.itemService.findOne(itemId);
			
			this.itemService.deleteItem(item);
			
			result = new ModelAndView("redirect:/item/list.do");
		} catch (Throwable oops) {
			String message;
			if (oops.getLocalizedMessage().contains("Acceso denegado")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
}
