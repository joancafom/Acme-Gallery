package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Company;
import domain.Item;
import services.CompanyService;
import services.ItemService;

@Controller
@RequestMapping("/item/company")
public class ItemCompanyController extends AbstractController {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private CompanyService companyService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Item> items;
		Company company;
		
		company = this.companyService.findByPrincipal();
		
		items = company.getItems();
		
		result = new ModelAndView("item/list");
		result.addObject("requestURI", "item/");
		result.addObject("baseURI", "item/company/");
		result.addObject("items", items);
		result.addObject("principal", true);
		
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(RedirectAttributes redirAttrs) {
		ModelAndView result;
		Item item;
		Company company;
		
		try {
			company = this.companyService.findByPrincipal();
			
			item = this.itemService.create();
			Assert.isTrue(company.getPro(), "No tienes permisos");
			
			result = this.createEditModelAndView(item);
		} catch (Throwable oops) {
			String message;
			
			if (oops.getLocalizedMessage().equals("No tienes permisos")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/company/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		
		
		
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ModelAndView create(@Valid final Item item, BindingResult binding, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Company company;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("item/edit");
			result.addObject("requestURI", "item/merchant");
		} else {
			try 
			{
				company = this.companyService.findByPrincipal();
				Assert.isTrue(company.getPro(), "No tienes permisos");
				
				this.itemService.saveItemCompany(item, company);
				
				result = new ModelAndView("redirect:/item/company/list.do");
			} catch (Throwable oops) {
				String message;
				
				if (oops.getLocalizedMessage().equals("No tienes permisos")) {
					message = "item.access";
				} else {
					message = "item.error";
				}
				result = new ModelAndView("redirect:/item/company/list.do");
				redirAttrs.addFlashAttribute("message", message);
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Company company;
		Item item;
		
		try {
			company = this.companyService.findByPrincipal();
			Assert.isTrue(company.getPro(), "Acceso denegado");
			
			item = this.itemService.findOne(itemId);
			Assert.isTrue(!item.getDeleted(), "Acceso denegado");
			Assert.isTrue(company.getItems().contains(item), "Acceso denegado");
			
			result = this.createEditModelAndView(item);
			result.addObject("baseURI", "item/company/edit.do");
		} catch (Throwable oops) {
			String message;
			if (oops.getLocalizedMessage().contains("Acceso denegado")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/company/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView edit(@Valid Item item, BindingResult binding) {
		ModelAndView result;
		Company company;
		
		if (binding.hasErrors()) {
			result = this.createEditModelAndView(item);
			result.addObject("baseURI", "item/company/edit.do");
		} else {
			try {
				company = this.companyService.findByPrincipal();
				Assert.isTrue(company.getPro(), "Acceso denegado");
				Assert.isTrue(!item.getDeleted(), "Acceso denegado");
				Assert.isTrue(company.getItems().contains(item), "Acceso denegado");
				item.setDeleted(true);
				
				this.itemService.save(item);
				
				result = new ModelAndView("redirect:/item/company/list.do");
			} catch (Throwable oops) {
				String message;
				
				if (oops.getLocalizedMessage().equals("Acceso denegado")) {
					message = "item.access";
				} else {
					message = "item.error";
				}
				result = this.createEditModelAndView(item, message);
				result.addObject("baseURI", "item/company/edit.do");
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Company company;
		Item item;
		
		try {
			company = this.companyService.findByPrincipal();
			
			item = this.itemService.findOne(itemId);
			Assert.isTrue(company.getPro(), "Acceso denegado");
			Assert.isTrue(company.getItems().contains(item), "Acceso denegado");
			
			this.itemService.deleteItem(item);
			
			result = new ModelAndView("redirect:/item/company/list.do");
		} catch (Throwable oops) {
			String message;
			if (oops.getLocalizedMessage().contains("Acceso denegado")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/company/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(@RequestParam final String item) {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.searchItemsCompany(item);
		
		result = new ModelAndView("item/list");
		result.addObject("requestURI", "item/");
		result.addObject("baseURI", "item/company/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView saveCondition(@RequestParam String item) {
		
		return new ModelAndView("redirect:/item/company/search.do?item=" + item);
	}
	
	protected ModelAndView createEditModelAndView(Item item) {
		ModelAndView result;
		
		result = this.createEditModelAndView(item, null);
		
		return result;
	}
	
	protected ModelAndView createEditModelAndView(Item item, String message) {
		ModelAndView result;
		
		result = new ModelAndView("item/edit");
		result.addObject("item", item);
		result.addObject("message", message);
		result.addObject("requestURI", "item/company");
		result.addObject("baseURI", "item/company/create.do");
		result.addObject("principal", true);
		
		return result;
	}
}
