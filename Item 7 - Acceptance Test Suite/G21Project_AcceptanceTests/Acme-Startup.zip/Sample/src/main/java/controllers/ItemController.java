package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Company;
import domain.Item;
import domain.Merchant;
import services.CompanyService;
import services.ItemService;
import services.MerchantService;

@Controller
@RequestMapping("/item")
public class ItemController extends AbstractController {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;
	
	public ItemController() {
		super();
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.findAllNotDeleted();
		
		result = new ModelAndView("item/list");
		result.addObject("baseURI", "item/");
		result.addObject("requestURI", "item/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/listCompany", method = RequestMethod.GET)
	public ModelAndView listCompany(@RequestParam final int companyId) {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.findCompanyItems(companyId);
		
		result = new ModelAndView("item/list");
		result.addObject("baseURI", "item/");
		result.addObject("requestURI", "item/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/listMerchant", method = RequestMethod.GET)
	public ModelAndView listMerchant(@RequestParam final int merchantId) {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.findMerchantItems(merchantId);
		
		result = new ModelAndView("item/list");
		result.addObject("baseURI", "item/");
		result.addObject("requestURI", "item/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(@RequestParam final String item) {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.searchItems(item);
		
		result = new ModelAndView("item/list");
		result.addObject("baseURI", "item/");
		result.addObject("requestURI", "item/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView saveCondition(@RequestParam String item) {
		
		return new ModelAndView("redirect:/item/search.do?item=" + item);
	}
	
	
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int itemId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Item item;
		Merchant merchant;
		Company company;
		String sellerLink = null;
		String sellerName = null;
		
		try {
			item = this.itemService.findOne(itemId);
			Assert.isTrue(!item.getDeleted(), "Este item no esta disponible");
			
			merchant = this.merchantService.findByItem(itemId);
			company = this.companyService.findByItem(itemId);
			
			if(company == null) {
				if (merchant == null) {
					Assert.isTrue(true);
				} else {
					sellerName = merchant.getName();
					sellerLink = "item/listMerchant.do?merchantId=" + merchant.getId();
				}
			} else {
				sellerName = company.getName();
				sellerLink = "item/listCompany.do?companyId=" + company.getId();
			}
			
			result = new ModelAndView("item/display");
			result.addObject("requestURI", "item/");
			result.addObject("item", item);
			result.addObject("sellerLink", sellerLink);
			result.addObject("sellerName", sellerName);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/item/list.do");
			String message;
			
			if (oops.getLocalizedMessage().equals("Este item no esta disponible")) {
				message = "item.available";
			} else {
				message = "item.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
}
