package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Item;
import domain.Merchant;
import services.ItemService;
import services.MerchantService;

@Controller
@RequestMapping("/item/merchant")
public class ItemMerchantController extends AbstractController {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private MerchantService merchantService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.findAllItemsByMerchant();
		
		result = new ModelAndView("item/list");
		result.addObject("requestURI", "item/");
		result.addObject("baseURI", "item/merchant/");
		result.addObject("items", items);
		result.addObject("principal", true);
		
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Item item;
		
		item = this.itemService.create();
		
		result = this.createEditModelAndView(item);
		
		return result;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ModelAndView create(@Valid final Item item, BindingResult binding, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Merchant merchant;
		
		if (binding.hasErrors()) {
			result = new ModelAndView("item/edit");
			result.addObject("requestURI", "item/merchant");
		} else {
			try 
			{
				merchant = this.merchantService.findByPrincipal();
				
				this.itemService.saveItem(item, merchant);
				
				result = new ModelAndView("redirect:/item/merchant/list.do");
			} catch (Throwable oops) {
				String message;
				
				if (oops.getLocalizedMessage().equals("No tienes permisos")) {
					message = "item.access";
				} else {
					message = "item.error";
				}
				result = new ModelAndView("redirect:/item/merchant/list.do");
				redirAttrs.addFlashAttribute("message", message);
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Merchant merchant;
		Item item;
		
		try {
			merchant = this.merchantService.findByPrincipal();
			
			item = this.itemService.findOne(itemId);
			Assert.isTrue(!item.getDeleted(), "Acceso denegado");
			Assert.isTrue(merchant.getItems().contains(item), "Acceso denegado");
			
			result = this.createEditModelAndView(item);
			result.addObject("baseURI", "item/merchant/edit.do");
		} catch (Throwable oops) {
			String message;
			if (oops.getLocalizedMessage().contains("Acceso denegado")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/merchant/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView edit(@Valid Item item, BindingResult binding) {
		ModelAndView result;
		Merchant merchant;
		
		if (binding.hasErrors()) {
			result = this.createEditModelAndView(item);
			result.addObject("baseURI", "item/merchant/edit.do");
		} else {
			try {
				merchant = this.merchantService.findByPrincipal();
				Assert.isTrue(!item.getDeleted(), "Acceso denegado");
				Assert.isTrue(merchant.getItems().contains(item), "Acceso denegado");
				
				this.itemService.save(item);
				
				result = new ModelAndView("redirect:/item/merchant/list.do");
			} catch (Throwable oops) {
				String message;
				
				if (oops.getLocalizedMessage().equals("Acceso denegado")) {
					message = "item.access";
				} else {
					message = "item.error";
				}
				result = this.createEditModelAndView(item, message);
				result.addObject("baseURI", "item/merchant/edit.do");
			}
		}
		return result;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int itemId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Merchant merchant;
		Item item;
		
		try {
			merchant = this.merchantService.findByPrincipal();
			
			item = this.itemService.findOne(itemId);
			Assert.isTrue(merchant.getItems().contains(item), "Acceso denegado");
			
			this.itemService.deleteItem(item);
			
			result = new ModelAndView("redirect:/item/merchant/list.do");
		} catch (Throwable oops) {
			String message;
			if (oops.getLocalizedMessage().contains("Acceso denegado")) {
				message = "item.access";
			} else {
				message = "item.error";
			}
			result = new ModelAndView("redirect:/item/merchant/list.do");
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(@RequestParam final String item) {
		ModelAndView result;
		Collection<Item> items;
		
		items = this.itemService.searchItemsMerchant(item);
		
		result = new ModelAndView("item/list");
		result.addObject("requestURI", "item/");
		result.addObject("baseURI", "item/merchant/");
		result.addObject("items", items);
		result.addObject("principal", false);

		return result;
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView saveCondition(@RequestParam String item) {
		
		return new ModelAndView("redirect:/item/merchant/search.do?item=" + item);
	}
	
	protected ModelAndView createEditModelAndView(Item item) {
		ModelAndView result;
		
		result = this.createEditModelAndView(item, null);
		
		return result;
	}
	
	protected ModelAndView createEditModelAndView(Item item, String message) {
		ModelAndView result;
		
		result = new ModelAndView("item/edit");
		result.addObject("item", item);
		result.addObject("message", message);
		result.addObject("requestURI", "item/merchant");
		result.addObject("baseURI", "item/merchant/create.do");
		result.addObject("principal", true);
		
		return result;
	}
}
