package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/law")
public class LawController extends AbstractController {

	public LawController() {
		super();
	}
	
	@RequestMapping(value = "use")
	public ModelAndView use() {
		ModelAndView result;
		
		result = new ModelAndView("law/use");
		
		return result;
	}
	
	@RequestMapping(value = "privacy")
	public ModelAndView privacy() {
		ModelAndView result;
		
		result = new ModelAndView("law/privacy");
		
		return result;
	}
	
	@RequestMapping(value = "cookies")
	public ModelAndView cookies() {
		ModelAndView result;
		
		result = new ModelAndView("law/cookies");
		
		return result;
	}
}
