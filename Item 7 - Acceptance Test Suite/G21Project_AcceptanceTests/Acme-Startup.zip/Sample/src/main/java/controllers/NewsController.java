package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Admin;
import domain.Comment;
import domain.Company;
import domain.News;
import domain.Startup;
import forms.NewsForm;
import services.AdminService;
import services.CompanyService;
import services.NewsService;
import services.StartupService;

@Controller
@RequestMapping("/news")
public class NewsController extends AbstractController{
	
	// Services ---------------------------------------------------------------
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private StartupService startupService;

	@Autowired
	private CompanyService companyService;
	
	
	// Constructors -----------------------------------------------------------
	public NewsController() {
		super();
	}
	
	
	
	//List ----------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam("startupId") int startupId) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(startupId);
		Collection<News> newss= new ArrayList<News>();

		newss = startup.getNews();

		result = new ModelAndView("news/list");
		result.addObject("newss", newss);
			

		return result;
	}
	
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam("newId") int newId) {
		ModelAndView result;
		News news;
		news = newsService.findOne(newId);

		result = new ModelAndView("news/display");
		result.addObject("news", news);
			

		return result;
	}
	
	
	
	//Admin list---------------------------------------
	@RequestMapping(value = "/admin/list", method = RequestMethod.GET)
	public ModelAndView adminList(final RedirectAttributes redirectAttrs) {
		ModelAndView result;

		try {
			Admin a = adminService.findByPrincipal();
			Assert.notNull(a);

			Collection<News> newss = new ArrayList<News>();
			newss = newsService.findAll();
			result = new ModelAndView("news/list");
			result.addObject("newss", newss);
			result.addObject("requestURI", "news/admin/list.do");
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/list.do");
			redirectAttrs.addFlashAttribute("message", "startup.notAdmin");

		}

		return result;
	}
	
	
	//Admin delete-------------------------------------
	@RequestMapping(value = "/admin/delete", method = RequestMethod.GET)
	public ModelAndView adminDelte(@RequestParam int newsId,final RedirectAttributes redirectAttrs) {
		ModelAndView result;

		try {
			Admin a = adminService.findByPrincipal();
			News res = newsService.findOne(newsId);
			Assert.notNull(a);

			Collection<News> newss = new ArrayList<News>();
			
			newsService.delete(res);
			newss = newsService.findAll();
			result = new ModelAndView("news/list");
			result.addObject("newss", newss);
			result.addObject("requestURI", "news/admin/list.do");
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/news/admin/list.do");
			redirectAttrs.addFlashAttribute("message", "startup.notAdmin");

		}

		return result;
	}
	
	
	
	
	
	// Creating ----------------------------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.GET)
	public ModelAndView create(final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		result = new ModelAndView("news/company/create");

		News res = newsService.create();
		NewsForm newsForm = new NewsForm ();
		newsForm.setId(res.getId());


		result.addObject("newsForm", newsForm);
		result.addObject("startups", startups);
		result.addObject("requestURI", "./news/company/create.do");

		
		return result;
	}
	
	//Save create-----------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid NewsForm newsForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(newsForm);
		} else {
			try {

				News res = new News();
				Date momento = new Date(System.currentTimeMillis() - 1000);
				Collection<Comment> comments = new ArrayList<Comment>();

				res.setBody(newsForm.getBody());
				res.setPicture(newsForm.getPicture());
				res.setTitle(newsForm.getTitle());
				res.setComments(comments);
				res.setCreationDate(momento);
				
				

				res = newsService.save(res);
				
				Startup startup = startupService.findOne(newsForm.getStartupId());
				Collection<News> aux = new ArrayList<News>();
				aux=startup.getNews();
				aux.add(res);
				startupService.saveCategory(startup);

				result = new ModelAndView("redirect:/startup/company/list.do");
			} catch (Throwable oops) {

				result = createEditModelAndView(newsForm, "news.commit.error");
			}
		}
		return result;
	}	
	
	

	
	
	
	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(NewsForm newsForm ) {
		ModelAndView result;
		result = createEditModelAndView(newsForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(NewsForm  newsForm, String message) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		result = new ModelAndView("news/company/create");

		result.addObject("newsForm", newsForm);
		result.addObject("message", message);
		result.addObject("startups", startups);

		return result;
	}
}
