package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Company;
import domain.Offer;
import domain.PersonalData;
import domain.Startup;
import domain.Tag;
import domain.User;
import forms.OfferForm;
import services.CompanyService;
import services.OfferService;
import services.StartupService;
import services.UserService;

@Controller
@RequestMapping("/offer")
public class OfferController extends AbstractController {
	
	// Services ---------------------------------------------------------------
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private UserService userService;

	@Autowired
	private CompanyService companyService;
	

	// Constructors -----------------------------------------------------------
	public OfferController() {
		super();
	}
	
	
	//List per startup----------------------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam("startupId") int startupId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(startupId);
		Collection<Offer> offers= new ArrayList<Offer>();

		offers = startup.getOffers();

		result = new ModelAndView("offer/user/list");
		result.addObject("offers", offers);
			
		return result;
	}
	
	
	
	//List per startup for company----------------------------------------
	@RequestMapping(value = "/company/list", method = RequestMethod.GET)
	public ModelAndView listCompany(@RequestParam("startupId") int startupId , final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(startupId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		try{
			Assert.isTrue(startups.contains(startup));
			
			Collection<Offer> offers= new ArrayList<Offer>();

			offers = startup.getOffers();

			result = new ModelAndView("offer/company/list");
			result.addObject("offers", offers);
			
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			redirectAttrs.addFlashAttribute("message", "offer.notAllowed.company");

		}
		
		return result;
	}
	
	
	// Creating ----------------------------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.GET)
	public ModelAndView create(final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		result = new ModelAndView("offer/company/create");

		Offer res = offerService.create();
		OfferForm offerForm = new OfferForm ();
		offerForm.setId(res.getId());


		result.addObject("offerForm", offerForm);
		result.addObject("startups", startups);
		result.addObject("requestURI", "./offer/company/create.do");

		
		return result;
	}	
	
	
	//Save create-----------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid OfferForm offerForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(offerForm);
		} else {
			try {

				Offer res = new Offer();
				Collection<Tag> tags = new ArrayList<Tag>();
				Collection<PersonalData> personalDatas=new ArrayList<PersonalData>();
				
				res.setDescription(offerForm.getDescription());
				res.setSalary(offerForm.getSalary());
				res.setTitle(offerForm.getTitle());
				res.setTags(tags);
				res.setPersonalDatas(personalDatas);
				
				res = offerService.save(res);
				
				Startup startup = startupService.findOne(offerForm.getStartupId());
				Collection<Offer> aux = new ArrayList<Offer>();
				aux=startup.getOffers();
				aux.add(res);
				startupService.saveCategory(startup);

				result = new ModelAndView("redirect:/startup/company/list.do");
			} catch (Throwable oops) {

				result = createEditModelAndView(offerForm, "offer.commit.error");
			}
		}
		return result;
	}	
	
	
	
	// Modify------------------------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("offerId") int offerId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		OfferForm offerForm = new OfferForm();
		startups = c.getStartups();
		Startup startup=startupService.startupPerOffer(offerId);
		Collection<Offer> offers = new ArrayList<Offer>();
		offers = startup.getOffers();
		
		Offer res =offerService.findOne(offerId);

		try {
			Assert.isTrue(startups.contains(startup));
			Assert.isTrue(offers.contains(res));
			
			offerForm.setDescription(res.getDescription());
			offerForm.setTitle(res.getTitle());
			offerForm.setSalary(res.getSalary());
			offerForm.setId(offerId);
			offerForm.setStartupId(startup.getId());
			
			result = new ModelAndView("offer/company/edit");

			result.addObject("offerForm", offerForm);
			result.addObject("startups", startups);
			result.addObject("requestURI", "offer/company/edit.do?offerId=" + offerId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "offer.startup.commit.notYour");
			} else if(!(offers.contains(res))){
				redirectAttrs.addFlashAttribute("message", "offer.commit.notStartup");
			}else{
				result = createEditModelAndView(offerForm, "offer.commit.error");

			}

		}

		return result;
	}
	
	
	//Save edit---------------------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid OfferForm offerForm, BindingResult binding, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Startup startup=startupService.startupPerOffer(offerForm.getId());
		Collection<Offer> offers = new ArrayList<Offer>();
		offers = startup.getOffers();
		Offer res =offerService.findOne(offerForm.getId());
		
		if (binding.hasErrors()) {
			result = createEditModelAndView(offerForm);

		} else {
			try {
				Assert.isTrue(startups.contains(startup));
				Assert.isTrue(offers.contains(res));

				res.setTitle(offerForm.getTitle());
				res.setDescription(offerForm.getDescription());
				res.setSalary(offerForm.getSalary());
				
				offerService.save(res);
				
				offerService.save(res);
				result = new ModelAndView("redirect:/offer/company/list.do?startupId="+startup.getId());
			} catch (Throwable oops) {
				if(!(startups.contains(startup))){
					result = createEditModelAndView(offerForm, "offer.startup.commit.notYour");
				} else if(!(offers.contains(res))){
					result = new ModelAndView("redirect:/offer/company/list.do?startupId="+startup.getId());
					redirectAttrs.addFlashAttribute("message", "offer.commit.notStartup");
				}else{
					result = createEditModelAndView(offerForm, "offer.commit.error");
				}
			}
		}
		return result;
	}
	
	
	
	
	// Delete----------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid OfferForm offerForm , BindingResult binding, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Startup startup=startupService.startupPerOffer(offerForm.getId());
		Collection<Offer> offers = new ArrayList<Offer>();
		offers = startup.getOffers();
		Offer res =offerService.findOne(offerForm.getId());

		if (binding.hasErrors()) {
			result = createEditModelAndView(offerForm);
		} else {
			try {
	
				Assert.isTrue(startups.contains(startup));
				Assert.isTrue(offers.contains(res));				
	
				offerService.delete(res);
				result = new ModelAndView("redirect:/offer/company/list.do?startupId="+startup.getId());
			} catch (Throwable oops) {
				if(!(startups.contains(startup))){
					result = createEditModelAndView(offerForm, "offer.startup.commit.notYour");
				} else if(!(offers.contains(res))){
					result = new ModelAndView("redirect:/offer/company/list.do?startupId="+startup.getId());
					redirectAttrs.addFlashAttribute("message", "offer.commit.notStartup");
				}else{
					result = createEditModelAndView(offerForm, "offer.commit.error");
				}
			}
	}
		return result;
	}
	
	
	
	// User aplica a una offer----------------------------------------------
	@RequestMapping(value = "/user/apply", method = RequestMethod.GET)
	public ModelAndView subscribe(@RequestParam int offerId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer res;
		res = offerService.findOne(offerId);
		User u = userService.findByPrincipal();
		Collection<Offer> offers= new ArrayList<Offer>();
		
		try {
			Assert.notNull(u.getPersonalData());
			
			PersonalData personalData=u.getPersonalData();
			offers=offerService.offersPerPersonalData(personalData.getId());

			Assert.isTrue(!(offers.contains(res)));			

			offerService.apply(res, u.getId());
			Startup startup = startupService.startupPerOffer(offerId);
			result = new ModelAndView("redirect:/offer/user/list.do?startupId="+startup.getId());

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/user/list.do");
			if(offers.contains(res)){
				redirectAttrs.addFlashAttribute("message", "offer.subscribe.error");
			}else{
				redirectAttrs.addFlashAttribute("message", "offer.commit.personal");

				}
			}
		return result;
	}		
	

	
	
	
	
	
	
	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(OfferForm offerForm ) {
		ModelAndView result;
		result = createEditModelAndView(offerForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(OfferForm  offerForm, String message) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		if (offerForm.getId()==0){
			result = new ModelAndView("offer/company/create");

		}else{
			result = new ModelAndView("offer/company/edit");

		}

		result.addObject("offerForm", offerForm);
		result.addObject("message", message);
		result.addObject("startups", startups);

		return result;
	}
	
}
