
package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Company;
import domain.Offer;
import domain.PersonalData;
import domain.User;
import forms.PersonalDataForm;
import services.ActorService;
import services.CompanyService;
import services.OfferService;
import services.PersonalDataService;
import services.UserService;

@Controller
@RequestMapping("/personalData")
public class PersonalDataController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private PersonalDataService personalDataService;

	@Autowired
	private UserService userService;

	@Autowired
	private OfferService offerService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private ActorService actorService;


	// Constructors -----------------------------------------------------------
	public PersonalDataController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView result;

		User principal = userService.findByPrincipal();
		PersonalData personalData;

		personalData = personalDataService.personalDataPerUser(principal.getId());

		result = new ModelAndView("personalData/user/list");
		result.addObject("personalData", personalData);
		result.addObject("requestURI", "personalData/user/list.do");

		return result;
	}

	// Editing ------------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int personalDataId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		PersonalDataForm personalDataForm;
		User principal = userService.findByPrincipal();
		PersonalData personalData;
		User userPd = personalDataService.userByPersonalDataId(personalDataId);

		try {
			Assert.isTrue(principal.equals(userPd), "Usted no tiene acceso a datos personales que no son suyos");
			personalData = personalDataService.findOne(personalDataId);

			personalDataForm = new PersonalDataForm();
			personalDataForm.setPersonalDataId(personalData.getId());
			personalDataForm.setName(personalData.getName());
			personalDataForm.setSurname(personalData.getSurname());
			personalDataForm.setPhone(personalData.getPhone());
			personalDataForm.setEmail(personalData.getEmail());
			personalDataForm.setLinkedIn(personalData.getLinkedIn());

			result = new ModelAndView("personalData/user/edit");
			result.addObject("personalDataForm", personalDataForm);
			result.addObject("requestURI", "./personalData/user/edit.do?personalDataId=" + personalDataId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/personalData/user/list.do");
			if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos personales que no son suyos")) {
				redirectAttrs.addFlashAttribute("message", "personalData.user.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "personalData.error");
			}
		}

		return result;
	}

	// Save edit---------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid PersonalDataForm personalDataForm, BindingResult binding, RedirectAttributes redirectAttrs) {

		ModelAndView result;
		PersonalData personalData;
		User principal = userService.findByPrincipal();
		User userPd = personalDataService.userByPersonalDataId(personalDataForm.getPersonalDataId());

		if (binding.hasErrors()) {
			result = editModelAndView(personalDataForm);
		} else {
			try {
				Assert.isTrue(principal.equals(userPd), "Usted no tiene acceso a datos personales que no son suyos");
				Assert.notNull(personalDataForm);

				personalData = personalDataService.findOne(personalDataForm.getPersonalDataId());
				personalData.setName(personalDataForm.getName());
				personalData.setSurname(personalDataForm.getSurname());
				personalData.setEmail(personalDataForm.getEmail());
				if (personalDataForm.getPhone().isEmpty()) {
					personalData.setPhone(personalDataForm.getPhone());
				} else {
					personalData.setPhone(actorService.patronPhone() + "" + personalDataForm.getPhone());
				}
				personalData.setLinkedIn(personalDataForm.getLinkedIn());

				this.personalDataService.save(personalData);

				result = new ModelAndView("redirect:/personalData/user/list.do");
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage().equals("Usted no tiene acceso a datos personales que no son suyos")) {
					result = editModelAndView(personalDataForm, "personalData.user.error");
				} else {
					result = editModelAndView(personalDataForm, "personalData.error");
				}
			}
		}
		return result;
	}

	// Creating----------------------------------------------------------------------

	@RequestMapping(value = "/user/create", method = RequestMethod.GET)
	public ModelAndView create(final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		PersonalDataForm personalDataForm = new PersonalDataForm();
		User u = userService.findByPrincipal();

		try {
			Assert.isNull(personalDataService.personalDataPerUser(u.getId()), "No puede crear m�s de un dato personal");

			result = new ModelAndView("personalData/user/create");
			result.addObject("personalDataForm", personalDataForm);
			result.addObject("requestURI", "./personalData/user/create.do");
			return result;
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/personalData/user/list.do");
			if (oops.getLocalizedMessage().equals("No puede crear m�s de un dato personal")) {
				redirectAttrs.addFlashAttribute("message", "twoPersonalDatas.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "personalData.error");
			}
		}
		return result;
	}

	// Save create-------------------------------------------------------------------

	@RequestMapping(value = "/user/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid PersonalDataForm personalDataForm, BindingResult binding, RedirectAttributes redirectAttrs) {

		ModelAndView result;

		if (binding.hasErrors()) {
			result = createModelAndView(personalDataForm);
		} else {
			try {
				Assert.notNull(personalDataForm);

				PersonalData personalData = personalDataService.create();
				personalData.setName(personalDataForm.getName());
				personalData.setSurname(personalDataForm.getSurname());
				personalData.setEmail(personalDataForm.getEmail());
				if (personalDataForm.getPhone().isEmpty()) {
					personalData.setPhone(personalDataForm.getPhone());
				} else {
					personalData.setPhone(actorService.patronPhone() + "" + personalDataForm.getPhone());
				}
				personalData.setLinkedIn(personalDataForm.getLinkedIn());
				PersonalData saved = this.personalDataService.save(personalData);

				User u = userService.findByPrincipal();
				u.setPersonalData(saved);
				userService.save(u);

				result = new ModelAndView("redirect:/personalData/user/list.do");

			} catch (Throwable oops) {
				result = createModelAndView(personalDataForm, "personalData.error");

			}
		}
		return result;
	}

	//List per offer----------------------------------------
	@RequestMapping(value = "/company/list", method = RequestMethod.GET)
	public ModelAndView listCompany(@RequestParam("offerId") int offerId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer offer;
		offer = offerService.findOne(offerId);
		Company c = companyService.findByPrincipal();
		Collection<Offer> offers = new ArrayList<Offer>();
		offers = c.getOffers();

		try {
			Assert.isTrue(offers.contains(offer));

			Collection<PersonalData> personalData = new ArrayList<PersonalData>();

			personalData = offer.getPersonalDatas();

			result = new ModelAndView("personalData/company/list");
			result.addObject("personalData", personalData);
			result.addObject("requestURI", "personalData/comapny/list.do?offerId=" + offerId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			redirectAttrs.addFlashAttribute("message", "not.your");

		}

		return result;
	}

	// Ancilliary methods-------------------------------------------------------------
	protected ModelAndView createModelAndView(PersonalDataForm personalDataForm) {
		ModelAndView result;
		result = createModelAndView(personalDataForm, null);
		return result;
	}

	protected ModelAndView createModelAndView(PersonalDataForm personalDataForm, String message) {
		ModelAndView result;

		result = new ModelAndView("personalData/user/create");
		result.addObject("personalDataForm", personalDataForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView editModelAndView(PersonalDataForm personalDataForm) {
		ModelAndView result;
		result = editModelAndView(personalDataForm, null);
		return result;
	}

	protected ModelAndView editModelAndView(PersonalDataForm personalDataForm, String message) {
		ModelAndView result;

		result = new ModelAndView("personalData/user/edit");
		result.addObject("personalDataForm", personalDataForm);
		result.addObject("message", message);

		return result;
	}
}
