
package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Admin;
import domain.Raffle;
import domain.User;
import forms.RaffleForm;
import services.AdminService;
import services.MessageService;
import services.RaffleService;
import services.UserService;

@Controller
@RequestMapping("/raffle")
public class RaffleController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private RaffleService raffleService;

	@Autowired
	private AdminService adminService;

	@Autowired
	private UserService userService;

	@Autowired
	private MessageService messageService;

	// Constructors -----------------------------------------------------------
	public RaffleController() {
		super();
	}

	// ADMIN

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/admin/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView result;

		Admin principal = adminService.findByPrincipal();
		Collection<Raffle> raffles;

		raffles = raffleService.rafflesPerAdmin(principal.getId());

		result = new ModelAndView("raffle/admin/list");
		result.addObject("raffles", raffles);
		result.addObject("requestURI", "raffle/admin/list.do");

		return result;
	}

	// Listing active --------------------------------------------------------
	@RequestMapping(value = "/admin/listActive", method = RequestMethod.GET)
	public ModelAndView listActive() {

		ModelAndView result;

		Collection<Raffle> raffles;

		raffles = raffleService.activeRafles();

		result = new ModelAndView("raffle/admin/listActive");
		result.addObject("raffles", raffles);
		result.addObject("requestURI", "raffle/admin/listActive.do");

		return result;
	}

	// Sorteos que terminan hoy -----------------------------------------------
	@RequestMapping(value = "/admin/listToday", method = RequestMethod.GET)
	public ModelAndView listTodayRaffles() {

		ModelAndView result;

		Collection<Raffle> raffles;

		raffles = raffleService.todayRaffles();

		result = new ModelAndView("raffle/admin/listToday");
		result.addObject("raffles", raffles);
		result.addObject("requestURI", "raffle/admin/listToday.do");

		return result;
	}

	// Search ----------------------------------------------------------------

	@RequestMapping(value = "/admin/search", method = RequestMethod.GET)
	public ModelAndView listByTitle(@RequestParam("title") String title) {
		ModelAndView result;

		Collection<Raffle> raffles = new ArrayList<Raffle>();

		raffles = raffleService.rafflesPerTitle(title);

		result = new ModelAndView("raffle/admin/list");
		result.addObject("raffles", raffles);
		result.addObject("requestURI", "raffle/admin/list.do");
		return result;
	}

	// Editing ------------------------------------------------------------

	@RequestMapping(value = "/admin/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int raffleId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		RaffleForm raffleForm;
		Admin principal = adminService.findByPrincipal();
		Raffle raffle;
		Admin adminR = raffleService.adminByRaffleId(raffleId);

		try {
			Assert.isTrue(principal.equals(adminR), "Acceso denegado");
			raffle = raffleService.findOne(raffleId);

			raffleForm = new RaffleForm();
			raffleForm.setRaffleId(raffle.getId());
			raffleForm.setTitle(raffle.getTitle());
			raffleForm.setDescription(raffle.getDescription());
			raffleForm.setGift(raffle.getGift());
			raffleForm.setPicture(raffle.getPicture());
			raffleForm.setDateFinish(raffle.getDateFinish());

			result = new ModelAndView("raffle/admin/edit");
			result.addObject("raffleForm", raffleForm);
			result.addObject("requestURI", "./raffle/admin/edit.do?raffleId=" + raffleId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/raffle/admin/list.do");
			if (oops.getLocalizedMessage().equals("Acceso denegado")) {
				redirectAttrs.addFlashAttribute("message", "raffle.admin.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "raffle.error");
			}
		}

		return result;
	}

	// Save edit---------------------------------------------------------

	@RequestMapping(value = "/admin/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid RaffleForm raffleForm, BindingResult binding, RedirectAttributes redirectAttrs) {

		ModelAndView result;
		Raffle raffle;
		Admin principal = adminService.findByPrincipal();
		Admin adminR = raffleService.adminByRaffleId(raffleForm.getRaffleId());
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = editModelAndView(raffleForm);
		} else {
			try {
				Assert.notNull(raffleForm);
				Assert.isTrue(principal.equals(adminR), "Acceso denegado");
				Assert.isTrue(momento.before(raffleForm.getDateFinish()),
						"La fecha de comienzo debe ser anterior a la fecha fin");

				raffle = raffleService.findOne(raffleForm.getRaffleId());
				raffle.setTitle(raffleForm.getTitle());
				raffle.setDescription(raffleForm.getDescription());
				raffle.setGift(raffleForm.getGift());
				raffle.setPicture(raffleForm.getPicture());
				raffle.setDateFinish(raffleForm.getDateFinish());

				this.raffleService.save(raffle);

				result = new ModelAndView("redirect:/raffle/admin/list.do");
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage().equals("Acceso denegado")) {
					result = editModelAndView(raffleForm, "raffle.admin.error");
				} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result = editModelAndView(raffleForm, "raffle.date.error");
				} else {
					result = editModelAndView(raffleForm, "raffle.error");
				}
			}
		}
		return result;
	}

	// Creating----------------------------------------------------------------------

	@RequestMapping(value = "/admin/create", method = RequestMethod.GET)
	public ModelAndView create(final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		RaffleForm raffleForm = new RaffleForm();
		Admin a = adminService.findByPrincipal();

		try {
			Assert.notNull(a);
			result = new ModelAndView("raffle/admin/create");
			result.addObject("raffleForm", raffleForm);
			result.addObject("requestURI", "./raffle/admin/create.do");
			return result;
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/raffle/admin/list.do");
			redirectAttrs.addFlashAttribute("raffle", "raffle.error");
		}
		return result;
	}

	// Save
	// create-------------------------------------------------------------------

	@RequestMapping(value = "/admin/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid RaffleForm raffleForm, BindingResult binding,
			RedirectAttributes redirectAttrs) {

		ModelAndView result;
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = createModelAndView(raffleForm);
		} else {
			try {
				Assert.notNull(raffleForm);
				Assert.isTrue(momento.before(raffleForm.getDateFinish()),
						"La fecha de comienzo debe ser anterior a la fecha fin");

				Raffle raffle = raffleService.create();
				raffle.setTitle(raffleForm.getTitle());
				raffle.setDescription(raffleForm.getDescription());
				raffle.setGift(raffleForm.getGift());
				raffle.setPicture(raffleForm.getPicture());
				raffle.setDateFinish(raffleForm.getDateFinish());

				Raffle saved = this.raffleService.save(raffle);

				Admin a = adminService.findByPrincipal();
				a.getRaffles().add(saved);
				adminService.save(a);

				result = new ModelAndView("redirect:/raffle/admin/list.do");

			} catch (Throwable oops) {
				if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result = createModelAndView(raffleForm, "raffle.date.error");
				} else {
					result = createModelAndView(raffleForm, "raffle.error");
				}
			}
		}
		return result;

	}

	// Usuarios inscritos ----------------------------------------------------

	@RequestMapping(value = "/admin/inscribeUsers", method = RequestMethod.GET)
	public ModelAndView inscribeUsers(@RequestParam int raffleId) {

		ModelAndView result;

		Collection<User> users;
		Raffle r = raffleService.findOne(raffleId);
		users = r.getUsers();

		result = new ModelAndView("raffle/admin/inscribeUsers");
		result.addObject("users", users);
		result.addObject("requestURI", "raffle/admin/inscribeUsers.do");

		return result;
	}

	// Elegir ganador ------------------------------------------------------------
	@RequestMapping(value = "/admin/userWinner", method = RequestMethod.GET)
	public ModelAndView userWinner(@RequestParam int raffleId, @RequestParam String text1, @RequestParam String text2,
			@RequestParam String text3, RedirectAttributes redirectAttrs) {

		ModelAndView result;
		int aux = 0;
		int num = 0;
		Collection<User> users;
		Raffle r = raffleService.findOne(raffleId);
		users = r.getUsers();

		try {
			Assert.isTrue(!r.getClosed(), "No puede haber m�s de un ganador del sorteo");
			Assert.isTrue(raffleService.raffleActiveONo(raffleId), "momento");
		
			aux = users.size();
			Assert.isTrue(aux != 0, "Debe haber algun usuario inscrito");

			if (aux != 0) {
				num = (int) (Math.random() * aux);
			} else if (aux == 1) {
				num = 0;
			}
			User user = (User) users.toArray()[num];
			r.setClosed(true);

			String mes1 = text1;
			String mes2 = text2;
			String mes3 = text3 + " " + user.getName() + "";

			String body = mes1 + "" + r.getTitle() + "" + mes2;

			messageService.sendRaffleMessage(user, body, "HIGH", mes3);

			result = new ModelAndView("raffle/admin/userWinner");
			result.addObject("user", user);
			result.addObject("requestURI", "./raffle/admin/userWinner.do");
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/raffle/admin/listToday.do");
			if (oops.getLocalizedMessage().equals("momento")) {
				redirectAttrs.addFlashAttribute("message", "raffle.moment.error");
			} else if (oops.getLocalizedMessage().equals("No puede haber m�s de un ganador del sorteo")) {
				redirectAttrs.addFlashAttribute("message", "raffle.win.error");
			}
			else if (oops.getLocalizedMessage().equals("Debe haber algun usuario inscrito")) {
				redirectAttrs.addFlashAttribute("message", "raffle.aux.error");
			}else {
				redirectAttrs.addFlashAttribute("message", "raffle.error");
			}
		}
		return result;
	}

	// USER
	// Listing
	// ----------------------------------------------------------------------

	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView listUser() {

		ModelAndView result;

		Collection<Raffle> raffles;

		raffles = raffleService.activeRafles();

		result = new ModelAndView("raffle/user/list");
		result.addObject("raffles", raffles);
		result.addObject("requestURI", "raffle/user/list.do");

		return result;
	}

	// Inscribirse
	// -------------------------------------------------------------------
	@RequestMapping(value = "/user/inscribe", method = RequestMethod.GET)
	public ModelAndView subscribe(@RequestParam int raffleId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Raffle res;
		res = raffleService.findOne(raffleId);
		User principal = userService.findByPrincipal();
		Date momento = new Date(System.currentTimeMillis() - 1000);

		try {
			Assert.isTrue(!(res.getUsers().contains(principal)), "Usted ya esta inscrito a este sorteo");
			Assert.isTrue(res.getDateFinish().after(momento), "momento");
			raffleService.inscribe(res, principal.getId());
			result = new ModelAndView("redirect:/raffle/user/list.do");

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/raffle/user/list.do");
			if (oops.getLocalizedMessage().equals("momento")) {
				redirectAttrs.addFlashAttribute("message", "raffle.momenterror");
			} else if (oops.getLocalizedMessage().equals("Usted ya esta inscrito a este sorteo")) {
				redirectAttrs.addFlashAttribute("message", "raffle.user.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "raffle.error");
			}
		}
		return result;
	}

	// Ancilliary
	// methods-------------------------------------------------------------
	protected ModelAndView createModelAndView(RaffleForm raffleForm) {
		ModelAndView result;
		result = createModelAndView(raffleForm, null);
		return result;
	}

	protected ModelAndView createModelAndView(RaffleForm raffleForm, String message) {
		ModelAndView result;

		result = new ModelAndView("raffle/admin/create");
		result.addObject("raffleForm", raffleForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView editModelAndView(RaffleForm raffleForm) {
		ModelAndView result;
		result = editModelAndView(raffleForm, null);
		return result;
	}

	protected ModelAndView editModelAndView(RaffleForm raffleForm, String message) {
		ModelAndView result;

		result = new ModelAndView("raffle/admin/edit");
		result.addObject("raffleForm", raffleForm);
		result.addObject("message", message);

		return result;
	}
}
