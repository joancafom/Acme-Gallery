
package controllers;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import domain.Basket;
import domain.BuyStore;
import domain.Company;
import domain.Item;
import domain.Merchant;
import domain.Sponsor;
import domain.User;
import forms.CompanyForm;
import forms.SponsorForm;
import forms.UserForm;
import security.Authority;
import security.UserAccount;
import services.ActorService;
import services.BasketService;
import services.BuyStoreService;
import services.CompanyService;
import services.MerchantService;
import services.SponsorService;
import services.UserService;

@Controller
@RequestMapping("/security")
public class RegisterController extends AbstractController {

	@Autowired
	private ActorService actorService;

	@Autowired
	private UserService userService;

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private SponsorService sponsorService;

	@Autowired
	private BasketService basketService;

	@Autowired
	private BuyStoreService buyStoreService;


	// RegisterUser ---------------------------------------------------------------
	//GET--------------------------------------------------------------
	@RequestMapping(value = "/registerUser", method = RequestMethod.GET)
	public ModelAndView registerUser() {
		ModelAndView result;
		UserForm userForm;

		userForm = new UserForm();
		result = createEditModelAndViewUser(userForm);

		return result;
	}

	//POST-----------------------------------------------------------------
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST, params = "saveUser")
	public ModelAndView saveUser(@Valid UserForm userForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = createEditModelAndViewUser(userForm);
		else if (!userForm.getTerms())
			result = createEditModelAndViewUser(userForm, "security.acceptterm");
		else if (actorService.findEqualsUsername(userForm.getUsername()) > 0)
			result = createEditModelAndViewUser(userForm, "security.usernameError");
		else if (actorService.findEqualsEmail(userForm.getEmail()) > 0)
			result = createEditModelAndViewUser(userForm, "security.emailError");
		else if (!userForm.getPassword().equals(userForm.getConfPassword()))
			result = createEditModelAndViewUser(userForm, "security.errorpassword");
		else
			try {
				User u = userService.create();
				u.setName(userForm.getName());
				u.setSurname(userForm.getSurname());
				u.setEmail(userForm.getEmail());
				u.setPhone(userForm.getPhone());
				u.setAddress(userForm.getAddress());
				u.setPostalAddress(userForm.getPostalAddress());
				u.setProfession(userForm.getProfession());
				u.setPro(false);
				Basket b = new Basket();
				Collection<Item> items = new HashSet<Item>();
				b.setItems(items);
				b.setDate(new Date(System.currentTimeMillis() - 1000));
				b.setTotal(0.0);
				Basket bb = basketService.save(b);
				u.setBasket(bb);
				BuyStore buyS = new BuyStore();
				buyS.setItems(items);
				BuyStore buySS = buyStoreService.save(buyS);
				u.setBuyStore(buySS);

				// UserAccount --------------------------------------------
				Authority auth = new Authority();
				auth.setAuthority(Authority.USER);
				UserAccount userAccount = new UserAccount();
				userAccount.setUsername(userForm.getUsername());
				Md5PasswordEncoder encoder = new Md5PasswordEncoder();
				userAccount.setPassword(encoder.encodePassword(userForm.getPassword(), null));
				userAccount.getAuthorities().add(auth);
				userAccount.setBanned(true);
				u.setUserAccount(userAccount);
				userService.save(u);

				result = new ModelAndView("redirect:/security/login.do");

			} catch (Throwable oops) {
				result = createEditModelAndViewUser(userForm, "security.error");
			}

		return result;
	}

	// RegisterCustomer ---------------------------------------------------------------
	@RequestMapping(value = "/registerCompany", method = RequestMethod.GET)
	public ModelAndView registerCompany() {
		ModelAndView result;
		CompanyForm companyForm;

		companyForm = new CompanyForm();
		result = createEditModelAndViewCompany(companyForm);

		return result;
	}

	//POST-----------------------------------------------------------------
	@RequestMapping(value = "/registerCompany", method = RequestMethod.POST, params = "saveCompany")
	public ModelAndView saveCompany(@Valid CompanyForm companyForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = createEditModelAndViewCompany(companyForm);
		else if (!companyForm.getTerms())
			result = createEditModelAndViewCompany(companyForm, "security.acceptterm");
		else if (actorService.findEqualsUsername(companyForm.getUsername()) > 0)
			result = createEditModelAndViewCompany(companyForm, "security.usernameError");
		else if (actorService.findEqualsEmail(companyForm.getEmail()) > 0)
			result = createEditModelAndViewCompany(companyForm, "security.emailError");
		else if (!companyForm.getPassword().equals(companyForm.getConfPassword()))
			result = createEditModelAndViewCompany(companyForm, "security.errorpassword");
		else
			try {
				Company u = companyService.create();
				u.setName(companyForm.getName());
				u.setEmail(companyForm.getEmail());
				u.setPhone(companyForm.getPhone());
				u.setAddress(companyForm.getAddress());
				u.setPostalAddress(companyForm.getPostalAddress());
				u.setPro(false);

				// UserAccount --------------------------------------------
				Authority auth = new Authority();
				auth.setAuthority(Authority.COMPANY);
				UserAccount userAccount = new UserAccount();
				userAccount.setUsername(companyForm.getUsername());
				Md5PasswordEncoder encoder = new Md5PasswordEncoder();
				userAccount.setPassword(encoder.encodePassword(companyForm.getPassword(), null));
				userAccount.getAuthorities().add(auth);
				u.setUserAccount(userAccount);
				userAccount.setBanned(true);
				companyService.save(u);

				result = new ModelAndView("redirect:/security/login.do");

			} catch (Throwable oops) {
				result = createEditModelAndViewCompany(companyForm, "security.error");
			}

		return result;
	}

	// RegisterSponsor ---------------------------------------------------------------
	@RequestMapping(value = "/registerSponsor", method = RequestMethod.GET)
	public ModelAndView registerSponsor() {
		ModelAndView result;
		SponsorForm sponsorForm;

		sponsorForm = new SponsorForm();
		result = createEditModelAndViewSponsor(sponsorForm);

		return result;
	}

	//POST-----------------------------------------------------------------
	@RequestMapping(value = "/registerSponsor", method = RequestMethod.POST, params = "saveSponsor")
	public ModelAndView saveSponsor(@Valid SponsorForm sponsorForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = createEditModelAndViewSponsor(sponsorForm);
		else if (!sponsorForm.getTerms())
			result = createEditModelAndViewSponsor(sponsorForm, "security.acceptterm");
		else if (actorService.findEqualsUsername(sponsorForm.getUsername()) > 0)
			result = createEditModelAndViewSponsor(sponsorForm, "security.usernameError");
		else if (actorService.findEqualsEmail(sponsorForm.getEmail()) > 0)
			result = createEditModelAndViewSponsor(sponsorForm, "security.emailError");
		else if (!sponsorForm.getPassword().equals(sponsorForm.getConfPassword()))
			result = createEditModelAndViewSponsor(sponsorForm, "security.errorpassword");
		else
			try {
				Sponsor u = sponsorService.create();
				u.setName(sponsorForm.getName());
				u.setEmail(sponsorForm.getEmail());
				u.setPhone(sponsorForm.getPhone());
				u.setAddress(sponsorForm.getAddress());
				u.setPostalAddress(sponsorForm.getPostalAddress());

				Basket b = new Basket();
				Collection<Item> items = new HashSet<Item>();
				b.setItems(items);
				b.setDate(new Date(System.currentTimeMillis() - 1000));
				b.setTotal(0.0);
				Basket bb = basketService.save(b);
				u.setBasket(bb);

				BuyStore buyS = new BuyStore();
				buyS.setItems(items);
				BuyStore buySS = buyStoreService.save(buyS);
				u.setBuyStore(buySS);

				// UserAccount --------------------------------------------
				Authority auth = new Authority();
				auth.setAuthority(Authority.SPONSOR);
				UserAccount userAccount = new UserAccount();
				userAccount.setUsername(sponsorForm.getUsername());
				Md5PasswordEncoder encoder = new Md5PasswordEncoder();
				userAccount.setPassword(encoder.encodePassword(sponsorForm.getPassword(), null));
				userAccount.getAuthorities().add(auth);
				u.setUserAccount(userAccount);
				userAccount.setBanned(true);
				sponsorService.save(u);

				result = new ModelAndView("redirect:/security/login.do");

			} catch (Throwable oops) {
				result = createEditModelAndViewSponsor(sponsorForm, "security.error");
			}

		return result;
	}

	//POST-----------------------------------------------------------------
	@RequestMapping(value = "/registerMerchant", method = RequestMethod.POST, params = "saveMerchant")
	public ModelAndView saveMerchant(@Valid SponsorForm sponsorForm, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = createEditModelAndViewMerchant(sponsorForm);
		else if (!sponsorForm.getTerms())
			result = createEditModelAndViewMerchant(sponsorForm, "security.acceptterm");
		else if (actorService.findEqualsUsername(sponsorForm.getUsername()) > 0)
			result = createEditModelAndViewMerchant(sponsorForm, "security.usernameError");
		else if (actorService.findEqualsEmail(sponsorForm.getEmail()) > 0)
			result = createEditModelAndViewMerchant(sponsorForm, "security.emailError");
		else if (!sponsorForm.getPassword().equals(sponsorForm.getConfPassword()))
			result = createEditModelAndViewMerchant(sponsorForm, "security.errorpassword");
		else
			try {
				Merchant u = merchantService.create();
				u.setName(sponsorForm.getName());
				u.setEmail(sponsorForm.getEmail());
				u.setPhone(sponsorForm.getPhone());
				u.setAddress(sponsorForm.getAddress());
				u.setPostalAddress(sponsorForm.getPostalAddress());

				// UserAccount --------------------------------------------
				Authority auth = new Authority();
				auth.setAuthority(Authority.MERCHANT);
				UserAccount userAccount = new UserAccount();
				userAccount.setUsername(sponsorForm.getUsername());
				Md5PasswordEncoder encoder = new Md5PasswordEncoder();
				userAccount.setPassword(encoder.encodePassword(sponsorForm.getPassword(), null));
				userAccount.getAuthorities().add(auth);
				u.setUserAccount(userAccount);
				userAccount.setBanned(true);
				merchantService.save(u);

				result = new ModelAndView("redirect:/security/login.do");

			} catch (Throwable oops) {
				result = createEditModelAndViewMerchant(sponsorForm, "security.error");
			}

		return result;
	}

	// RegisterSponsor ---------------------------------------------------------------
	//Utilizo el formulario de Sponsor por compatibilidad de atributos
	@RequestMapping(value = "/registerMerchant", method = RequestMethod.GET)
	public ModelAndView registerMerchant() {
		ModelAndView result;
		SponsorForm sponsorForm;

		sponsorForm = new SponsorForm();
		result = createEditModelAndViewMerchant(sponsorForm);

		return result;
	}

	//---------------------------------------------------------------------------
	//---------------------------------------------------------------------------
	//---------------------------------------------------------------------------

	protected ModelAndView createEditModelAndViewUser(UserForm userForm) {
		ModelAndView result;
		result = createEditModelAndViewUser(userForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewUser(UserForm userForm, String message) {
		ModelAndView result;

		result = new ModelAndView("security/registerUser");
		result.addObject("userForm", userForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewCompany(CompanyForm companyForm) {
		ModelAndView result;
		result = createEditModelAndViewCompany(companyForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewCompany(CompanyForm companyForm, String message) {
		ModelAndView result;

		result = new ModelAndView("security/registerCompany");
		result.addObject("companyForm", companyForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewSponsor(SponsorForm sponsorForm) {
		ModelAndView result;
		result = createEditModelAndViewSponsor(sponsorForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewSponsor(SponsorForm sponsorForm, String message) {
		ModelAndView result;

		result = new ModelAndView("security/registerSponsor");
		result.addObject("sponsorForm", sponsorForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewMerchant(SponsorForm sponsorForm) {
		ModelAndView result;
		result = createEditModelAndViewMerchant(sponsorForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewMerchant(SponsorForm sponsorForm, String message) {
		ModelAndView result;

		result = new ModelAndView("security/registerMerchant");
		result.addObject("sponsorForm", sponsorForm);
		result.addObject("message", message);

		return result;
	}

}
