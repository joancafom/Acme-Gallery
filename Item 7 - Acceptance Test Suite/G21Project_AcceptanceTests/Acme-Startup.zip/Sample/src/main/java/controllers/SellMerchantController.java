package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Item;
import domain.Merchant;
import domain.Sell;
import services.ItemService;
import services.MerchantService;
import services.SellService;

@Controller
@RequestMapping("/sell/merchant")
public class SellMerchantController extends AbstractController {

	@Autowired
	private SellService sellService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private ItemService itemService;
	
	public SellMerchantController() {
		super();
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Merchant merchant;
		Collection<Sell> sells;
		
		merchant = this.merchantService.findByPrincipal();
		
		sells = this.sellService.findSellsByMerchant(merchant.getId());
		
		result = new ModelAndView("sell/list");
		result.addObject("requestURI", "sell/merchant/list.do");
		result.addObject("baseURI", "sell/merchant/");
		result.addObject("sells", sells);

		return result;
	}
	
	@RequestMapping(value = "/close", method = RequestMethod.GET)
	public ModelAndView close(@RequestParam final int sellId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Merchant merchant;
		Sell sell;
		
		try {
			merchant = this.merchantService.findByPrincipal();
			Assert.notNull(merchant, "No tienes permisos");
			
			sell = this.sellService.findOne(sellId);
			Assert.notNull(sell, "Este sell no existe");
			Assert.isTrue(merchant.getSells().contains(sell), "No eres el propietario de esta venta");
			sell.setClosed(true);
			
			this.sellService.saveSell(sell);
			
			result = new ModelAndView("redirect:/sell/merchant/list.do");
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/sell/merchant/list.do");
			String message;
			
			if (oops.getLocalizedMessage().equals("No tienes permisos")) {
				message = "sell.permissions";
			} else if (oops.getLocalizedMessage().equals("Este sell no existe")) {
				message = "sell.empty";
			} else if (oops.getLocalizedMessage().equals("No eres el propietario de esta venta")) {
				message = "sell.property";
			} else {
				message = "sell.error";
			}
			redirectAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
	
	@RequestMapping(value = "/condition", method = RequestMethod.GET)
	public ModelAndView condition(@RequestParam final boolean condition) {
		ModelAndView result;
		Collection<Sell> sells;
		Merchant merchant;
		
		merchant = this.merchantService.findByPrincipal();
		
		sells = this.sellService.findSellsByMerchantAndCondition(merchant.getId(), condition);
		
		result = new ModelAndView("sell/list");
		result.addObject("requestURI", "sell/merchant/condition.do?condition=" + condition);
		result.addObject("baseURI", "sell/merchant/");
		result.addObject("sells", sells);
		
		return result;
	}
	
	@RequestMapping(value = "/condition", method = RequestMethod.POST)
	public ModelAndView saveCondition(@RequestParam boolean condition) {
		
		return new ModelAndView("redirect:/sell/merchant/condition.do?condition=" + condition);
	}
	
	@RequestMapping(value = "/items", method = RequestMethod.GET)
	public ModelAndView items(@RequestParam final int sellId, RedirectAttributes redirAttrs) {
		ModelAndView result;
		Merchant merchant;
		Sell sell;
		Collection<Item> items;
		
		try {
			merchant = this.merchantService.findByPrincipal();
			
			sell = this.sellService.findOne(sellId);
			Assert.isTrue(merchant.getSells().contains(sell), "No puedes realizar esta acci�n.");
			
			items = this.itemService.findAllItemsBySell(sellId);
			
			result = new ModelAndView("item/list");
			result.addObject("requestURI", "item/");
			result.addObject("baseURI", "sell/merchant/");
			result.addObject("items", items);
		} catch (Throwable oops) {
			String message;
			result = new ModelAndView("redirect:/sell/merchant/list.do");
			
			if (oops.getLocalizedMessage().equals("No puedes realizar esta acci�n.")) {
				message = "sell.permissions";
			} else {
				message = "sell.error";
			}
			redirAttrs.addFlashAttribute("message", message);
		}
		return result;
	}
}
