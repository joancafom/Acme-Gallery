
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Spam;
import forms.SpamForm;
import services.SpamService;

@Controller
@RequestMapping("/spam")
public class SpamController extends AbstractController {

	@Autowired
	private SpamService spamService;


	// Constructors -----------------------------------------------------------
	public SpamController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Spam> tabs;

		tabs = spamService.findAll();
		result = new ModelAndView("spam/list");
		result.addObject("spamForm", tabs);
		result.addObject("requestURI", "spam/list.do");

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("spamId") int spamId) {
		ModelAndView result;
		Spam spam;

		spam = spamService.findOne(spamId);
		result = new ModelAndView("spam/edit");
		result.addObject("spamForm", spam);
		result.addObject("requestURI", "spam/edit.do?spamId=" + spam);
		result.addObject("URI", "spam/list.do");

		return result;
	}



	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid SpamForm spamForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		
		Collection<Spam> res = spamService.findKeyWord(spamForm.getName());
		if (binding.hasErrors()) {
			result = createEditModelAndView(spamForm);

		}else {
			

		try{
			
			if(!res.isEmpty()){
				
				Assert.isTrue(false);
			}
			Spam tw = spamService.findOne(spamForm.getId());
			tw.setName(spamForm.getName());
			tw = spamService.save(tw);
			result= new ModelAndView("redirect:/spam/list.do");
		}catch (Throwable oops){
			if(!res.isEmpty()){
				result = new ModelAndView("redirect:/spam/list.do");
				redirectAttrs.addFlashAttribute("message", "tabooWord.commit.errorName");
			}else{
				result= createEditModelAndView(spamForm, "tabooWord.commit.error");
			}
			}
		}
		return result;

	}

	
	//Creation --------------------------------------
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;

		Spam t;
		t = spamService.create();
		SpamForm res = new SpamForm();
		res.setId(t.getId());
		result = createEditModelAndView(res);
		result.addObject("spamForm", res);

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid SpamForm spamForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		//boolean aux=false;
		Collection<Spam> res = spamService.findKeyWord(spamForm.getName());
		
		if (binding.hasErrors()) {
			result = createEditModelAndView(spamForm);

		}else {
			

		try{
			
			if(!res.isEmpty()){
				
				Assert.isTrue(false);
			}
			Spam tw = spamService.create();
			tw.setName(spamForm.getName());
			spamService.save(tw);
			result= new ModelAndView("redirect:/spam/list.do");
		}catch (Throwable oops){
			
			if(!res.isEmpty()){
				result = new ModelAndView("redirect:/spam/list.do");
				redirectAttrs.addFlashAttribute("message", "tabooWord.commit.errorName");
			}else{
				result= createEditModelAndView(spamForm, "tabooWord.commit.error");
			}
		}
		}
			
		return result;
	}

	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(SpamForm spamForm) {
		ModelAndView result;
		result = createEditModelAndView(spamForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(SpamForm spamForm, String message) {
		ModelAndView result;

		result = new ModelAndView("spam/edit");
		result.addObject("spamForm", spamForm);
		result.addObject("message", message);

		return result;
	}

}
