package controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Category;
import domain.Company;
import domain.Cooperate;
import domain.News;
import domain.Offer;
import domain.Startup;
import domain.Tag;
import domain.User;
import forms.StartupForm;
import services.CategoryService;
import services.CompanyService;
import services.StartupService;
import services.UserService;

@Controller
@RequestMapping("/startup")
public class StartupController extends AbstractController  {
	
	// Services ---------------------------------------------------------------
	@Autowired
	private StartupService startupService;

	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CategoryService categoryService;


	// Constructors -----------------------------------------------------------
	public StartupController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Startup> startups = new ArrayList<Startup>();
		Collection<Category> categories = categoryService.findAll();
		startups = startupService.findAll();

		result = new ModelAndView("startup/list");
		result.addObject("categories", categories);
		result.addObject("startups", startups);
		result.addObject("requestURI", "startup/list.do");

		return result;
	}
	
	
	
	// keyword----------------------------------------------------
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView listByKeyWord(@RequestParam("keyword") String keyword) {
		ModelAndView result;

		Collection<Startup> startups= new ArrayList<Startup>();
		Collection<Category> categories = categoryService.findAll();

		startups = startupService.startupPerKeyWord(keyword);

		result = new ModelAndView("startup/list");
		result.addObject("categories", categories);
		result.addObject("startups", startups);
		result.addObject("requestURI", "startup/list.do");
		return result;
	}
	
	
	
	@RequestMapping(value = "/group", method = RequestMethod.GET, params = "categoryId")
	public ModelAndView groupList(@RequestParam(value = "categoryId", defaultValue = "") int categoryId) {
		ModelAndView result;
		Collection<Startup> startups = new ArrayList<Startup>();
		Collection<Category> categories = categoryService.findAll();

		startups=startupService.startupsPerCategory(categoryId);
		
		result = new ModelAndView("startup/list");

		result.addObject("categories", categories);
		result.addObject("startups", startups);
		result.addObject("requestURI", "startup/list.do");

		return result;
	}	
	
	

	
	//Listado de las creadas por un company-----------------------------
	@RequestMapping(value = "/company/list", method = RequestMethod.GET)
	public ModelAndView listMy() {
		Company c = companyService.findByPrincipal();

		ModelAndView result;
		Collection<Startup> startups = new ArrayList<Startup>();
		Collection<Category> categories = categoryService.findAll();
		
		startups = c.getStartups();
		result = new ModelAndView("startup/company/list");
		result.addObject("categories", categories);
		result.addObject("startups", startups);
		result.addObject("requestURI", "startup/company/list.do");

		return result;
	}
	
	
	
	// Creating ----------------------------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.GET)
	public ModelAndView create(final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		result = new ModelAndView("startup/company/create");

		Company c = companyService.findByPrincipal();
		try {
			Assert.notNull(c);
			
			Startup res = startupService.create();
			StartupForm startupForm = new StartupForm ();
			startupForm.setId(res.getId());

			Collection<Category> categories = categoryService.findAll();

			result.addObject("startupForm", startupForm);
			result.addObject("categories", categories);
			result.addObject("requestURI", "./startup/company/create.do");

		} catch (Throwable oops) {
			if (c.equals(null)) {
				result = new ModelAndView("redirect:/startup/list.do");
				redirectAttrs.addFlashAttribute("message", "startup.error.company");			}
		}
		
		return result;
	}
	
	
	//Save create-----------------------------------------------
	@RequestMapping(value = "/company/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid StartupForm startupForm, BindingResult binding) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createEditModelAndView(startupForm);
		} else {
			try {
				Assert.notNull(c);

				Startup res = new Startup();

				Collection<Tag> tags = new ArrayList<Tag>();
				Collection<Offer> offers= new ArrayList<Offer>();
				Collection<Cooperate> cooperates= new ArrayList<Cooperate>();
				Collection<News> news= new ArrayList<News>();
				Date momento = new Date(System.currentTimeMillis() - 1000);

				res.setTags(tags);
				res.setOffers(offers);
				res.setCooperates(cooperates);
				res.setNews(news);
				res.setName(startupForm.getName());
				res.setCategory(categoryService.findOne(startupForm.getCategoryId()));
				res.setEnterprisePage(startupForm.getEnterprisePage());
				res.setDescription(startupForm.getDescription());
				res.setCreationDate(momento);

				res = startupService.save(res);

				result = new ModelAndView("redirect:/startup/company/list.do");
			} catch (Throwable oops) {
				if (c.equals(null)) {
					result = createEditModelAndView(startupForm, "startup.error.company");

				} else {
					result = createEditModelAndView(startupForm, "startup.commit.error");
				}
			}
		}
		return result;
	}	
	
	// Modify------------------------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("startupId") int startupId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		StartupForm startupForm = new StartupForm();
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();

		try {
			Assert.isTrue(startups.contains(startupService.findOne(startupId)));
			
			Collection<Category> categories = new ArrayList<Category>();
			categories = categoryService.findAll();
			Startup res =startupService.findOne(startupId);
			
			startupForm.setDescription(res.getDescription());
			startupForm.setName(res.getName());
			startupForm.setEnterprisePage(res.getEnterprisePage());
			startupForm.setId(res.getId());
			startupForm.setCategoryId(res.getCategory().getId());
			
			result = new ModelAndView("startup/company/edit");

			result.addObject("startupForm", startupForm);
			result.addObject("categories", categories);
			result.addObject("requestURI", "startup/company/edit.do?startupId=" + startupId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(startups.contains(startupService.findOne(startupId)))) {
				redirectAttrs.addFlashAttribute("message", "startup.commit.notYour");
			} else {
				result = createEditModelAndView(startupForm, "startup.commit.error");
			}

		}

		return result;
	}		

	
	
	//Save edit---------------------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid StartupForm startupForm, BindingResult binding) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		
		if (binding.hasErrors()) {
			result = createEditModelAndView(startupForm);

		} else {
			try {
				Assert.isTrue(startups.contains(startupService.findOne(startupForm.getId())));

				Startup res =startupService.findOne(startupForm.getId());
				
				res.setCategory(categoryService.findOne(startupForm.getCategoryId()));
				res.setName(startupForm.getName());
				res.setDescription(startupForm.getDescription());
				res.setEnterprisePage(startupForm.getEnterprisePage());

				startupService.save(res);
				result = new ModelAndView("redirect:/startup/company/list.do");
			} catch (Throwable oops) {
				if(!(startups.contains(startupService.findOne(startupForm.getId())))){
					result = createEditModelAndView(startupForm, "startup.commit.notYour");
				}else{
					result = createEditModelAndView(startupForm, "startup.commit.error");

				}
			}
		}
		return result;
	}
	
	
	// Delete----------------------------------------------
	@RequestMapping(value = "/company/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid StartupForm startupForm, BindingResult binding) {
		ModelAndView result;
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Startup res;
		res = startupService.findOne(startupForm.getId());


		if (binding.hasErrors()) {
			result = createEditModelAndView(startupForm);
		} else {
			try {

				Assert.isTrue(startups.contains(res));
	
				startupService.delete(res);
				result = new ModelAndView("redirect:/startup/company/list.do");
			} catch (Throwable oops) {
				if(!(startups.contains(res))){
					result = createEditModelAndView(startupForm, "startup.commit.notYour");
				}else{
					result = createEditModelAndView(startupForm, "startup.commit.error");
	
				}
			}
		
	}
		return result;
	}	
	
	
	
	//Listado de las seguidas por un usuario-----------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView listFollowed() {
		User u = userService.findByPrincipal();

		ModelAndView result;
		Collection<Startup> startups = new ArrayList<Startup>();
		
		startups = u.getStartups();
		result = new ModelAndView("startup/user/list");
		result.addObject("startups", startups);
		result.addObject("requestURI", "startup/user/list.do");

		return result;
	}	
	
	
	
	// Usuario subscribirse a una startup----------------------------------------------
	@RequestMapping(value = "/user/subscribe", method = RequestMethod.GET)
	public ModelAndView subscribe(@RequestParam int startupId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup res;
		//Assert.isNull(null);
		res = startupService.findOne(startupId);
		User u = userService.findByPrincipal();
		Collection<Startup> startups= new ArrayList<Startup>();
		startups=u.getStartups();
		
		try {
			Assert.isTrue(!(startups.contains(res)));
			//startupService.subscribe(res, u.getId());
			result = new ModelAndView("redirect:/startup/list.do");

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/list.do");
			if(startups.contains(res)){
				redirectAttrs.addFlashAttribute("message", "startup.subscribe.error");
			}else{
				redirectAttrs.addFlashAttribute("message", "startup.commit.error");

				}
			}
		return result;
	}	
	
	
	// Usuario subscribirse a una startup----------------------------------------------
	@RequestMapping(value = "/user/unSubscribe", method = RequestMethod.GET)
	public ModelAndView unSubscribe(@RequestParam int startupId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup res;
		res = startupService.findOne(startupId);
		User u = userService.findByPrincipal();
		Collection<Startup> startups= new ArrayList<Startup>();
		startups=u.getStartups();
		
		try {
			Assert.isTrue((startups.contains(res)));
			startupService.unSubscribe(res, u.getId());
			result = new ModelAndView("redirect:/startup/user/list.do");

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/list.do");
			if(!(startups.contains(res))){
				redirectAttrs.addFlashAttribute("message", "startup.unSubscribe.error");
			}else{
				redirectAttrs.addFlashAttribute("message", "startup.commit.error");

				}
			}
		return result;
	}	
	
	
	
	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(StartupForm startupForm) {
		ModelAndView result;
		result = createEditModelAndView(startupForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(StartupForm  startupForm, String message) {
		ModelAndView result;
		Collection<Category> categories = categoryService.findAll();
		
		if(startupForm.getId()==0){
			result = new ModelAndView("startup/company/create");

		}else{
			result = new ModelAndView("startup/company/edit");

		}
		result.addObject("startupForm", startupForm);
		result.addObject("message", message);
		result.addObject("categories", categories);

		return result;
	}
}
