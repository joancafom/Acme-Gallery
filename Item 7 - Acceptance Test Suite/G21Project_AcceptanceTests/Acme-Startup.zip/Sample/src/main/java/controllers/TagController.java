
package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.Company;
import domain.Offer;
import domain.Startup;
import domain.Tag;
import forms.TagForm;
import services.CompanyService;
import services.OfferService;
import services.StartupService;
import services.TagService;

@Controller
@RequestMapping("/tag")
public class TagController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private TagService tagService;
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private CompanyService companyService;


	// Constructors -----------------------------------------------------------
	public TagController() {
		super();
	}
	



	// ADMIN------------------------

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/admin/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Tag> tags;

		tags = tagService.findAll();

		result = new ModelAndView("tag/admin/list");
		result.addObject("tags", tags);
		result.addObject("requestURI", "tag/admin/list.do");

		return result;
	}

	@RequestMapping(value = "/admin/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam("tagId") int tagId) {
		ModelAndView result;

		Tag tag;

		tag = tagService.findOne(tagId);
		TagForm tagForm = new TagForm();
		tagForm.setId(tag.getId());
		tagForm.setName(tag.getName());

		result = new ModelAndView("tag/admin/edit");
		result.addObject("tagForm", tagForm);
		result.addObject("requestURI", "tag/admin/edit.do?tagId=" + tagId);

		return result;
	}

	// Delete tag---------------------------------------------------------
	@RequestMapping(value = "/admin/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid TagForm tagForm, BindingResult binding) {
		ModelAndView result;
		Tag t = tagService.findOne(tagForm.getId());
		if (binding.hasErrors()) {
			result = createEditModelAndView(tagForm);

		} else if (StringUtils.isBlank(tagForm.getName())) {
			result = createEditModelAndView(tagForm, "tag.commit.errorEmpty");
		} else {
			try {
				tagService.delete(t);
				result = new ModelAndView("redirect:/tag/admin/list.do");

			} catch (Throwable oops) {
				result = createEditModelAndView(tagForm, "tag.commit.error");
			}
		}
		return result;
	}

	// Creation --------------------------------------
	@RequestMapping(value = "/admin/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;

		TagForm tagForm = new TagForm();
		Tag t;
		t = tagService.create();
		tagForm.setId(t.getId());
		tagForm.setName(t.getName());

		result = new ModelAndView("tag/admin/create");
		result.addObject("tagForm", tagForm);

		return result;
	}

	@RequestMapping(value = "/admin/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid TagForm tagForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;

		Collection<Tag> tags = new ArrayList<Tag>();
		tags = tagService.findAll();
		boolean aux = false;

		if (binding.hasErrors()) {
			result = createEditModelAndViewCreate(tagForm);
		} else if (StringUtils.isBlank(tagForm.getName())) {
			result = createEditModelAndViewCreate(tagForm, "tag.commit.errorEmpty");
		} else {
			try {

				for (Tag t : tags) {
					if (tagForm.getId() != t.getId()) {
						aux = true;
						Assert.isTrue(tagForm.getName() != t.getName());
					}
				}

				Tag res = new Tag();
				res.setName(tagForm.getName());

				res = tagService.save(res);
				result = new ModelAndView("redirect:/tag/admin/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndViewCreate(tagForm, "tag.commit.error");
				if (aux == true) {
					result = new ModelAndView("redirect:/tag/admin/list.do");
					redirectAttrs.addFlashAttribute("message", "tag.commit.errorName");

				}

			}
		}

		return result;
	}

	// Save modify---------------------------------------------
	@RequestMapping(value = "/admin/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid TagForm tagForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Tag tag = tagService.findOne(tagForm.getId());
		

		Collection<Tag> tags = new ArrayList<Tag>();
		tags = tagService.findAll();
		boolean aux = false;

		if (binding.hasErrors()) {
			result = createEditModelAndView(tagForm);

		} else if (StringUtils.isBlank(tagForm.getName())) {
			result = createEditModelAndView(tagForm, "tag.commit.errorEmpty");
		} else {
			try {
				
				for (Tag t : tags) {
					if (tagForm.getId() != t.getId()) {
						if (tagForm.getName().equals(t.getName())) {
							aux = true;
							Assert.isTrue(tagForm.getName() != t.getName());
						}
					}
				}

				tag.setName(tagForm.getName());
				tagService.save(tag);
				result = new ModelAndView("redirect:/tag/admin/list.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(tagForm, "tag.error");
				 if (aux == true) {
					result = new ModelAndView("redirect:/tag/admin/list.do");
					redirectAttrs.addFlashAttribute("message", "tag.commit.errorName");
				}
			}
		}
		return result;
	}
	
	
	
	
	
	//List startup----------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView listStartup(@RequestParam("startupId") int startupId) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(startupId);
		Collection<Tag> tags= new ArrayList<Tag>();

		tags = startup.getTags();

		result = new ModelAndView("tag/admin/list");
		result.addObject("tags", tags);

		return result;
	}
	
	
	//List offer----------------------------------------
	@RequestMapping(value = "/lista", method = RequestMethod.GET)
	public ModelAndView listOffer(@RequestParam("offerId") int offerId) {
		ModelAndView result;
		Offer offer;
		offer = offerService.findOne(offerId);
		Collection<Tag> tags= new ArrayList<Tag>();

		tags = offer.getTags();

		result = new ModelAndView("tag/admin/list");
		result.addObject("tags", tags);

		return result;
	}	
	
	
	
	
	
	//List company----------------------------------------
	@RequestMapping(value = "/company/addList", method = RequestMethod.GET)
	public ModelAndView listAdd(@RequestParam("objectId") int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		boolean aux=true;
		boolean ole=true;

		try {
			Assert.isTrue(startups.contains(startup));

			Collection<Tag> tagsAux= new ArrayList<Tag>();
			tagsAux = startup.getTags();
			
			Collection<Tag> tags= new ArrayList<Tag>();
			tags=tagService.findAll();
			
			tags.removeAll(tagsAux);

			result = new ModelAndView("tag/company/add");
			result.addObject("tags", tags);
			result.addObject("objectId", objectId);
			result.addObject("aux", aux);
			result.addObject("ole", ole);
			result.addObject("requestURI", "tag/company/addList.do?objectId=" + objectId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour");
			} else {
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");
			}
		}
		return result;
	}
	
	
	
	
	//List company----------------------------------------
	@RequestMapping(value = "/company/removeList", method = RequestMethod.GET)
	public ModelAndView listRemove(@RequestParam("objectId") int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		boolean aux=false;
		boolean ole=true;

		try {
			Assert.isTrue(startups.contains(startup));

			Collection<Tag> tags= new ArrayList<Tag>();
			tags=startup.getTags();
			
			result = new ModelAndView("tag/company/add");
			result.addObject("tags", tags);
			result.addObject("objectId", objectId);
			result.addObject("aux", aux);
			result.addObject("ole", ole);
			result.addObject("requestURI", "tag/company/removeList.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour");
			} else {
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");
			}
		}
		return result;
	}	
	
	// Company a�ade la tag----------------------------------------------
	@RequestMapping(value = "/company/add", method = RequestMethod.GET)
	public ModelAndView addTag(@RequestParam int tagId,@RequestParam int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Collection<Tag> tags= new ArrayList<Tag>();
		tags=startup.getTags();
		Tag tag = tagService.findOne(tagId);
		try {
			Assert.isTrue(startups.contains(startup));
			
			Assert.isTrue(!(tags.contains(tag)));
			
			tagService.addTag(tag,startup);
			result = new ModelAndView("redirect:/tag/company/addList.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/tag/company/addList.do?objectId=" + objectId);
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour");
			}else if(tags.contains(tag)){
				redirectAttrs.addFlashAttribute("message", "tag.commit.alreadyAdd");
			}else{
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");

				}
			}
		return result;
	}	
	
	
	
	// Company remove la tag----------------------------------------------
	@RequestMapping(value = "/company/remove", method = RequestMethod.GET)
	public ModelAndView removeTag(@RequestParam int tagId,@RequestParam int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Startup startup;
		startup = startupService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Collection<Tag> tags= new ArrayList<Tag>();
		tags=startup.getTags();
		Tag tag = tagService.findOne(tagId);
		try {
			Assert.isTrue(startups.contains(startup));
			
			Assert.isTrue((tags.contains(tag)));
			
			tagService.removeTag(tag,startup);
			result = new ModelAndView("redirect:/tag/company/removeList.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/tag/company/removeList.do?objectId=" + objectId);
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour");
			}else if(!(tags.contains(tag))){
				redirectAttrs.addFlashAttribute("message", "tag.commit.notAdd");
			}else{
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");

				}
			}
		return result;
	}
	
	//PARA LAS OFFERS------------------------------------------
	//List company para las offers----------------------------------------
	@RequestMapping(value = "/company/addListo", method = RequestMethod.GET)
	public ModelAndView listAddOffer(@RequestParam("objectId") int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer offer;
		offer= offerService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Offer> offers= new ArrayList<Offer>();
		offers = c.getOffers();
		boolean aux=true;
		boolean ole=false;

		try {
			Assert.isTrue(offers.contains(offer));

			Collection<Tag> tagsAux= new ArrayList<Tag>();
			tagsAux = offer.getTags();
			
			Collection<Tag> tags= new ArrayList<Tag>();
			tags=tagService.findAll();
			
			tags.removeAll(tagsAux);

			result = new ModelAndView("tag/company/add");
			result.addObject("tags", tags);
			result.addObject("objectId", objectId);
			result.addObject("aux", aux);
			result.addObject("ole", ole);
			result.addObject("requestURI", "tag/company/addListo.do?offerId=" + objectId);

		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(offers.contains(offer))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour.offer");
			} else {
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");
			}
		}
		return result;
	}
	
	
	
	
	//List company----------------------------------------
	@RequestMapping(value = "/company/removeListo", method = RequestMethod.GET)
	public ModelAndView listRemoveOffer(@RequestParam("objectId") int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer offer;
		offer= offerService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Offer> offers= new ArrayList<Offer>();
		offers = c.getOffers();
		boolean aux=false;
		boolean ole=false;

		try {
			Assert.isTrue(offers.contains(offer));

			Collection<Tag> tags= new ArrayList<Tag>();
			tags=offer.getTags();
			
			result = new ModelAndView("tag/company/add");
			result.addObject("tags", tags);
			result.addObject("objectId", objectId);
			result.addObject("aux", aux);
			result.addObject("ole", ole);
			result.addObject("requestURI", "tag/company/removeListo.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/startup/company/list.do");
			if (!(offers.contains(offer))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour.offer");
			} else {
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");
			}
		}
		return result;
	}
	
	
	
	// Company a�ade la tag----------------------------------------------
	@RequestMapping(value = "/company/addo", method = RequestMethod.GET)
	public ModelAndView addTagOffer(@RequestParam int tagId,@RequestParam int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer offer;
		offer = offerService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Collection<Tag> tags= new ArrayList<Tag>();
		tags=offer.getTags();
		Tag tag = tagService.findOne(tagId);
		Startup startup=startupService.startupPerOffer(objectId);
		try {
			Assert.isTrue(startups.contains(startup));
			
			Assert.isTrue(!(tags.contains(tag)));
			
			tagService.addTago(tag,offer);
			result = new ModelAndView("redirect:/tag/company/addListo.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/tag/company/addListo.do?objectId=" + objectId);
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour.offer");
			}else if(tags.contains(tag)){
				redirectAttrs.addFlashAttribute("message", "tag.commit.alreadyAdd");
			}else{
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");

				}
			}
		return result;
	}	
	
	
	
	// Company remove la tag----------------------------------------------
	@RequestMapping(value = "/company/removeo", method = RequestMethod.GET)
	public ModelAndView removeTagOffer(@RequestParam int tagId,@RequestParam int objectId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		Offer offer;
		offer = offerService.findOne(objectId);
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups = new ArrayList<Startup>();
		startups = c.getStartups();
		Collection<Tag> tags= new ArrayList<Tag>();
		tags=offer.getTags();
		Tag tag = tagService.findOne(tagId);
		Startup startup=startupService.startupPerOffer(objectId);
		try {
			Assert.isTrue(startups.contains(startup));
			
			Assert.isTrue((tags.contains(tag)));
			
			tagService.removeTago(tag,offer);
			result = new ModelAndView("redirect:/tag/company/removeListo.do?objectId=" + objectId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/tag/company/removeListo.do?objectId=" + objectId);
			if (!(startups.contains(startup))) {
				redirectAttrs.addFlashAttribute("message", "tag.commit.notYour.offer");
			}else if(!(tags.contains(tag))){
				redirectAttrs.addFlashAttribute("message", "tag.commit.notAdd");
			}else{
				redirectAttrs.addFlashAttribute("message", "tag.commit.error");

				}
			}
		return result;
	}
	
	
	
	

	// Ancillary methods -----------------------------

	protected ModelAndView createEditModelAndView(TagForm tagForm) {
		ModelAndView result;
		result = createEditModelAndView(tagForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(TagForm tagForm, String message) {
		ModelAndView result;

		result = new ModelAndView("tag/admin/edit");
		result.addObject("tag", tagForm);
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView createEditModelAndViewCreate(TagForm tagForm) {
		ModelAndView result;
		result = createEditModelAndViewCreate(tagForm, null);
		return result;
	}

	protected ModelAndView createEditModelAndViewCreate(TagForm tagForm, String message) {
		ModelAndView result;

		result = new ModelAndView("tag/admin/create");
		result.addObject("tag", tagForm);
		result.addObject("message", message);

		return result;
	}

}
