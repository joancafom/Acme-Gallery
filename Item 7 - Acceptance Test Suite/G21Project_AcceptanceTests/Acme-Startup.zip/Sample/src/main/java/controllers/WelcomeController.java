/*
 * WelcomeController.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import domain.Announcement;
import domain.Configuration;
import services.ConfigurationService;

@Controller
@RequestMapping("/welcome")
public class WelcomeController extends AbstractController {

	
	@Autowired
	ConfigurationService configurationService;
	// Constructors -----------------------------------------------------------

	public WelcomeController() {
		super();
	}

	// Index ------------------------------------------------------------------		

	@RequestMapping(value = "/index")
	public ModelAndView index(@RequestParam(required = false, defaultValue = "John Doe") final String name) {
		ModelAndView result;
//		SimpleDateFormat formatter;
//		String moment;
//		formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
//		moment = formatter.format(new Date());
		Collection<Configuration> confs =configurationService.findAll();
		
		String photo = "";
		String welcome = "";
		String bienvenida= "";
		String company= "";
	
		for(Configuration c : confs){
			welcome = c.getWelcome();
			bienvenida = c.getBienvenida();
			photo = c.getBanner();
			company = c.getCompany();
		}

		String footer = "";
		String link = "";
		int aux = 0;
		int num = 0;
		Collection<Announcement> advs = new ArrayList<Announcement>();

		advs = announcementService.findAll();
		aux = advs.size();
		if (aux != 0) {
			num = (int) (Math.random() * aux);
			Announcement adv = (Announcement) advs.toArray()[num];
			footer = adv.getBanner();
			link = adv.getLink();
		}
		
		
		result = new ModelAndView("welcome/index");
		//result.addObject("name", name);
		//result.addObject("moment", moment);
		result.addObject("welcome", welcome);
		result.addObject("bienvenida", bienvenida);
		result.addObject("photo", photo);
		result.addObject("company", company);
		result.addObject("footer", footer);
		result.addObject("link", link);
		return result;
	}
}
