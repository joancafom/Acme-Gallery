package controllers;

import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import domain.InterestData;
import domain.PersonalData;
import domain.User;
import domain.Work;
import forms.WorkForm;
import services.PersonalDataService;
import services.UserService;
import services.WorkService;

@Controller
@RequestMapping("/work")
public class WorkController extends AbstractController {

	// Services ---------------------------------------------------------------
	@Autowired
	private WorkService workService;

	@Autowired
	private UserService userService;

	@Autowired
	private PersonalDataService personalDataService;

	// Constructors -----------------------------------------------------------
	public WorkController() {
		super();
	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/user/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int personalDataId) {

		ModelAndView result;
		Collection<Work> works;

		works = workService.workPerPersonalData(personalDataId);

		result = new ModelAndView("work/user/list");
		result.addObject("requestURI", "work/user/list.do");
		result.addObject("works", works);
		result.addObject("personalDataId", personalDataId);

		return result;
	}

	// Editing ----------------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int workId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;
		WorkForm workForm;
		User principal = userService.findByPrincipal();

		Work work;
		User userpd = workService.userByWorkId(workId);

		PersonalData pd = workService.personalDataByWorkId(workId);

		try {
			Assert.isTrue(principal.equals(userpd), "Usted no tiene acceso a experiencias laborales que no son suyas");
			work = workService.findOne(workId);

			workForm = new WorkForm();
			workForm.setWorkId(work.getId());
			workForm.setDateStart(work.getDateStart());
			workForm.setDateEnd(work.getDateEnd());
			workForm.setAttachment(work.getAttachment());
			workForm.setComments(work.getComments());
			workForm.setCompany(work.getCompany());
			workForm.setRole(work.getRole());
			workForm.setPersonalDataId(pd.getId());

			result = new ModelAndView("work/user/edit");
			result.addObject("workForm", workForm);
			result.addObject("personalDataId", pd.getId());
			result.addObject("requestURI", "./work/user/edit.do?workId=" + workId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/work/user/list.do?personalDataId=" + pd.getId());
			if (oops.getLocalizedMessage().equals("Usted no tiene acceso a experiencias laborales que no son suyas")) {
				redirectAttrs.addFlashAttribute("message", "work.user.error");
			} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
				redirectAttrs.addFlashAttribute("message", "work.date.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "work.error");
			}
		}

		return result;
	}

	@RequestMapping(value = "/user/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid WorkForm workForm, BindingResult binding, RedirectAttributes redirectAttrs) {

		ModelAndView result;
		Work work;

		User principal = userService.findByPrincipal();
		User userPd = workService.userByWorkId(workForm.getWorkId());
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = editModelAndView(workForm);
		} else {
			try {
				Assert.isTrue(principal.equals(userPd),
						"Usted no tiene acceso a experiencias laborales que no son suyas");
				Assert.notNull(workForm);

			/*	if (workForm.getDateEnd() != null) {
					Assert.isTrue(workForm.getDateStart().before(workForm.getDateEnd()),
							"La fecha de comienzo debe ser anterior a la fecha fin");
					Assert.isTrue(workForm.getDateEnd().before(momento),
							"La fecha fin debe ser anterior a la fecha actual");
				}
*/
				int personalDataId = workService.personalDataByWorkId(workForm.getWorkId()).getId();

				work = workService.findOne(workForm.getWorkId());
				work.setDateStart(workForm.getDateStart());
				work.setDateEnd(workForm.getDateEnd());
				work.setAttachment(workForm.getAttachment());
				work.setComments(workForm.getComments());
				work.setCompany(workForm.getCompany());
				work.setRole(workForm.getRole());
				workService.save(work);

				result = new ModelAndView("redirect:/work/user/list.do?personalDataId=" + personalDataId);
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage()
						.equals("Usted no tiene acceso a experiencias laborales que no son suyas")) {
					result = editModelAndView(workForm, "work.user.error");
				} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result = editModelAndView(workForm, "work.date.error");
				} else if (oops.getLocalizedMessage().equals("La fecha fin debe ser anterior a la fecha actual")) {
					result = editModelAndView(workForm, "work.dateactual.error");
				} else {
					result = editModelAndView(workForm, "work.error");
				}
				result.addObject("personalDataId", workForm.getPersonalDataId());
			}
		}
		return result;
	}

	// Creating
	// ----------------------------------------------------------------------

	@RequestMapping(value = "/user/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam int personalDataId, final RedirectAttributes redirectAttrs) {
		ModelAndView result;

		WorkForm workForm = new WorkForm();
		workForm.setPersonalDataId(personalDataId);
		User userpd = personalDataService.userByPersonalDataId(personalDataId);
		User principal = userService.findByPrincipal();

		try {
			Assert.isTrue(principal.equals(userpd), "Usted no tiene acceso a experiencias laborales que no son suyas");
			result = new ModelAndView("work/user/create");
			result.addObject("workForm", workForm);
			result.addObject("requestURI", "./work/user/create.do");
			result.addObject("personalDataId", personalDataId);
		} catch (Throwable oops) {
			result = new ModelAndView("redirect:/personalData/user/list.do");
			if (oops.getLocalizedMessage().equals("Usted no tiene acceso a experiencias laborales que no son suyas")) {
				redirectAttrs.addFlashAttribute("message", "work.user.error");
			} else {
				redirectAttrs.addFlashAttribute("message", "work.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/user/create", method = RequestMethod.POST, params = "save")
	public ModelAndView saveCreate(@Valid WorkForm workForm, BindingResult binding, RedirectAttributes redirectAttrs) {
		ModelAndView result;

		workForm.setPersonalDataId(workForm.getPersonalDataId());
		User principal = userService.findByPrincipal();
		User userpd = personalDataService.userByPersonalDataId(workForm.getPersonalDataId());
		Date momento = new Date(System.currentTimeMillis() - 1000);

		if (binding.hasErrors()) {
			result = createModelAndView(workForm);
		} else
			try {
				Assert.notNull(workForm);
				Assert.isTrue(principal.equals(userpd),
						"Usted no tiene acceso a experiencias laborales que no son suyas");

				if (workForm.getDateEnd() != null) {
					Assert.isTrue(workForm.getDateStart().before(workForm.getDateEnd()),
							"La fecha de comienzo debe ser anterior a la fecha fin");
					Assert.isTrue(workForm.getDateEnd().before(momento),
							"La fecha fin debe ser anterior a la fecha actual");
				}

				int personalDataId = workForm.getPersonalDataId();
				Work res = workService.create();
				res.setDateStart(workForm.getDateStart());
				res.setDateEnd(workForm.getDateEnd());
				res.setAttachment(workForm.getAttachment());
				res.setComments(workForm.getComments());
				res.setCompany(workForm.getCompany());
				res.setRole(workForm.getRole());
				Work saved = workService.save(res);

				PersonalData p = personalDataService.findOne(personalDataId);
				p.getInterestDatas().add(saved);
				personalDataService.save(p);

				result = new ModelAndView("redirect:/work/user/list.do?personalDataId=" + personalDataId);
			} catch (Throwable oops) {
				if (oops.getLocalizedMessage()
						.equals("Usted no tiene acceso a experiencias laborales que no son suyas")) {
					result = createModelAndView(workForm, "work.user.error");
				} else if (oops.getLocalizedMessage().equals("La fecha de comienzo debe ser anterior a la fecha fin")) {
					result = createModelAndView(workForm, "work.date.error");
				} else if (oops.getLocalizedMessage().equals("La fecha fin debe ser anterior a la fecha actual")) {
					result = createModelAndView(workForm, "work.dateactual.error");
				} else {
					result = createModelAndView(workForm, "work.error");
				}
				result.addObject("personalDataId", workForm.getPersonalDataId());
			}
		return result;
	}

	// Deleting
	// -------------------------------------------------------------------------

	@RequestMapping(value = "/user/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(WorkForm workForm, BindingResult binding) {
		ModelAndView result;

		try {
			Assert.notNull(workService.findOne(workForm.getWorkId()));
			Work res = workService.findOne(workForm.getWorkId());

			PersonalData p = workService.personalDataByWorkId(workForm.getWorkId());
			Collection<InterestData> works = p.getInterestDatas();
			works.remove(res);
			p.setInterestDatas(works);
			personalDataService.save(p);

			workService.delete(res);

			result = new ModelAndView("redirect:/work/user/list.do?personalDataId=" + p.getId());
		} catch (Throwable oops) {
			result = editModelAndView(workForm, "work.error");
		}

		return result;
	}

	// Ancilliary methods
	// ----------------------------------------------------------------
	protected ModelAndView createModelAndView(WorkForm workForm) {
		ModelAndView result;
		result = createModelAndView(workForm, null);
		return result;
	}

	protected ModelAndView createModelAndView(WorkForm workForm, String message) {
		ModelAndView result;

		result = new ModelAndView("work/user/create");
		result.addObject("workForm", workForm);
		result.addObject("personalDataId", workForm.getPersonalDataId());
		result.addObject("message", message);

		return result;
	}

	protected ModelAndView editModelAndView(WorkForm workForm) {
		ModelAndView result;
		result = editModelAndView(workForm, null);
		return result;
	}

	protected ModelAndView editModelAndView(WorkForm workForm, String message) {
		ModelAndView result;

		result = new ModelAndView("work/user/edit");
		result.addObject("workForm", workForm);
		result.addObject("personalDataId", workForm.getPersonalDataId());
		result.addObject("message", message);

		return result;
	}

}
