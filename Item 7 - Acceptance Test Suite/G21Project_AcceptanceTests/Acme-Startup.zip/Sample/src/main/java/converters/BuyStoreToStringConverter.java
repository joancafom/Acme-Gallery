package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.BuyStore;

@Component
@Transactional
public class BuyStoreToStringConverter implements Converter<BuyStore, String> {

	@Override
	public String convert(BuyStore buyStore) {
		String result;

		if (buyStore == null)
			result = null;
		else
			result = String.valueOf(buyStore.getId());

		return result;
	}

}
