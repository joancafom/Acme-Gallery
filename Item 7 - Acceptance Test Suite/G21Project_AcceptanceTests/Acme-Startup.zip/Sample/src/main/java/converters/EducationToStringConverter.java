package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Education;

@Component
@Transactional
public class EducationToStringConverter implements Converter<Education, String> {

	@Override
	public String convert(Education education) {
		String result;

		if (education == null)
			result = null;
		else
			result = String.valueOf(education.getId());

		return result;
	}

}
