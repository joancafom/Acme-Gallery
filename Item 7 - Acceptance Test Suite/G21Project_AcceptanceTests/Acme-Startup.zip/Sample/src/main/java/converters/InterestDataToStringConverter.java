package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.InterestData;



@Component
@Transactional
public class InterestDataToStringConverter implements Converter<InterestData, String> {

	@Override
	public String convert(InterestData interestData) {
		String result;

		if (interestData == null)
			result = null;
		else
			result = String.valueOf(interestData.getId());

		return result;
	}

}
