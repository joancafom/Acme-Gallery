
package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Merchant;

@Component
@Transactional
public class MerchantToStringConverter implements Converter<Merchant, String> {

	@Override
	public String convert(Merchant merchant) {
		String result;

		if (merchant == null)
			result = null;
		else
			result = String.valueOf(merchant.getId());

		return result;
	}

}
