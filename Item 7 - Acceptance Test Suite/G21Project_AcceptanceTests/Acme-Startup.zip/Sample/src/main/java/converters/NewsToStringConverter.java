package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.News;



@Component
@Transactional
public class NewsToStringConverter implements Converter<News, String> {

	@Override
	public String convert(News news) {
		String result;

		if (news == null)
			result = null;
		else
			result = String.valueOf(news.getId());

		return result;
	}

	
}
