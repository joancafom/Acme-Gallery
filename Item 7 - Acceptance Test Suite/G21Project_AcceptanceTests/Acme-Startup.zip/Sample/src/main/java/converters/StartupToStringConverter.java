package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Startup;



@Component
@Transactional
public class StartupToStringConverter implements Converter<Startup, String> {

	@Override
	public String convert(Startup startup) {
		String result;

		if (startup == null)
			result = null;
		else
			result = String.valueOf(startup.getId());

		return result;
	}

	
}
