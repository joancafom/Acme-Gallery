
package converters;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.InterestData;
import repositories.InterestDataRepository;

@Component
@Transactional
public class StringToInterestDataConverter implements Converter<String, InterestData> {

	@Autowired
	InterestDataRepository interestDataRepository;


	@Override
	public InterestData convert(String text) {
		InterestData result;
		int id;
		try {
			if (StringUtils.isEmpty(text)) {
				result = null;
			} else {
				id = Integer.valueOf(text);
				result = interestDataRepository.findOne(id);
			}
		} catch (Exception oops) {
			throw new IllegalArgumentException(oops);
		}
		return result;
	}

}
