package converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import domain.Work;

@Component
@Transactional
public class WorkToStringConverter implements Converter<Work, String> {

	@Override
	public String convert(Work work) {
		String result;

		if (work == null)
			result = null;
		else
			result = String.valueOf(work.getId());

		return result;
	}

}
