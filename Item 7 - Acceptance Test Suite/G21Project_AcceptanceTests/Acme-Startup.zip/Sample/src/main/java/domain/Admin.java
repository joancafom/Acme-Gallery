
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "email") })
public class Admin extends Actor {

	//Constructor

	public Admin() {
		super();
	}


	//Relationships

	private Collection<Raffle> raffles;


	@OneToMany
	public Collection<Raffle> getRaffles() {
		return raffles;
	}

	public void setRaffles(Collection<Raffle> raffles) {
		this.raffles = raffles;
	}

}
