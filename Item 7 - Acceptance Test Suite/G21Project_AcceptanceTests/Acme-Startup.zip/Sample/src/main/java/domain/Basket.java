package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.validation.constraints.Min;


@Entity
@Access(AccessType.PROPERTY)
public class Basket extends DomainEntity{
	
	// Attributes -------------------------------------------------------------
	private double total;
	private Date date;
	
	
	//Constructor
	public Basket() {
		super();
	}

	
	//Getter and setters------------------------------
	
	@Min(0)
	public double getTotal() {
		return total;
	}


	public void setTotal(double total) {
		this.total = total;
	}

	
	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}



	//Relaciones--------------------------
	private Collection<Item>	items;

	@ManyToMany
	public Collection<Item> getItems() {
		return items;
	}


	public void setItems(Collection<Item> items) {
		this.items = items;
	}

	
}
