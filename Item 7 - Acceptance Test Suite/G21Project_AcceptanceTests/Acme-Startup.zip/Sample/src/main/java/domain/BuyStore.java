package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;


@Entity
@Access(AccessType.PROPERTY)
public class BuyStore extends DomainEntity {

	// Constructor
	public BuyStore() {
		super();
	}

	// Relaciones

	private Collection<Item> items;

	@ManyToMany
	public Collection<Item> getItems() {
		return items;
	}

	public void setItems(Collection<Item> items) {
		this.items = items;
	}

}
