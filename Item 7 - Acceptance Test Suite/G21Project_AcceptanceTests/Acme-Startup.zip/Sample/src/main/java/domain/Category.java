package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes={@Index(columnList="name")})
public class Category extends DomainEntity{
	
	// Attributes -------------------------------------------------------------
	private String name;
	
	
	//Constructor
	public Category() {
		super();
	}

	
	//Getter and setters------------------------------
	@NotBlank
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	//Relaciones--------------------------
	private Collection<Category>	sons;
	private Category				father;

	@OneToMany(cascade = CascadeType.REMOVE)
	public Collection<Category> getSons() {
		return sons;
	}

	public void setSons(Collection<Category> sons) {
		this.sons = sons;
	}

	@ManyToOne(optional = true)
	@Valid
	public Category getFather() {
		return father;
	}

	public void setFather(Category father) {
		this.father = father;
	}
}
