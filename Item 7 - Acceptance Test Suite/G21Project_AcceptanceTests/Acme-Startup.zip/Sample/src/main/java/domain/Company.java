
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "email") })
public class Company extends Actor {

	private Boolean		pro;
	private CreditCard	creditCard;


	// Constructor

	public Company() {
		super();
	}

	@NotNull
	public Boolean getPro() {
		return pro;
	}

	public void setPro(Boolean pro) {
		this.pro = pro;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}


	// Relationships

	private Collection<Sell>	sells;
	private Collection<Item>	items;
	private Collection<Offer>	offers;
	private Collection<Startup>	startups;
	private Collection<News>	news;


	@OneToMany
	public Collection<Sell> getSells() {
		return sells;
	}

	public void setSells(Collection<Sell> sells) {
		this.sells = sells;
	}

	@OneToMany
	public Collection<Item> getItems() {
		return items;
	}

	public void setItems(Collection<Item> items) {
		this.items = items;
	}

	@OneToMany
	public Collection<Offer> getOffers() {
		return offers;
	}

	public void setOffers(Collection<Offer> offers) {
		this.offers = offers;
	}

	@OneToMany
	public Collection<Startup> getStartups() {
		return startups;
	}

	public void setStartups(Collection<Startup> startups) {
		this.startups = startups;
	}

	@OneToMany
	public Collection<News> getNews() {
		return news;
	}

	public void setNews(Collection<News> news) {
		this.news = news;
	}

}
