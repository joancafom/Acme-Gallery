package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.hibernate.validator.constraints.URL;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "countryCode") })
public class Configuration extends DomainEntity{
	
	
		// Attributes -------------------------------------------------------------
		private String welcome;
		private String bienvenida;
		private String banner;
		private String company;
		private String countryCode;
		
		
		
		//Constructor
		public Configuration() {
			super();
		}
		
		
		
		@NotBlank
		public String getWelcome() {
			return welcome;
		}

		public void setWelcome(String welcome) {
			this.welcome = welcome;
		}

		@NotBlank
		public String getBienvenida() {
			return bienvenida;
		}

		public void setBienvenida(String bienvenida) {
			this.bienvenida = bienvenida;
		}


		@NotBlank
		@URL
		public String getBanner() {
			return banner;
		}

		public void setBanner(String banner) {
			this.banner = banner;
		}

		@NotBlank
		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}
		
		@Range(min = 10, max = 99)
		@NotBlank
		public String getCountryCode() {
			return countryCode;
		}

		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}
}
