
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Embeddable;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

@Embeddable
@Access(AccessType.PROPERTY)

public class CreditCard {

	public CreditCard() {
		super();
	}


	private String	holderName;
	private String	brandName;
	private String	number;
	private String	expirationMonth;
	private String	expirationYear;
	private String	cvvCode;


	@NotBlank
	public String getHolderName() {
		return this.holderName;
	}
	public void setHolderName(final String holderName) {
		this.holderName = holderName;
	}
	@NotBlank
	public String getBrandName() {
		return this.brandName;
	}
	public void setBrandName(final String brandName) {
		this.brandName = brandName;
	}

	@NotBlank
	@CreditCardNumber
	public String getNumber() {
		return this.number;
	}
	public void setNumber(final String number) {
		this.number = number;
	}
	@NotBlank
	@Pattern(regexp = "(^0[1-9]$)|(^1[0-2]$)")
	public String getExpirationMonth() {
		return this.expirationMonth;
	}
	public void setExpirationMonth(final String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}
	@NotBlank
	@Pattern(regexp = "^\\d\\d$")
	public String getExpirationYear() {
		return this.expirationYear;
	}
	public void setExpirationYear(final String expirationYear) {
		this.expirationYear = expirationYear;
	}

	@Range(min = 100, max = 999)
	@NotBlank
	public String getCvvCode() {
		return this.cvvCode;
	}
	public void setCvvCode(String cvvCode) {
		this.cvvCode = cvvCode;
	}

}
