
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "email") })
public class Merchant extends Actor {

	//Constructor

	public Merchant() {
		super();
	}

	//Relationships

	private Collection<Sell> sells;
	private Collection<Item> items;

	@OneToMany()
	public Collection<Sell> getSells() {
		return sells;
	}

	public void setSells(Collection<Sell> sells) {
		this.sells = sells;
	}

	@OneToMany
	public Collection<Item> getItems() {
		return items;
	}

	public void setItems(Collection<Item> items) {
		this.items = items;
	}

}
