package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

@Entity
@Access(AccessType.PROPERTY)
public class Offer extends DomainEntity{

	// Attributes -------------------------------------------------------------
	private String title;
	private String description;
	private Double salary;
	
	
	//Constructor
	public Offer() {
		super();
	}

	//Getter and setters------------------------------
	@NotBlank
	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}

	@NotBlank
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}

	@Range(min = 0)
	public Double getSalary() {
		return salary;
	}


	public void setSalary(Double salary) {
		this.salary = salary;
	}

	//Relaciones-----------
	private Collection<Tag> tags;
	private Collection<PersonalData> personalDatas;


	@NotNull
	@ManyToMany
	public Collection<Tag> getTags() {
		return tags;
	}

	public void setTags(Collection<Tag> tags) {
		this.tags = tags;
	}

	@NotNull
	@ManyToMany
	public Collection<PersonalData> getPersonalDatas() {
		return personalDatas;
	}

	public void setPersonalDatas(Collection<PersonalData> personalDatas) {
		this.personalDatas = personalDatas;
	}
	
	
	
	
}
