
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

@Entity
@Access(AccessType.PROPERTY)
public class PersonalData extends DomainEntity {

	// Attributes -------------------------------------------------------------

	private String	identifier;
	private String	name;
	private String	surname;
	private String	email;
	private String	phone;
	private String	linkedIn;


	//Constructor -------------------------------------------------------------

	public PersonalData() {
		super();
	}

	//Getter and setters------------------------------

	@Column(unique = true)
	@Pattern(regexp = "^\\w\\w\\w-\\d\\d\\d\\d\\d\\d$")
	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@NotBlank
	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	@Email
	@NotBlank
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@URL
	public String getLinkedIn() {
		return linkedIn;
	}

	public void setLinkedIn(String linkedIn) {
		this.linkedIn = linkedIn;
	}


	// Relationships ----------------------------------------------------------

	private Collection<InterestData> interestDatas;


	@OneToMany
	public Collection<InterestData> getInterestDatas() {
		return interestDatas;
	}

	public void setInterestDatas(Collection<InterestData> interestDatas) {
		this.interestDatas = interestDatas;
	}

}
