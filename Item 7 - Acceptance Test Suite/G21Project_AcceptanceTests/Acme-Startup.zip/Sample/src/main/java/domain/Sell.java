package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "closed") })
public class Sell extends DomainEntity{
	
	// Attributes -------------------------------------------------------------
	private String direction;
	private double total;
	public boolean closed;
	
	
	//Constructor
	public Sell() {
		super();
	}

	
	//Getter and setters------------------------------
	@NotBlank
	public String getDirection() {
		return direction;
	}


	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	@Min(0)
	public double getTotal() {
		return total;
	}


	public void setTotal(double total) {
		this.total = total;
	}
	
	public boolean getClosed() {
		return this.closed;
	}
	
	public void setClosed(boolean closed) {
		this.closed = closed;
	}



	//Relaciones--------------------------
	private Collection<Item>	items;

	@ManyToMany
	@NotNull
	public Collection<Item> getItems() {
		return items;
	}


	public void setItems(Collection<Item> items) {
		this.items = items;
	}

	
}
