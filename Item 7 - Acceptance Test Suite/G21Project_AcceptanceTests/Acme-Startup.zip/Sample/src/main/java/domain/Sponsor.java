
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "email") })
public class Sponsor extends Actor {

	// Constructor

	public Sponsor() {
		super();
	}

	// Relationships

	private Collection<Announcement> announcements;
	private BuyStore buyStore;
	private Collection<Cooperate> cooperates;
	private Basket basket;

	@OneToMany
	public Collection<Announcement> getAnnouncements() {
		return announcements;
	}

	public void setAnnouncements(Collection<Announcement> announcements) {
		this.announcements = announcements;
	}

	@OneToOne(optional = true)
	public BuyStore getBuyStore() {
		return buyStore;
	}

	public void setBuyStore(BuyStore buyStore) {
		this.buyStore = buyStore;
	}

	@OneToMany
	public Collection<Cooperate> getCooperates() {
		return cooperates;
	}

	public void setCooperates(Collection<Cooperate> cooperates) {
		this.cooperates = cooperates;
	}

	@OneToOne(optional = false)
	@NotNull
	public Basket getBasket() {
		return basket;
	}

	public void setBasket(Basket basket) {
		this.basket = basket;
	}

}
