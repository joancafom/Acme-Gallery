
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "email") })
public class User extends Actor {

	private String		surname;
	private String		profession;
	private Boolean		pro;
	private CreditCard	creditCard;


	public User() {
		super();
	}

	@NotBlank
	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	@NotBlank
	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	@NotNull
	public Boolean getPro() {
		return pro;
	}

	public void setPro(Boolean pro) {
		this.pro = pro;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}


	// Relationships----------------------------------------------------------

	private Collection<Comment>	comments;
	private Collection<Startup>	startups;
	private Basket				basket;
	private BuyStore			buyStore;
	private PersonalData		personalData;


	@OneToMany
	public Collection<Comment> getComments() {
		return comments;
	}

	public void setComments(Collection<Comment> comments) {
		this.comments = comments;
	}

	@ManyToMany
	public Collection<Startup> getStartups() {
		return startups;
	}

	public void setStartups(Collection<Startup> startups) {
		this.startups = startups;
	}

	@OneToOne(optional = false)
	public Basket getBasket() {
		return basket;
	}

	public void setBasket(Basket basket) {
		this.basket = basket;
	}

	@OneToOne(optional = true)
	public BuyStore getBuyStore() {
		return buyStore;
	}

	public void setBuyStore(BuyStore buyStore) {
		this.buyStore = buyStore;
	}

	@OneToOne(optional = true)
	public PersonalData getPersonalData() {
		return personalData;
	}

	public void setPersonalData(PersonalData personalData) {
		this.personalData = personalData;
	}

}
