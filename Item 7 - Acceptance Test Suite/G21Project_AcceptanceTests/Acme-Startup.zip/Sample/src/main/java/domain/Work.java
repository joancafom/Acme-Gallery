
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Work extends InterestData {
	
	// Attributes ------------------------------------
	private String company;
	private String role;
	
	//Constructor-------------------------------------

	public Work() {
		super();
	}

	
	//Getter and setters------------------------------
	
	@NotBlank
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@NotBlank
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
}
