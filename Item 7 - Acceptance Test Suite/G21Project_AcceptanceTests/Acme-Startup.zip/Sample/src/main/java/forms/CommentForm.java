package forms;

import org.hibernate.validator.constraints.NotBlank;

public class CommentForm {

	private int id;
	private int version;
	
	private String body;
	
	@NotBlank
	public String getBody() {
		return this.body;
	}
	
	public void setBody(String body) {
		this.body = body;
	}
	
	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getVersion() {
		return this.version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}
}
