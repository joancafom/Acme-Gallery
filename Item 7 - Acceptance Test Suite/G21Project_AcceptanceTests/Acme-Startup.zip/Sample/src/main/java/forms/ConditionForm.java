package forms;

import javax.validation.constraints.NotNull;

public class ConditionForm {

	private boolean closed;
	
	@NotNull
	public boolean getClosed() {
		return this.closed;
	}
	
	public void setClosed(boolean closed) {
		this.closed = closed;
	}
}
