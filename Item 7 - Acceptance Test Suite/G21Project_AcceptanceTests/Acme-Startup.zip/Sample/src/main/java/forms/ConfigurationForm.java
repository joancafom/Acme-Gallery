package forms;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.hibernate.validator.constraints.URL;

public class ConfigurationForm {

	// Attributes -------------------------------------------------------------
			private String welcome;
			private String bienvenida;
			private String banner;
			private String company;
			private String countryCode;
			private int id;
			
			
			@NotBlank
			public String getWelcome() {
				return welcome;
			}

			public void setWelcome(String welcome) {
				this.welcome = welcome;
			}

			@NotBlank
			public String getBienvenida() {
				return bienvenida;
			}

			public void setBienvenida(String bienvenida) {
				this.bienvenida = bienvenida;
			}


			@NotBlank
			@URL
			public String getBanner() {
				return banner;
			}

			public void setBanner(String banner) {
				this.banner = banner;
			}

			@NotBlank
			public String getCompany() {
				return company;
			}

			public void setCompany(String company) {
				this.company = company;
			}
			
			@Range(min = 10, max = 99)
			@NotBlank
			public String getCountryCode() {
				return countryCode;
			}

			public void setCountryCode(String countryCode) {
				this.countryCode = countryCode;
			}

			
			public int getId() {
				return id;
			}

			public void setId(int id) {
				this.id = id;
			}
}
