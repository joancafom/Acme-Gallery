package forms;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.hibernate.validator.constraints.URL;

public class EditCooperateForm {

	private int id;
	private String company;
	private String description;
	private String banner;
	private String link;
	
	private String holderName;
	private String brandName;
	private String number;
	private String expirationMonth;
	private String expirationYear;
	private String cvvCode;
	
	public int getId() {
		return this.id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	@NotBlank
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	@NotBlank
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@URL
	public String getBanner() {
		return banner;
	}

	public void setBanner(String banner) {
		this.banner = banner;
	}

	@URL
	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	
	@NotBlank
	public String getHolderName() {
		return this.holderName;
	}
	public void setHolderName(final String holderName) {
		this.holderName = holderName;
	}
	@NotBlank
	public String getBrandName() {
		return this.brandName;
	}
	public void setBrandName(final String brandName) {
		this.brandName = brandName;
	}

	@NotBlank
	@CreditCardNumber
	public String getNumber() {
		return this.number;
	}
	public void setNumber(final String number) {
		this.number = number;
	}
	@NotBlank
	@Pattern(regexp = "(^0[1-9]$)|(^1[0-2]$)")
	public String getExpirationMonth() {
		return this.expirationMonth;
	}
	public void setExpirationMonth(final String expirationMonth) {
		this.expirationMonth = expirationMonth;
	}
	@NotBlank
	@Pattern(regexp = "^\\d\\d$")
	public String getExpirationYear() {
		return this.expirationYear;
	}
	public void setExpirationYear(final String expirationYear) {
		this.expirationYear = expirationYear;
	}

	@Range(min = 100, max = 999)
	@NotBlank
	public String getCvvCode() {
		return this.cvvCode;
	}
	public void setCvvCode(String cvvCode) {
		this.cvvCode = cvvCode;
	}
}
