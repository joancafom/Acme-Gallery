
package forms;

import org.hibernate.validator.constraints.NotBlank;

import domain.Folder;

public class FolderForm {

	private String	name;
	private Integer	id;
	private Folder	folder;


	public Folder getFolder() {
		return folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "FolderForm [name=" + name + ", id=" + id + ", folder=" + folder + ", getFolder()=" + getFolder() + ", getId()=" + getId() + ", getName()=" + getName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
			+ super.toString() + "]";
	}

}
