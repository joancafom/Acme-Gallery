
package forms;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class MessageNotificationForm {

	private String	subject;
	private String	body;
	private String	priority;


	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	@Valid
	@NotNull
	@Pattern(regexp = "LOW|HIGH|NEUTRAL")
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "MessageNotificationForm [subject=" + subject + ", body=" + body + ", priority=" + priority + ", getSubject()=" + getSubject() + ", getBody()=" + getBody() + ", getPriority()=" + getPriority() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}
