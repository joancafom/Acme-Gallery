package forms;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

public class StartupForm {
	
	private int id;
	
	private String name;
	private String description;
	private String enterprisePage;
	
	private int categoryId;

	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	@NotBlank
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	
	@URL
	@NotBlank
	public String getEnterprisePage() {
		return enterprisePage;
	}

	public void setEnterprisePage(String enterprisePage) {
		this.enterprisePage = enterprisePage;
	}

	
	

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	
	
	

}
