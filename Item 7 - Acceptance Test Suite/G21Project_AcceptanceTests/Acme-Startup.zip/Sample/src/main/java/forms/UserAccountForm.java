
package forms;

public class UserAccountForm {

	private Integer	id;
	private Boolean	banned;


	public UserAccountForm() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getBanned() {
		return banned;
	}

	public void setBanned(Boolean banned) {
		this.banned = banned;
	}

	@Override
	public String toString() {
		return "UserAccountForm [id=" + id + ", banned=" + banned + ", getId()=" + getId() + ", getBanned()=" + getBanned() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
