
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Actor;
import security.UserAccount;

@Repository
public interface ActorRepository extends JpaRepository<Actor, Integer> {

	@Query("select a from Actor a where a.userAccount.id = ?1")
	Actor findByUserAccountId(int id);

	@Query("select aut.authority from Actor a, UserAccount au join au.authorities aut where a.id = ?1 and a.userAccount = au")
	String findAuthorityActor(int id);

	@Query("select a from Actor a where a.email = ?1")
	Actor findActorEmail(String email);

	@Query("select count(a) from Actor a where a.email = ?1")
	Integer findEmails(String email);

	@Query("select count(a) from Actor a, UserAccount ua where a.userAccount = ua.id and ua.username = ?1")
	Integer findCountUsernames(String username);

	@Query("select count(a) from Actor a where a.email = ?1")
	Integer findCountEmail(String email);

	@Query("select ua from UserAccount ua where ua.id = ?1")
	UserAccount userAccountId(int id);

	@Query("select a.email from Actor a where a.email != ?1")
	Collection<String> emailsSavedInBD(String emailId);

	@Query("select a.email from Actor a")
	Collection<String> getAllEmails();

	@Query("select a from Actor a,UserAccount ua where a.userAccount = ua.id and ua.banned = false")
	Collection<Actor> actorBanneds();

	@Query("select a from Actor a where a.id = ?1")
	Actor actorPerId(int actorId);

	@Query("select a from Actor a where a.pro = true")
	Collection<Actor> actorsPRO();

}
