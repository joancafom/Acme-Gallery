
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Admin;
import domain.Raffle;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer> {

	@Query("select a from Admin a where a.userAccount.id = ?1")
	Admin findByUserAccountId(int id);

	/*
	 * Query 1 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero ofertas por startup.
	 */

	@Query("select avg(s.offers.size), max(s.offers.size), min(s.offers.size),Stddev(s.offers.size) from Startup s")
	Object[] offerstPerStartup();

	/*
	 * Query 2 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de datos personales por oferta.
	 */

	@Query("select avg(s.personalDatas.size), max(s.personalDatas.size), min(s.personalDatas.size),Stddev(s.personalDatas.size) from Offer s")
	Object[] offerstPerPersonalData();

	/*
	 * Query 3 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de startups que tienen las compa�ias.
	 */

	@Query("select avg(c.startups.size), max(c.startups.size), min(c.startups.size),Stddev(c.startups.size) from Company c")
	Object[] startupsPerCompany();

	/*
	 * Query 4 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de comentarios por usuario.
	 */

	@Query("select avg(u.comments.size), max(u.comments.size), min(u.comments.size),Stddev(u.comments.size) from User u")
	Object[] commentsPerUser();

	/*
	 * Query 5 - C
	 * El porcentaje de usuarios con datos de interes en trabajo y educaci�n.
	 */

	@Query("select (count(w)/(select count(i) from InterestData i))*100.0 from Work w")
	Double percentWorksInterestingData();

	@Query("select (count(e)/(select count(i) from InterestData i))*100.0 from Education e")
	Double percentEducationsInterestingData();

	/*
	 * Query 6 - C
	 * El porcentaje de Usuarios, Compa��as, Vendedores y Sponsors en el sistema.
	 */

	@Query("select (count(u)/((select count(uu) from UserAccount uu)-(select count(a) from Admin a)))*100.0 from User u")
	Double percentUsers();

	@Query("select (count(u)/((select count(uu) from UserAccount uu)-(select count(a) from Admin a)))*100.0 from Company u")
	Double percentCompanies();

	@Query("select (count(u)/((select count(uu) from UserAccount uu)-(select count(a) from Admin a)))*100.0 from Merchant u")
	Double percentMerchants();

	@Query("select (count(u)/((select count(uu) from UserAccount uu)-(select count(a) from Admin a)))*100.0 from Sponsor u")
	Double percentSponsors();

	/*
	 * Query 7 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de ventas de los vendedores.
	 */

	@Query("select avg(m.sells.size), max(m.sells.size), min(m.sells.size),Stddev(m.sells.size) from Merchant m")
	Object[] sellsPerMerchants();

	/*
	 * Query 8 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de ventas de las compa��as.
	 */

	@Query("select avg(m.sells.size), max(m.sells.size), min(m.sells.size),Stddev(m.sells.size) from Company m")
	Object[] sellsPerCompanies();

	/*
	 * Query 9 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de Anuncios por Sponsor.
	 */

	@Query("select avg(s.announcements.size), max(s.announcements.size), min(s.announcements.size),Stddev(s.announcements.size) from Sponsor s")
	Object[] announcementsPerSponsor();

	/*
	 * Query 10 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de items comprados por Usuario.
	 */

	@Query("select avg(u.buyStore.items.size), max(u.buyStore.items.size), min(u.buyStore.items.size),Stddev(u.buyStore.items.size) from User u")
	Object[] itemsPerUser();

	/*
	 * Query 11 - C
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de items comprados por Sponsor.
	 */

	@Query("select avg(u.buyStore.items.size), max(u.buyStore.items.size), min(u.buyStore.items.size),Stddev(u.buyStore.items.size) from Sponsor u")
	Object[] itemsPerSponsor();

	/*
	 * Query 1 - B
	 * La media, el total y la desviaci�n t�pica del n�mero de usuarios premium.
	 */

	@Query("select (count(u)/(select count(uu) from User uu))*100.0 from User u where u.pro = true")
	Double avgUsersPro();

	@Query("select count(u) from User u where u.pro = true")
	Integer countUsersPro();

	@Query("select stddev(u) from User u where u.pro = true")
	Double stddevUsersPro();

	/*
	 * Query 2 - B
	 * La media, el total y la desviaci�n t�pica del n�mero de compa��as premium.
	 */

	@Query("select (count(u)/(select count(uu) from User uu))*100.0 from Company u where u.pro = true")
	Double avgCompaniesPro();

	@Query("select count(u) from Company u where u.pro = true")
	Integer countCompaniesPro();

	@Query("select stddev(u) from Company u where u.pro = true")
	Double stddevCompaniesPro();

	/*
	 * Query 3 - B
	 * El porcentaje de empresas con al menos un �tem en venta.
	 */

	@Query("select (count(c)/(select count(cc) from Company cc))*100.0 from Company c where c.items.size >= 1")
	Double itemsPerCompanyEnVenta();

	/*
	 * Query 4 - B
	 * El porcentaje de usuarios con al menos un �tem en su historial de compras.
	 */

	@Query("select (count(u)/(select count(uu) from User uu))*100.0 from User u, BuyStore b where u.buyStore.id = b.id and b.items.size > 1")
	Double itemsBuyStorePerUser();

	/*
	 * Query 9 - C
	 * El porcentaje de startups con al menos un 10% m�s de ofertas que la media.
	 */

	@Query("select (count(s)/(select count(a) from Startup a))*100.0 from Startup s where s.offers.size >= (select avg(ss.offers.size)*1.10 from Startup ss)")
	Double avgOffersPerStartupAverage();

	/*
	 * Query 10 - C
	 * El porcentaje de startups con al menos un 10% m�s de novedades que la media
	 */

	@Query("select (count(s)/(select count(a) from Startup a))*100.0 from Startup s where s.news.size >= (select avg(ss.news.size)*1.10 from Startup ss)")
	Double avgNewsPerStartupAverage();

	/*
	 * Query 1 - A
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de usuarios inscritos en el sorteo.
	 */

	@Query("select avg(r.users.size), max(r.users.size), min(r.users.size),Stddev(r.users.size) from Raffle r")
	Object[] usersPerRaffle();

	/*
	 * Query 2 - A
	 * La media, el m�nimo, el m�ximo y la desviaci�n t�pica del n�mero de comentarios que tienen las noticias
	 */

	@Query("select avg(n.comments.size), max(n.comments.size), min(n.comments.size),Stddev(n.comments.size) from News n")
	Object[] commentsPerNews();

	/*
	 * Query 3 - A
	 * Las rifas que ya han terminado a d�a de hoy.
	 */

	@Query("select r from Raffle r where r.dateFinish <= current_date and r.closed = true")
	Collection<Raffle> rafflesEnds();

	/*
	 * Query 4 - A
	 * Las rifas que no han terminado a d�a de hoy.
	 */

	@Query("select r from Raffle r where r.dateFinish > current_date and r.closed = false")
	Collection<Raffle> rafflesNoEnd();

}
