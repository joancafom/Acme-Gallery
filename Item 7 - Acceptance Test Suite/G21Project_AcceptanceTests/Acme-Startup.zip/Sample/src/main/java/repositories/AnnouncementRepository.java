package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Announcement;
import domain.Sponsor;
@Repository
public interface AnnouncementRepository extends JpaRepository<Announcement, Integer> {

/*	//Newsapaper con tabooword para los admin
	@Query("select c from Announcement c where exists (select t from Spam t where t.title like concat('%', t.name, '%'))")
	Collection<Announcement> announcementWithSpam();
*/	
	@Query("select a from Sponsor a join a.announcements aa where aa.id = ?1")
	Sponsor sponsorPerAnnouncement(int announcementId);
}
