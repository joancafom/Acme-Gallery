package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Basket;

@Repository
public interface BasketRepository extends JpaRepository<Basket, Integer> {

	@Query("select sum(i.price - ((i.discount/100) * i.price)) from Basket b join b.items i where b.id = ?1")
	public double calculateTotal(int sellId);
	
	@Query("select m.id, i from Merchant m join m.items i where exists (select b from Basket b join b.items ii where ii.id = i.id and b.id = ?1)")
	Collection<Object[]> getBasketMerchantsAndItems(int basketId);
	
	@Query("select c.id, i from Company c join c.items i where exists (select b from Basket b join b.items ii where ii.id = i.id and b.id = ?1)")
	Collection<Object[]> getBasketCompanyAndItems(int basketId);
}
