
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import domain.BuyStore;

@Repository
public interface BuyStoreRepository extends JpaRepository<BuyStore, Integer> {

}
