
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> {

	@Query("select a from Company a where a.userAccount.id = ?1")
	Company findByUserAccountId(int id);
	
	@Query("select c from Company c join c.items i where i.id = ?1")
	Company findByItem(int id);
	
	@Query("select c from Company c join c.offers cc where cc.id=?1")
	Company companyPerOffer(int offerId);
	
	@Query("select t from Company t join t.news tt where tt.id=?1")
	Company companyPerNews(int newsId);
	
	
}
