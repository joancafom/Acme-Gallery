package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Cooperate;

@Repository
public interface CooperateRepository extends JpaRepository<Cooperate, Integer> {

	@Query("select c from Sponsor s join s.cooperates c where s.id = ?1")
	Collection<Cooperate> findCooperatesByPrincipal(int sponsorId);
}
