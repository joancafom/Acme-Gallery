
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Education;
import domain.PersonalData;
import domain.User;

@Repository
public interface EducationRepository extends JpaRepository<Education, Integer> {

	@Query("select e from Education e where e.id = (select i.id from PersonalData p join p.interestDatas i where e.id=i.id and p.id=?1)")
	Collection<Education> educationPerPersonalData(int personalDataId);
	
	@Query("select u from User u join u.personalData p join p.interestDatas i where i.id=?1")
	User userByEducationId(int educationId);
	
	@Query("select p from PersonalData p join p.interestDatas i where i.id=?1")
	PersonalData personalDataByEducationId(int educationId);
}
