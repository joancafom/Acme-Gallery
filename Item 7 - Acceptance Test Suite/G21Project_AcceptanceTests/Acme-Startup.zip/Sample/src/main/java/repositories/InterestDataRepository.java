
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.InterestData;

@Repository
public interface InterestDataRepository extends JpaRepository<InterestData, Integer> {

	@Query("select p.interestDatas from PersonalData p where p.id=?1")
	Collection<InterestData> interestDataPerPersonalData(int personalDataId);
}
