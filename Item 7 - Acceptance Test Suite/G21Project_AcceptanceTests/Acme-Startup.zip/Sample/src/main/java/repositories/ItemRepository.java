package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Item;

@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> {

	@Query("select i from Merchant m join m.items i where i.deleted = false")
	Collection<Item> findAllNotDeleted();
	
	@Query("select i from Sell s join s.items i where s.id = ?1")
	Collection<Item> findAllItemsBySell(int sellId);
	
	@Query("select i from Company c join c.items i where c.pro = true and i.deleted = false")
	Collection<Item> findAllItemsCompanyPro();
	
	@Query("select i from Company c join c.items i where c.pro = true and i.deleted = false and c.id = ?1")
	Collection<Item> findAllItemsCompanyProId(int companyId);
	
	@Query("select i from Merchant m join m.items i where i.deleted = false and m.id = ?1")
	Collection<Item> findAllNotDeletedId(int merchantId);
	
	@Query("select i from Item i where i.title like %?1")
	Collection<Item> searchItems(String item);
	
	@Query("select i from Merchant m join m.items i where i.title like %?1% and m.id = ?2")
	Collection<Item> searchItemsByMerchant(String item, int merchantId);
	
	@Query("select i from Company c join c.items i where i.title like %?1% and c.id = ?2")
	Collection<Item> searchItemsByCompany(String item, int companyId);
	
	@Query("select i from Item i join i.comments c where c.id = ?1")
	Item itemByComment(int commentId);
}
