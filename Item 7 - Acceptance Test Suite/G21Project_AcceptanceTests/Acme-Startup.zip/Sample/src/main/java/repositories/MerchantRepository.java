
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Merchant;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Integer> {

	@Query("select a from Merchant a where a.userAccount.id = ?1")
	Merchant findByUserAccountId(int id);

	@Query("select m from Merchant m join m.items i where i.id = ?1")
	Merchant findByItem(int id);
}
