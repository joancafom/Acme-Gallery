package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.News;

@Repository
public interface NewsRepository extends JpaRepository<News, Integer>{

	//Dar la news de un cpomment
	@Query("select n from News n join n.comments c where c.id = ?1")
	News newsPerComment(int commentId);
	
	
	@Query("select count(c) from Comment c join c.comments cc where cc.id = ?1")
	int newsPerCommentInt(int newsId);
	
	
	
	
}
