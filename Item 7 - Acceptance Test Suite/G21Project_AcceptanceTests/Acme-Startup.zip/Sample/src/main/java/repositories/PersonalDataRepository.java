
package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.PersonalData;
import domain.User;

@Repository
public interface PersonalDataRepository extends JpaRepository<PersonalData, Integer> {
	
	@Query("select u.personalData from User u where u.id=?1")
	PersonalData personalDataPerUser(int userId);

	@Query("select u from User u join u.personalData p where p.id=?1")
	User userByPersonalDataId(int personalDataId);
}
