
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Admin;
import domain.Raffle;

@Repository
public interface RaffleRepository extends JpaRepository<Raffle, Integer> {

	@Query("select a.raffles from Admin a where a.id=?1")
	Collection<Raffle> rafflesPerAdmin(int adminId);

	@Query("select r from Raffle r join r.users u where u.id=?1")
	Collection<Raffle> rafflesPerUser(int userId);

	@Query("select a from Admin a join a.raffles r where r.id=?1")
	Admin adminByRaffleId(int raffleId);

	@Query("select r from Raffle r where r.title like %?1%")
	Collection<Raffle> rafflesPerTitle(String title);

	@Query("select r from Raffle r where r.dateFinish >= current_date and r.closed=false")
	Collection<Raffle> activeRaffles();

	@Query("select r from Raffle r where r.dateFinish <= current_timestamp and r.closed=false")
	Collection<Raffle> todayRaffles();

	@Query("select count(r) from Raffle r where r.id = ?1 and r.dateFinish < CURRENT_TIMESTAMP")
	Integer raffleActiveONo(int raffleId);
}
