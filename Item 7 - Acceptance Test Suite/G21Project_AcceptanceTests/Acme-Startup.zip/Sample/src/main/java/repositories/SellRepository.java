package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Sell;

@Repository
public interface SellRepository extends JpaRepository<Sell, Integer> {

	@Query("select sum(i.price - ((i.discount/100) * i.price)) from Sell s join s.items i where s.id = ?1")
	public double calculateTotal(int sellId);
	
	@Query("select s from Merchant m join m.sells s where m.id = ?1")
	public Collection<Sell> findSellsByMerchant(int id);
	
	@Query("select s from Merchant m join m.sells s where m.id = ?1 and s.closed = ?2")
	public Collection<Sell> findSellsByMerchantAndCondition(int id, boolean condition);
	
	@Query("select s from Company c join c.sells s where c.id = ?1")
	public Collection<Sell> findSellsByCompany(int id);
	
	@Query("select s from Company c join c.sells s where c.id = ?1 and s.closed = ?2")
	public Collection<Sell> findSellsByCompanytAndCondition(int id, boolean condition);
	
	@Query("select s from Sell s join s.items i where i.id = ?1")
	public Collection<Sell> findSellsByItem(int id);
}
