
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Spam;

@Repository
public interface SpamRepository extends JpaRepository<Spam, Integer> {

	//buscar una spam por una palabra
	@Query("select s from Spam s where s.name like %?1%")
	Collection<Spam> findAllSpamByKeyword(String keyword);

	@Query("select s from Spam s where s.name = ?1")
	Collection<Spam> findKeyWord(String keyword);

	@Query("select count(a) from Spam a where ?1 LIKE '%' || a.name || '%'")
	Integer findSpamInMessage(String phrase);

}
