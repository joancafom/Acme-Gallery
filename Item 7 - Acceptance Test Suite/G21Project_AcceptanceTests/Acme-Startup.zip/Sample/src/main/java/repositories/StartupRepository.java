package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Startup;

@Repository
public interface StartupRepository extends JpaRepository<Startup, Integer>{

	//Dar la startups de una category
	@Query("select t from Startup t join t.category tt where tt.id=?1")
	Collection<Startup> startupsPerCategory(int categoryId);
	
	//Dar la startups de una news
	@Query("select t from Startup t join t.news tt where tt.id=?1")
	Startup startupsPerNews(int newsId);
	
	//Dar la startups de una cooperates
	@Query("select s from Startup s join s.cooperates c where c.id = ?1")
	Startup startupsPerCooperate(int cooperateId);
	
	//Dar la startups de una offer
	@Query("select s from Startup s join s.offers c where c.id = ?1")
	Startup startupsPerOffer(int offerId);
	
	
	//Dar la startups por key word
	@Query("select t from Startup t where (t.name like %?1% or t.description like %?1%)")
	Collection<Startup> startupPerKeyWord(String keyWord);
	
}
