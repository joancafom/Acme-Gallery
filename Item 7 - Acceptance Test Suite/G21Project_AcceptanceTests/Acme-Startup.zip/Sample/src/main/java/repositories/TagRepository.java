package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Offer;
import domain.Startup;
import domain.Tag;

@Repository
public interface TagRepository extends JpaRepository<Tag, Integer> {

	
	
	//Dar las startup de una tag
//	@Query("select t from Startup t join t.tagValues tt join tt.tag ttt where ttt.id=?1")
//	Collection<Startup> startupsPerTag(int tagId);
	
	
/*	@Query("select tag from Tag tag join tag.tagValues tvt, Startup t join t.tagValues tv where tvt.id = tv.id and t.id=?1")
	Collection<Tag> tagPerStartup(int startupId);
	
	@Query("select s from Startup s join s.tagValues t where exists (select tg from Tag tg join tg.tagValues tt where tt.id = t.id and tg.id = ?1")
	Collection<Startup> startupPerTag(int tagId);*/
	
	
	@Query("select t from Startup t join t.tags jj where jj.id=?1")
	Collection<Startup> startupPerTag(int tagId);
	
	@Query("select t from Offer t join t.tags jj where jj.id=?1")
	Collection<Offer> offerPerTag(int tagId);
	
	
	
}
