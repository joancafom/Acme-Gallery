
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	@Query("select a from User a where a.userAccount.id = ?1")
	User findByUserAccountId(int id);

	
	@Query("select u from User u join u.startups tt where tt.id= ?1")
	Collection<User> usersPerStartup(int startupId);
	
	@Query("select u from User u join u.comments c where c.id = ?1")
	User findUserByComment(int commentId);
	
	
}
