
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.PersonalData;
import domain.User;
import domain.Work;

@Repository
public interface WorkRepository extends JpaRepository<Work, Integer> {

	@Query("select w from Work w where w.id = (select i.id from PersonalData p join p.interestDatas i where w.id=i.id and p.id=?1)")
	Collection<Work> workPerPersonalData(int personalDataId);
	
	@Query("select u from User u join u.personalData p join p.interestDatas i where i.id=?1")
	User userByWorkId(int workId);
	
	@Query("select p from PersonalData p join p.interestDatas i where i.id=?1")
	PersonalData personalDataByWorkId(int workId);
}
