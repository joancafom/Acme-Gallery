
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.Folder;
import domain.Message;
import repositories.ActorRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class ActorService {

	@Autowired
	private ActorRepository actorRepository;

	@Autowired
	private FolderService folderService;

	@Autowired
	private ConfigurationService configurationService;

	@Autowired
	private UserService userService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private SponsorService sponsorService;


	public ActorService() {
		super();
	}

	public Actor findOne(int actorId) {
		Actor result;
		result = actorRepository.findOne(actorId);
		Assert.notNull(result);
		return result;
	}

	public Actor save(Actor actor) {
		Assert.notNull(actor);
		return actorRepository.save(actor);
	}

	public Collection<Actor> findAll() {
		Collection<Actor> r;

		Assert.notNull(actorRepository);
		r = actorRepository.findAll();
		Assert.notNull(r);

		return r;
	}

	//----------------------------------------------------

	public Actor findByPrincipal() {
		Actor a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public Actor findByUserAccount(UserAccount userAccount) {
		Actor a;
		a = actorRepository.findByUserAccountId(userAccount.getId());
		return a;
	}

	public Collection<Folder> systemFolder() {
		Collection<Message> cM = new ArrayList<Message>();
		Folder m1 = new Folder();
		m1.setName("Inbox");
		m1.setSystem(true);
		m1.setMessages(cM);
		final Folder m1save = this.folderService.save(m1);

		final Folder m2 = new Folder();
		m2.setName("Outbox");
		m2.setSystem(true);
		m2.setMessages(cM);
		final Folder m2save = this.folderService.save(m2);

		final Folder m3 = new Folder();
		m3.setName("Spambox");
		m3.setSystem(true);
		m3.setMessages(cM);
		final Folder m3save = this.folderService.save(m3);

		final Folder m4 = new Folder();
		m4.setName("Trashbox");
		m4.setSystem(true);
		m4.setMessages(cM);
		final Folder m4save = this.folderService.save(m4);

		final Folder m5 = new Folder();
		m5.setName("Notificationbox");
		m5.setSystem(true);
		m5.setMessages(cM);
		final Folder m5save = this.folderService.save(m5);

		// Collection<MessageFolder>
		final Collection<Folder> messageFolders = new ArrayList<Folder>();
		messageFolders.add(m1save);
		messageFolders.add(m2save);
		messageFolders.add(m3save);
		messageFolders.add(m4save);
		messageFolders.add(m5save);

		return messageFolders;
	}

	public boolean isAuthenticated() {
		boolean result = false;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		if (userAccount != null)
			result = true;
		return result;
	}

	public String authorityByActorId(int id) {

		Assert.notNull(id);
		String result = actorRepository.findAuthorityActor(id);
		Assert.notNull(result);
		return result;

	}

	public Actor findActorForEmail(String email) {
		Assert.notNull(email);
		Actor result = actorRepository.findActorEmail(email);
		Assert.notNull(result);
		return result;
	}

	public Integer findEqualsUsername(String username) {
		Assert.notNull(username);
		Integer result = actorRepository.findCountUsernames(username);
		Assert.notNull(result);
		return result;
	}

	public Integer findEqualsEmail(String email) {
		Assert.notNull(email);
		Integer result = actorRepository.findCountEmail(email);
		Assert.notNull(result);
		return result;
	}

	public UserAccount findUserAccountId(int id) {
		UserAccount result = actorRepository.userAccountId(id);
		return result;
	}

	public Collection<String> emailsSavedInBD() {
		Collection<String> em = actorRepository.emailsSavedInBD(this.findByPrincipal().getEmail());
		Assert.notNull(em);
		return em;
	}

	public Boolean existEmail(String email) {
		Boolean result = false;
		Collection<String> emails = actorRepository.getAllEmails();
		if (emails.contains(email)) {
			result = true;
		}
		return result;
	}

	public String patronPhone() {
		String result = "+" + configurationService.countryCodePhone() + " ";
		return result;
	}

	public Collection<Actor> actorBanneds() {
		Collection<Actor> cA = actorRepository.actorBanneds();
		Assert.notNull(cA);
		return cA;
	}

	public Collection<Actor> findAllActors() {
		Collection<Actor> result = new HashSet<Actor>();
		result.addAll(userService.findAll());
		result.addAll(companyService.findAll());
		result.addAll(sponsorService.findAll());
		result.addAll(merchantService.findAll());
		return result;
	}

	public Actor actorPerId(int actorId) {
		Actor result = actorRepository.actorPerId(actorId);
		Assert.notNull(result);
		return result;
	}

	public Collection<Actor> actorsPRO() {
		Collection<Actor> result = actorRepository.actorsPRO();
		Assert.notNull(result);
		return result;
	}

}
