
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Folder;
import domain.Raffle;
import repositories.AdminRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class AdminService {

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private ActorService actorService;


	public AdminService() {
		super();
	}

	public Admin create() {
		Admin result;
		result = new Admin();
		Collection<Folder> f = actorService.systemFolder();
		result.setFolders(f);
		Collection<Raffle> raffles = new HashSet<Raffle>();
		result.setRaffles(raffles);
		return result;
	}

	public Admin findOne(int adminId) {
		Admin result;

		result = adminRepository.findOne(adminId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Admin> findAll() {
		Collection<Admin> result;

		result = adminRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Admin save(Admin admin) {
		Assert.notNull(admin);
		Admin result = new Admin();
		if (!admin.getPhone().isEmpty()) {
			if (!admin.getPhone().trim().substring(0, 1).equals("+")) {
				admin.setPhone(actorService.patronPhone() + admin.getPhone());
				result = adminRepository.save(admin);
			}
		} else {
			result = adminRepository.save(admin);
		}
		Assert.notNull(result);
		return result;
	}

	public void delete(Admin admin) {
		Assert.notNull(admin);
		Assert.isTrue(admin.getId() != 0);
		Assert.isTrue(adminRepository.exists(admin.getId()));

		adminRepository.delete(admin);
	}

	//-------------------------------------------------------------

	public Admin findByPrincipal() {
		Admin a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public Admin findByUserAccount(UserAccount userAccount) {
		Assert.notNull(userAccount);
		Admin a;
		a = adminRepository.findByUserAccountId(userAccount.getId());
		return a;
	}

	//---------------------------------------------------------------------------

	public Object[] offerstPerStartup() {
		Object[] result = adminRepository.offerstPerStartup();
		Assert.notNull(result);
		return result;
	}

	public Object[] commentsPerUser() {
		Object[] result = adminRepository.commentsPerUser();
		Assert.notNull(result);
		return result;
	}

	public Object[] offerstPerPersonalData() {
		Object[] result = adminRepository.offerstPerPersonalData();
		Assert.notNull(result);
		return result;
	}

	public Object[] startupsPerCompany() {
		Object[] result = adminRepository.startupsPerCompany();
		Assert.notNull(result);
		return result;
	}

	public Object[] usersPerRaffle() {
		Object[] result = adminRepository.usersPerRaffle();
		Assert.notNull(result);
		return result;
	}

	public Object[] commentsPerNews() {
		Object[] result = adminRepository.commentsPerNews();
		Assert.notNull(result);
		return result;
	}

	public Double avgOffersPerStartupAverage() {
		Double result = adminRepository.avgOffersPerStartupAverage();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double avgNewsPerStartupAverage() {
		Double result = adminRepository.avgNewsPerStartupAverage();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double avgUsersPro() {
		Double result = adminRepository.avgUsersPro();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double stddevUsersPro() {
		Double result = adminRepository.stddevUsersPro();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Integer countUsersPro() {
		Integer result = adminRepository.countUsersPro();
		if (result == null) {
			result = 0;
		}
		return result;
	}

	public Double avgCompaniesPro() {
		Double result = adminRepository.avgCompaniesPro();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double stddevCompaniesPro() {
		Double result = adminRepository.stddevCompaniesPro();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Integer countCompaniesPro() {
		Integer result = adminRepository.countCompaniesPro();
		if (result == null) {
			result = 0;
		}
		return result;
	}

	public Double itemsPerCompanyEnVenta() {
		Double result = adminRepository.itemsPerCompanyEnVenta();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double itemsBuyStorePerUser() {
		Double result = adminRepository.itemsBuyStorePerUser();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Collection<Raffle> rafflesEnds() {
		Collection<Raffle> result = adminRepository.rafflesEnds();
		Assert.notNull(result);
		return result;
	}

	public Collection<Raffle> rafflesNoEnd() {
		Collection<Raffle> result = adminRepository.rafflesNoEnd();
		Assert.notNull(result);
		return result;
	}

	public Double percentWorksInterestingData() {
		Double result = adminRepository.percentWorksInterestingData();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double percentEducationsInterestingData() {
		Double result = adminRepository.percentEducationsInterestingData();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double percentUsers() {
		Double result = adminRepository.percentUsers();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double percentCompanies() {
		Double result = adminRepository.percentCompanies();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double percentMerchants() {
		Double result = adminRepository.percentMerchants();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Double percentSponsors() {
		Double result = adminRepository.percentSponsors();
		if (result == null) {
			result = 0.0;
		}
		return result;
	}

	public Object[] sellsPerMerchants() {
		Object[] result = adminRepository.sellsPerMerchants();
		Assert.notNull(result);
		return result;
	}

	public Object[] sellsPerCompanies() {
		Object[] result = adminRepository.sellsPerCompanies();
		Assert.notNull(result);
		return result;
	}

	public Object[] announcementsPerSponsor() {
		Object[] result = adminRepository.announcementsPerSponsor();
		Assert.notNull(result);
		return result;
	}

	public Object[] itemsPerUser() {
		Object[] result = adminRepository.itemsPerUser();
		Assert.notNull(result);
		return result;
	}

	public Object[] itemsPerSponsor() {
		Object[] result = adminRepository.itemsPerSponsor();
		Assert.notNull(result);
		return result;
	}

}
