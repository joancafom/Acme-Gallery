package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Announcement;
import domain.Sponsor;
import repositories.AnnouncementRepository;

@Service
@Transactional
public class AnnouncementService {
	
	@Autowired
	private AnnouncementRepository announcementRepository;
	
	@Autowired
	private SponsorService sponsorService;
	
	@Autowired
	private AdminService adminService;
	
	public AnnouncementService() {
		super();
	}
	
	// Simple CRUD methods ----------------------------------------------------

	public Announcement create() {
		Sponsor sp = sponsorService.findByPrincipal();
		Assert.notNull(sp);

		Announcement res = new Announcement();

		return res;
	}
	
	
	public Collection<Announcement> findAll() {
		Collection<Announcement> res;
		res = announcementRepository.findAll();
		Assert.notNull(res);

		return res;
	}

	public Announcement findOne(int announcementId) {
		Assert.isTrue(announcementId != 0);
		Announcement res = announcementRepository.findOne(announcementId);
		Assert.notNull(res);
		return res;
	}
	
	public Announcement save(Announcement announcement) {
		Assert.notNull(announcement);

		Sponsor sp = sponsorService.findByPrincipal();
		Assert.notNull(sp);
		Announcement result = announcementRepository.save(announcement);
		Assert.notNull(announcement);
		
		
		//Meter en la coleccion de anuncios del agente este nuevo
		Collection<Announcement> announcements = new ArrayList<Announcement>();
		announcements=sp.getAnnouncements();
		announcements.add(result);
		sp.setAnnouncements(announcements);
		
		sponsorService.save(sp);

		return result;
	}
	
	
	
	public void delete(Announcement announcement) {
		
		Assert.notNull(announcement);
		Assert.isTrue(announcementRepository.exists(announcement.getId()));

		//Quitar del sponsor este announcement
		Sponsor sp = announcementRepository.sponsorPerAnnouncement(announcement.getId());
		Collection<Announcement> advs = new ArrayList<Announcement>();
		advs = sp.getAnnouncements();
		advs.remove(announcement);
		sp.setAnnouncements(advs);
		sponsorService.saveAnnouncement(sp);
		
		
		announcementRepository.delete(announcement.getId());

	}
	
	
/*	public void deleteNewspaper(Advertisement advertisement) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
	//	Assert.notNull(advertisement);
	//	Assert.isTrue(advertisementRepository.exists(advertisement.getId()));

		//Quitar del agent este advertisement
		Agent ag = agentService.agentPerAdvertisement(advertisement.getId());
		Collection<Advertisement> advs = new ArrayList<Advertisement>();
		advs = ag.getAdvertisements();
		advs.remove(advertisement);
		ag.setAdvertisements(advs); 
		agentService.save(ag);
		
		advertisementRepository.delete(advertisement.getId());

	}
*/	
	//Otros metodos---------------------------------------------
	
	
/*	public Collection<Announcement> announcementWithSpam() {
		Collection<Announcement> res;
		res = announcementRepository.announcementWithSpam();
		Assert.notNull(res);

		return res;
	}
*/	
	
	public Sponsor sponsorPerAnnouncement(int announcementId) {
		Sponsor a;
		a = announcementRepository.sponsorPerAnnouncement(announcementId);
		return a;
	}
	
}
