
package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Basket;
import domain.Company;
import domain.CreditCard;
import domain.Item;
import domain.Merchant;
import domain.Sell;
import domain.Sponsor;
import domain.User;
import repositories.BasketRepository;
import security.UserAccount;

@Service
@Transactional
public class BasketService {

	@Autowired
	private BasketRepository basketRepository;

	@Autowired
	private ItemService itemService;

	@Autowired
	private SponsorService sponsorService;

	@Autowired
	private ActorService actorService;

	@Autowired
	private UserService userService;

	@Autowired
	private SellService sellService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;


	public BasketService() {
		super();
	}

	public Basket create() {
		Basket basket;

		basket = new Basket();

		return basket;
	}

	public Basket findOne(int basketId) {
		Assert.notNull(basketId);
		Basket result;

		result = this.basketRepository.findOne(basketId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Basket> findAll() {
		Collection<Basket> result;

		result = this.basketRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Basket save(Basket basket) {
		Basket result;
		
		result = this.basketRepository.save(basket);
		Assert.notNull(result);

		return result;
	}

	public void delete(Basket basket) {
		Assert.notNull(basket);
		Assert.isTrue(basketRepository.exists(basket.getId()));

		this.basketRepository.delete(basket);
	}

	public Basket findByPrincipal() {
		Basket result = this.create();
		UserAccount userAccount;
		Sponsor sponsor;
		User user;

		userAccount = this.actorService.findByPrincipal().getUserAccount();
		sponsor = this.sponsorService.findByUserAccount(userAccount);
		user = this.userService.findByUserAccount(userAccount);

		if (user == null) {
			if (sponsor == null) {
				Assert.notNull(sponsor, "La anunciante es nula");
			} else {
				result = sponsor.getBasket();
			}
		} else {
			result = user.getBasket();
		}
		return result;
	}

	public Basket addProduct(int itemId) {
		Assert.notNull(itemId);
		Basket basket;
		Item item;

		item = this.itemService.findOne(itemId);
		Assert.isTrue(!item.getDeleted(), "Este item no esta disponible");

		basket = this.findByPrincipal();
		basket.getItems().add(item);
		basket.setTotal(this.calculateTotal(basket));

		this.save(basket);
		

		return basket;
	}

	public Basket deleteProduct(int itemId) {
		Assert.notNull(itemId);
		Basket basket;
		Item item;

		item = this.itemService.findOne(itemId);

		basket = this.findByPrincipal();
		Assert.isTrue(basket.getItems().contains(item), "La cesta no contiene el item");
		basket.getItems().remove(item);
		basket.setTotal(this.calculateTotal(basket));

		this.save(basket);

		return basket;
	}

	public double calculateTotal(Basket basket) {
		Assert.notNull(basket);
		double result;

		if (basket.getItems().size() == 0) {
			result = 0;
		} else {
			result = this.basketRepository.calculateTotal(basket.getId());
			Assert.notNull(result);
		}

		return result;
	}

	public void isValidCreditCard(CreditCard creditCard) {
		Assert.notNull(creditCard);
		DateTime date;
		Integer currentYear;
		int currentMonth;
		int year;
		int month;

		date = new DateTime(System.currentTimeMillis());
		currentYear = Integer.parseInt(String.valueOf(date.getYear()).substring(2));
		currentMonth = date.getMonthOfYear();

		year = Integer.parseInt(creditCard.getExpirationYear());
		month = Integer.parseInt(creditCard.getExpirationMonth());

		Assert.isTrue(!(currentYear > year), "La tarjeta ha caducado");
		if (currentYear == year && month <= currentMonth) {
			Assert.isTrue(false, "La tarjeta ha caducado");
		}
	}

	public void pay(CreditCard creditCard, String direction) {
		Assert.notNull(creditCard);
		Assert.notNull(direction);
		Basket basket;
		Sell sell = this.sellService.create();
		boolean first = true;
		int previousId = 0;
		Collection<Object[]> merchantItems;
		Collection<Object[]> companyItems;
		Collection<Object[]> total = new ArrayList<Object[]>();
		Collection<Item> listItems = new ArrayList<Item>();
		Merchant merchant = this.merchantService.create();
		Company company = this.companyService.create();
		Item item;
		Sell auxiliar;
		
		basket = this.findByPrincipal();
		merchantItems = this.basketRepository.getBasketMerchantsAndItems(basket.getId());
		companyItems = this.basketRepository.getBasketCompanyAndItems(basket.getId());

		if (merchantItems == null) {
			if (companyItems == null) {
				Assert.isTrue(true, "La cesta est� vac�a");
			} else {
				total = companyItems;
			}
		} else {
			total = merchantItems;
			if (companyItems != null) {
				total.addAll(companyItems);
			}
		}
		for (Object[] t : total) {
			if (first) {
				previousId =(int) t[0];
				sell = this.sellService.create();
				sell.setClosed(false);
				sell.setDirection(direction);
				sell.setTotal(0);
				listItems = new ArrayList<Item>();
				sell.setItems(listItems);
				first = false;
			}
			if (previousId != (int) t[0]) {
				sell.setItems(listItems);
				merchant = this.merchantService.findOneWIthoutExceptions(previousId);
				company = this.companyService.findOneWithoutException(previousId);
				
				auxiliar = this.sellService.save(sell);
				auxiliar.setTotal(this.sellService.calculateTotal(auxiliar));
				auxiliar = this.sellService.save(auxiliar);
				if (merchant !=  null) {
					merchant.getSells().add(auxiliar);
				} else {
					company.getSells().add(auxiliar);
				}
				sell = this.sellService.create();
				sell.setClosed(false);
				sell.setTotal(0);
				sell.setDirection(direction);
				listItems = new ArrayList<Item>();
				sell.setItems(listItems);
			}
			listItems.add((Item) t[1]);
			previousId = (int) t[0];
			item = (Item) t[1];
			merchant = this.merchantService.findByItem(item.getId());
			company = this.companyService.findByItem(item.getId());
		}
		sell.setItems(listItems);
		
		auxiliar = this.sellService.save(sell);
		
		if (merchant !=  null) {
			merchant.getSells().add(auxiliar);
			this.merchantService.save(merchant);
		} else {
			company.getSells().add(auxiliar);
			this.companyService.save(company);
		}
		basket.setItems(new ArrayList<Item>());
		basket.setTotal(0);
		this.save(basket);
	}
}
