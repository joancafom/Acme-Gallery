package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.BuyStore;
import repositories.BuyStoreRepository;

@Service
@Transactional
public class BuyStoreService {

	@Autowired
	private BuyStoreRepository buyStoreRepository;

	public BuyStoreService() {
		super();
	}

	// METODOS CRUD ----------------------------------------------

	public BuyStore create() {
		BuyStore buyStore;
		buyStore = new BuyStore();

		return buyStore;
	}

	public Collection<BuyStore> findAll() {
		Collection<BuyStore> buyStores;
		Assert.notNull(this.buyStoreRepository);

		buyStores = this.buyStoreRepository.findAll();
		Assert.notNull(buyStores);

		return buyStores;
	}

	public BuyStore findOne(int buyStoreId) {
		BuyStore result;

		result = buyStoreRepository.findOne(buyStoreId);
		Assert.notNull(result);

		return result;
	}

	public BuyStore save(BuyStore buyStore) {
		Assert.notNull(buyStore);

		BuyStore result = buyStoreRepository.save(buyStore);

		return result;

	}

	public void delete(BuyStore buyStore) {
		Assert.notNull(buyStore);

		Collection<BuyStore> buyStores = buyStoreRepository.findAll();
		buyStores.remove(buyStore);
		buyStoreRepository.delete(buyStore);
	}

}
