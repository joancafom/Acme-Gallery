package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Category;
import domain.Startup;
import repositories.CategoryRepository;

@Service
@Transactional
public class CategoryService {
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private StartupService startupService;
	
	//Constructor--------------------------------
	public CategoryService() {
		super();
	}
	
	//Metodos CRUD------------------------------
	
	public Category create() {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Category res = new Category();
		//Al crear que el padre sea CATEGORY
		res.setFather(categoryRepository.getCATEGORY());
		return res;
	}
	
	
	public Collection<Category> findAll() {
		Collection<Category> res;
		res = categoryRepository.findAll();
		Assert.notNull(res);
		return res;
	}
	
	
	
	public Category findOne(int categoryId) {
		Assert.isTrue(categoryId != 0);
		Category res = categoryRepository.findOne(categoryId);
		Assert.notNull(res);
		return res;
	}
	
	
	public Category save(Category category) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(category);
		// No hay ninguna regla que comprobar
		Category result = categoryRepository.save(category);
		
		Assert.notNull(result);
		return result;
	}
	
	
	
	public void delete(Category category) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(category);
		Assert.isTrue(categoryRepository.exists(category.getId()));
		
		Collection<Startup> startups= new ArrayList<Startup>();
		startups = startupService.startupsPerCategory(category.getId());

		// primero borramos la relacion con startup
		for (Startup t : startups) {
			Category arriba = categoryRepository.getCATEGORY();
			t.setCategory(arriba);
			startupService.saveCategory(t);
		}
				
		Category principal = categoryRepository.getCATEGORY();
		Collection<Category> aux=new ArrayList<Category>();
		aux = principal.getSons();
		aux.remove(category);
		Collection<Category> aux2=new ArrayList<Category>();
		Collection<Category> aux3=new ArrayList<Category>();

		if ( category.getFather().equals(principal)){
			
			aux2=category.getSons();
			category.setSons(new ArrayList<Category>());
			for (Category c : aux2){
				c.setFather(principal);
				this.save(c);
				aux.add(c);
			}
			principal.setSons(aux);
			this.save(principal);
		}else{
			aux2=category.getSons();
			category.setSons(new ArrayList<Category>());
			aux3=category.getFather().getSons();
			aux3.remove(category);
			category.getFather().setSons(aux3);
			this.save(category.getFather());

			for (Category c : aux2){
				c.setFather(principal);
				this.save(c);
				aux.add(c);
			}
			principal.setSons(aux);
			this.save(principal);
		}
		
		categoryRepository.delete(category.getId());
		
	}
	
	
	
	
	//Other methods---------------------------------------------------
	public Category getCategoryPrincipal() {
		return categoryRepository.getCATEGORY();
	}

}
