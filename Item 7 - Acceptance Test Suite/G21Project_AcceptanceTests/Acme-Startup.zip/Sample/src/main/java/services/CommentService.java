package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Comment;
import domain.Item;
import domain.News;
import domain.User;
import repositories.CommentRepository;


@Service
@Transactional
public class CommentService {

	@Autowired
	private CommentRepository	commentRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private NewsService newsService;


	public CommentService() {
		super();
	}

	//METODOS CRUD ----------------------------------------------
	
	public Comment create() {
		Comment comment;
		comment= new Comment();
	
		return comment;
	}

	public Collection<Comment> findAll() {
		Collection<Comment> comments;
		Assert.notNull(this.commentRepository);
		
		comments = this.commentRepository.findAll();
		Assert.notNull(comments);
		
		return comments;
	}

	public Comment findOne(int commentId) {
		Comment result;
	
		result = commentRepository.findOne(commentId);
		Assert.notNull(result);
		
		return result;
	}

	public Comment save(Comment comment) {
		Assert.notNull(comment);
		
		Comment result = commentRepository.save(comment);

		return result;

	}

	public void delete(Comment comment) {
		Assert.notNull(comment);
		Assert.isTrue(this.commentRepository.exists(comment.getId()));
		
		commentRepository.delete(comment);
	}
	
	public Comment saveComment(Comment comment, int commentId) {
		Assert.notNull(commentId);
		Comment result;
		User user;
		Comment commentAux;
		
		if (comment.getId() != 0) {
			result = this.save(comment);
		} else {
			commentAux = this.findOne(commentId);
			
			user = this.userService.findByPrincipal();
			result = this.save(comment);
			user.getComments().add(result);
			commentAux.getComments().add(result);
		}
		
		return result;
	}
	
	public Comment saveCommentNew(Comment comment, int newId) {
		Assert.notNull(comment);
		Assert.notNull(newId);
		Comment result;
		User user;
		News news;
		
		if (comment.getId() != 0) {
			result = this.save(comment);
		} else {
			news = this.newsService.findOne(newId);
			
			user = this.userService.findByPrincipal();
			result = this.save(comment);
			user.getComments().add(result);
			news.getComments().add(result);
		}
		
		return result;
	}
	
	public Comment saveCommentItem(Comment comment, int itemId) {
		Assert.notNull(comment);
		Assert.notNull(itemId);
		Comment result;
		User user;
		Item item;
		
		if (comment.getId() != 0) {
			result = this.save(comment);
		} else {
			item = this.itemService.findOne(itemId);
			
			user = this.userService.findByPrincipal();
			result = this.save(comment);
			user.getComments().add(result);
			item.getComments().add(result);
		}
		
		return result;
	}
	
	public Comment findPrincipal(int commentId) {
		Assert.notNull(commentId);
		Comment result;
		
		result = this.commentRepository.findPrincipal(commentId);
		
		return result;
	}
	
	public void deleteComplete(int commentId) {
		Assert.notNull(commentId);
		Comment comment;
		News news;
		Item item;
		User user;
		Comment aux;
		Collection<Comment> hijos;
		
		item = this.itemService.itemByComment(commentId);
		news = this.newsService.newsPerComment(commentId);
		comment = this.commentRepository.findPrincipal(commentId);
		
		if (item == null) {
			if (news == null) {
				if (comment == null) {
					Assert.isTrue(true);
				} else {
					/*comment.getComments().remove(comment);
					this.delete(this.findOne(commentId));*/
					
					aux = this.findOne(commentId);
					user = this.userService.findUserByComment(commentId);
					
					user.getComments().remove(aux);
					comment.getComments().remove(aux);
					
					hijos = aux.getComments();
					aux.setComments(new ArrayList<Comment>());
					for (Comment c : hijos) {
						user = this.userService.findUserByComment(c.getId());
						user.getComments().remove(c);
						this.delete(c);
					}
					
					this.delete(aux);
				}
			} else {
				aux = this.findOne(commentId);
				user = this.userService.findUserByComment(commentId);
				
				user.getComments().remove(aux);
				news.getComments().remove(aux);
				
				hijos = aux.getComments();
				aux.setComments(new ArrayList<Comment>());
				for (Comment c : hijos) {
					user = this.userService.findUserByComment(c.getId());
					user.getComments().remove(c);
					this.delete(c);
				}
				
				this.delete(aux);
				
				
				//this.deleteComment(commentId);
			}
		} else {
			aux = this.findOne(commentId);
			user = this.userService.findUserByComment(commentId);
			
			item.getComments().remove(aux);
			
			user.getComments().remove(aux);
			item.getComments().remove(aux);
			
			hijos = aux.getComments();
			aux.setComments(new ArrayList<Comment>());
			for (Comment c : hijos) {
				user = this.userService.findUserByComment(c.getId());
				user.getComments().remove(c);
				this.delete(c);
			}
			
			this.delete(aux);
			
			//this.deleteComment(commentId);
		}
	}
	
	
	
	
	public void deleteNews(int commentId) {
		Assert.notNull(commentId);
		Comment comment;
		News news;
		Item item;
		User user;
		Comment aux;
		Collection<Comment> hijos;
		
		item = this.itemService.itemByComment(commentId);
		news = this.newsService.newsPerComment(commentId);
		comment = this.commentRepository.findPrincipal(commentId);
		
		if (item == null) {
			if (news != null) {
				if (comment == null) {
					Assert.isTrue(true);
				} else {
					/*comment.getComments().remove(comment);
					this.delete(this.findOne(commentId));*/
					
					aux = this.findOne(commentId);
					user = this.userService.findUserByComment(commentId);
					
					user.getComments().remove(aux);
					comment.getComments().remove(aux);
					
					hijos = aux.getComments();
					aux.setComments(new ArrayList<Comment>());
					for (Comment c : hijos) {
						user = this.userService.findUserByComment(c.getId());
						user.getComments().remove(c);
						this.delete(c);
					}
					
					this.delete(aux);
				}
			} else {
				aux = this.findOne(commentId);
				user = this.userService.findUserByComment(commentId);
				
				user.getComments().remove(aux);
				news.getComments().remove(aux);
				
				hijos = aux.getComments();
				aux.setComments(new ArrayList<Comment>());
				for (Comment c : hijos) {
					user = this.userService.findUserByComment(c.getId());
					user.getComments().remove(c);
					this.delete(c);
				}
				
				this.delete(aux);
				
				
				//this.deleteComment(commentId);
			}
		} else {
			aux = this.findOne(commentId);
			user = this.userService.findUserByComment(commentId);
			
			item.getComments().remove(aux);
			
			user.getComments().remove(aux);
			item.getComments().remove(aux);
			
			hijos = aux.getComments();
			aux.setComments(new ArrayList<Comment>());
			for (Comment c : hijos) {
				user = this.userService.findUserByComment(c.getId());
				user.getComments().remove(c);
				this.delete(c);
			}
			
			this.delete(aux);
			
			//this.deleteComment(commentId);
		}
	}

}
