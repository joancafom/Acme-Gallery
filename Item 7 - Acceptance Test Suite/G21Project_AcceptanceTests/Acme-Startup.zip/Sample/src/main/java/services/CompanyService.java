
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Company;
import domain.Folder;
import domain.Item;
import domain.News;
import domain.Offer;
import domain.Sell;
import domain.Startup;
import repositories.CompanyRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class CompanyService {

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private ActorService actorService;


	public Company create() {
		Company result;
		result = new Company();
		Collection<Folder> f = actorService.systemFolder();
		result.setFolders(f);
		Collection<Sell> shells = new HashSet<Sell>();
		result.setSells(shells);
		Collection<Item> items = new HashSet<Item>();
		result.setItems(items);
		Collection<Offer> offers = new HashSet<Offer>();
		result.setOffers(offers);
		Collection<Startup> startups = new HashSet<Startup>();
		result.setStartups(startups);
		Collection<News> news = new HashSet<News>();
		result.setNews(news);
		return result;
	}

	public Company findOne(int companyId) {
		Company result;

		result = companyRepository.findOne(companyId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Company> findAll() {
		Collection<Company> result;

		result = companyRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Company save(Company company) {
		Assert.notNull(company);
		Company result = new Company();
		if (!company.getPhone().isEmpty()) {
			if (!company.getPhone().trim().substring(0, 1).equals("+")) {
				company.setPhone(actorService.patronPhone() + company.getPhone());
				result = companyRepository.save(company);
			}
		} else {
			result = companyRepository.save(company);
		}
		Assert.notNull(result);
		return result;
	}

	public void delete(Company company) {
		Assert.notNull(company);
		Assert.isTrue(company.getId() != 0);
		Assert.isTrue(companyRepository.exists(company.getId()));

		companyRepository.delete(company);
	}

	//-------------------------------------------------------------

	public Company findByPrincipal() {
		Company a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public Company findByUserAccount(UserAccount userAccount) {
		Assert.notNull(userAccount);
		Company a;
		a = companyRepository.findByUserAccountId(userAccount.getId());
		return a;
	}
	
	public Company findByItem(int itemId) {
		Assert.notNull(itemId);
		Company result;
		
		result = this.companyRepository.findByItem(itemId);
		
		return result;
	}
	
	public Company findOneWithoutException(int companyId) {
		Assert.notNull(companyId);
		Company result;
		
		result = this.companyRepository.findOne(companyId);
		
		return result;
	}
	
	
	public Company companyPerOffer(int offferId) {
		Company result;
		
		result = companyRepository.companyPerOffer(offferId);
		
		return result;
	}
	
	public Company companyPerNews(int newsId) {
		Company result;
		
		result = companyRepository.companyPerNews(newsId);
		
		return result;
	}

	
	
	
	
}
