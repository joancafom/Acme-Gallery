
package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Configuration;
import repositories.ConfigurationRepository;

@Service
@Transactional
public class ConfigurationService {

	// Managed repository -----------------------------------------------------
	@Autowired
	private ConfigurationRepository configurationRepository;

	// Supporting services ----------------------------------------------------
	@Autowired
	private AdminService adminService;


	public ConfigurationService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Configuration create() {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);

		Configuration res = new Configuration();

		return res;
	}

	public Collection<Configuration> findAll() {
		Collection<Configuration> res;
		res = configurationRepository.findAll();
		Assert.notNull(res);

		return res;
	}

	public Configuration findOne(int configuration) {
		Assert.isTrue(configuration != 0);
		Configuration res = configurationRepository.findOne(configuration);
		Assert.notNull(res);
		return res;
	}

	public Configuration save(Configuration configuration) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(configuration);
		//No hay ninguna regla que comprobar
		Configuration result = configurationRepository.save(configuration);
		Assert.notNull(result);
		return result;
	}

	public void delete(Configuration configuration) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(configuration);
		Assert.isTrue(configurationRepository.exists(configuration.getId()));

		configurationRepository.delete(configuration.getId());
	}

	public int countryCodePhone() {
		return configurationRepository.findCountryCode();
	}

}
