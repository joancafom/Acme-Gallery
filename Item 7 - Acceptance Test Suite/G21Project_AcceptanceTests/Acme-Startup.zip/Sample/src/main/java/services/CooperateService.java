package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Cooperate;
import domain.CreditCard;
import domain.Sponsor;
import domain.Startup;
import repositories.CooperateRepository;

@Service
@Transactional
public class CooperateService {

	@Autowired
	private CooperateRepository cooperateRepository;
	
	@Autowired
	private SponsorService sponsorService;
	
	public Cooperate create() {
		Cooperate result;
		
		result = new Cooperate();
		
		return result;
	}
	
	public Cooperate findOne(int cooperateId) {
		Cooperate result;
		
		result = this.cooperateRepository.findOne(cooperateId);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Cooperate> findAll() {
		Collection<Cooperate> result;
		
		result = this.cooperateRepository.findAll();
		Assert.notNull(result);
		
		return result;
	}
	
	public Cooperate save(Cooperate cooperate) {
		Assert.notNull(cooperate);
		Cooperate result;
		
		result = this.cooperateRepository.save(cooperate);
		Assert.notNull(result);
		
		return result;
	}
	
	public void delete(Cooperate cooperate) {
		Assert.notNull(cooperate);
		Assert.isTrue(this.cooperateRepository.exists(cooperate.getId()));
		
		this.cooperateRepository.delete(cooperate);
	}
	
	public Collection<Cooperate> findCooperatesByPrincipal() {
		Collection<Cooperate> result;
		Sponsor sponsor;
		
		sponsor = this.sponsorService.findByPrincipal();
		Assert.notNull(sponsor);
		
		result = this.cooperateRepository.findCooperatesByPrincipal(sponsor.getId());
		Assert.notNull(result);
		
		return result;
	}
	
	public Cooperate save(Cooperate cooperate, Startup startup) {
		Assert.notNull(cooperate);
		Assert.notNull(startup);
		Cooperate result;
		Sponsor sponsor;
		
		result = this.save(cooperate);
		Assert.notNull(result);
		
		sponsor = this.sponsorService.findByPrincipal();
		sponsor.getCooperates().add(result);
		startup.getCooperates().add(result);
		
		return result;
	}
	
	public void isValidCreditCard(CreditCard creditCard) {
		Assert.notNull(creditCard);
		DateTime date;
		Integer currentYear;
		int currentMonth;
		int year;
		int month;
		
		date = new DateTime(System.currentTimeMillis());
		currentYear = Integer.parseInt(String.valueOf(date.getYear()).substring(2));
		currentMonth = date.getMonthOfYear();
		
		year = Integer.parseInt(creditCard.getExpirationYear());
		month = Integer.parseInt(creditCard.getExpirationMonth());

		
		Assert.isTrue(!(currentYear > year), "La tarjeta ha caducado");
		if (currentYear == year && month <= currentMonth) {
			Assert.isTrue(false, "La tarjeta ha caducado");
		}
	}
	
	public Cooperate find(int cooperateId) {
		Assert.notNull(cooperateId);
		Sponsor sponsor;
		Cooperate result;
		
		sponsor = this.sponsorService.findByPrincipal();
		
		result = this.findOne(cooperateId);
		Assert.isTrue(sponsor.getCooperates().contains(result), "No puede acceder a esta cooperacion");
		
		return result;
	}
	
	public void checkCooperate(Cooperate cooperate) {
		Assert.notNull(cooperate);
		Sponsor sponsor;
		
		sponsor = this.sponsorService.findByPrincipal();
		Assert.isTrue(sponsor.getCooperates().contains(cooperate), "No puede acceder a esta cooperacion");
	}
	
	public void deleteCooperate(int cooperateId, Startup startup) {
		Assert.notNull(cooperateId);
		Assert.notNull(startup);
		Cooperate cooperate;
		Sponsor sponsor;
		
		cooperate = this.find(cooperateId);
		
		sponsor = this.sponsorService.findByPrincipal();
		sponsor.getCooperates().remove(cooperate);
		startup.getCooperates().remove(cooperate);
		
		this.delete(cooperate);
	}
	
	
	
	public void deleteStartup(int cooperateId) {
		Assert.notNull(cooperateId);
		Cooperate cooperate;
		Sponsor sponsor;
		
		cooperate = cooperateRepository.findOne(cooperateId);
		
		sponsor = sponsorService.findSponsorByCooperate(cooperate);
		sponsor.getCooperates().remove(cooperate);
		
		this.delete(cooperate);
	}
}
