package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Education;
import domain.PersonalData;
import domain.User;
import repositories.EducationRepository;


@Service
@Transactional
public class EducationService {

	@Autowired
	private EducationRepository	educationRepository;


	public EducationService() {
		super();
	}

	//METODOS CRUD ----------------------------------------------
	
	public Education create() {
		Education education;
		education = new Education();

		return education;
	}

	public Collection<Education> findAll() {
		Collection<Education> educations;
		Assert.notNull(this.educationRepository);
		
		educations = this.educationRepository.findAll();
		Assert.notNull(educations);
		
		return educations;
	}

	public Education findOne(int educationId) {
		Education result;
	
		result = educationRepository.findOne(educationId);
		Assert.notNull(result);
		
		return result;
	}

	public Education save(Education education) {
		Assert.notNull(education);
		
		Education result = educationRepository.save(education);

		return result;

	}

	public void delete(Education education) {
		Assert.notNull(education);
		
		Collection<Education> educations = educationRepository.findAll();
		educations.remove(education);
		educationRepository.delete(education);
	}
	
	//Bussines method
	
	public Collection<Education> educationPerPersonalData(int personalDataId) {
		Collection<Education> res = educationRepository.educationPerPersonalData(personalDataId);

		return res;
	}
	
	public User userByEducationId(int educationId) {
		User res = educationRepository.userByEducationId(educationId);
		Assert.notNull(res);
		
		return res;
	}
	
	public PersonalData personalDataByEducationId(int educationId) {
		PersonalData res = educationRepository.personalDataByEducationId(educationId);
		Assert.notNull(res);
		
		return res;
	}
}
