
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.Folder;
import domain.Message;
import repositories.FolderRepository;

@Service
@Transactional
public class FolderService {

	@Autowired
	private FolderRepository	folderRepository;
	@Autowired
	private MessageService		messageService;
	@Autowired
	private ActorService		actorService;


	public FolderService() {
		super();
	}

	public Folder create() {
		Folder res;
		res = new Folder();
		Collection<Message> cM = new HashSet<Message>();
		res.setMessages(cM);
		Folder f = new Folder();
		res.setFolder(f);
		return res;
	}

	public Folder findOne(int folderId) {
		Assert.isTrue(folderId != 0);
		Folder res;
		res = folderRepository.findOne(folderId);
		Assert.notNull(res);

		return res;
	}

	public Collection<Folder> findAll() {
		Collection<Folder> f;

		Assert.notNull(this.folderRepository);
		f = folderRepository.findAll();
		Assert.notNull(f);

		return f;
	}

	public Folder save(Folder folder) {
		Assert.notNull(folder, "La folder no puede ser null");
		Folder f = null;
		f = folderRepository.save(folder);
		return f;
	}

	public void delete(Folder folder) {
		Actor a = actorService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(folder);
		Assert.isTrue(folder.getId() != 0);
		if (folder.getSystem()) {
			Assert.isTrue(!folder.getSystem());
		} else {
			if (a.getFolders().contains(folder)) {
				for (final Message m : folder.getMessages()) {
					messageService.delete(m);
				}
				a.getFolders().remove(folder);
				folderRepository.delete(folder);
			}
		}
	}

	//-------------------------------------------------------------------------------------------

	public Folder findInboxFrom(int actorId) {
		Assert.notNull(actorId);
		Assert.isTrue(actorId != 0);
		Folder res;
		res = folderRepository.findInboxFrom(actorId);
		Assert.notNull(res);

		return res;
	}

	public Folder findSpamboxFrom(int actorId) {
		Assert.notNull(actorId);
		Assert.isTrue(actorId != 0);
		Folder res;
		res = folderRepository.findSpamboxFrom(actorId);
		Assert.notNull(res);

		return res;
	}

	public Folder findOutboxFrom(int actorId) {
		Assert.notNull(actorId);
		Assert.isTrue(actorId != 0);
		Folder res;
		res = folderRepository.findOutboxFrom(actorId);
		Assert.notNull(res);

		return res;
	}

	public Folder findTrashboxFrom(int actorId) {
		Assert.notNull(actorId);
		Assert.isTrue(actorId != 0);
		Folder res;
		res = folderRepository.findTrashboxFrom(actorId);
		Assert.notNull(res);

		return res;
	}

	public Folder findNotificationboxFrom(int actorId) {
		Assert.notNull(actorId);
		Assert.isTrue(actorId != 0);
		Folder res;
		res = folderRepository.findNotificationboxFrom(actorId);
		Assert.notNull(res);

		return res;
	}

	public Folder findFolder(Actor actor, String folder) {
		Assert.isTrue(this.actorService.isAuthenticated());
		Assert.notNull(folder);
		Assert.notNull(actor);
		Folder result;

		result = folderRepository.findByActorAndNameFolder(actor, folder);
		Assert.notNull(result);
		Assert.notNull(actor.getFolders().contains(folder));

		return result;
	}

	public Boolean findFolderBoolean(Actor actor, String folder) {
		Assert.isTrue(this.actorService.isAuthenticated());
		Assert.notNull(folder);
		Assert.notNull(actor);
		Folder f;
		f = this.folderRepository.findByActorAndNameFolder(actor, folder);
		Boolean result = false;

		if (f == null) {
			result = true;
		}

		return result;
	}

	public Collection<Folder> foldersFather(int actorId, String nameFolder) {
		Collection<Folder> result = folderRepository.foldersFather(actorId, nameFolder);
		Assert.notNull(result);
		return result;
	}

	public Boolean findTabooWordInMessage(String phrase) {
		Boolean result = false;
		if (folderRepository.findTabooWordInMessage(phrase) >= 1) {
			result = true;
		}
		return result;
	}

}
