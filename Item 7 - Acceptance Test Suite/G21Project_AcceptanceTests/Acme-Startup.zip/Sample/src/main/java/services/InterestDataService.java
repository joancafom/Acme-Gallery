package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.InterestData;
import repositories.InterestDataRepository;


@Service
@Transactional
public class InterestDataService {

	@Autowired
	private InterestDataRepository	interestDataRepository;


	public InterestDataService() {
		super();
	}

	//METODOS CRUD ----------------------------------------------

	public Collection<InterestData> findAll() {
		Collection<InterestData> interestDatas;
		Assert.notNull(this.interestDataRepository);
		
		interestDatas = this.interestDataRepository.findAll();
		Assert.notNull(interestDatas);
		
		return interestDatas;
	}

	public InterestData findOne(int interestDataId) {
		InterestData result;
	
		result = interestDataRepository.findOne(interestDataId);
		Assert.notNull(result);
		
		return result;
	}

	public InterestData save(InterestData interestData) {
		Assert.notNull(interestData);
		
		InterestData result = interestDataRepository.save(interestData);

		return result;

	}
	
	public Collection<InterestData> interestDataPerPersonalData(int personalDataId) {
		Collection<InterestData> res = interestDataRepository.interestDataPerPersonalData(personalDataId);

		return res;
	}
	
	
}
