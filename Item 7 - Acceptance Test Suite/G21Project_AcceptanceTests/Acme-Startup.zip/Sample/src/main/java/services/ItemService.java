package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Company;
import domain.Item;
import domain.Merchant;
import repositories.ItemRepository;

@Service
@Transactional
public class ItemService {

	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;
	
	public Item create() {
		Item result;
		
		result = new Item();
		
		return result;
	}
	
	public Item findOne(int id) {
		Item result;
		
		result = this.itemRepository.findOne(id);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Item> findAll() {
		Collection<Item> result;
		
		result = this.itemRepository.findAll();
		Assert.notNull(result);
		
		return result;
	}
	
	public Item save(Item item) {
		Assert.notNull(item);
		Item result;
		
		result = this.itemRepository.save(item);
		Assert.notNull(result);
		
		return result;
	}
	
	public Item saveItem(Item item, Merchant merchant) {
		Assert.notNull(item);
		Assert.notNull(merchant);
		Item result;
		item.setDeleted(false);
		
		result = this.save(item);
		
		merchant.getItems().add(result);
		
		return result;
	}
	
	public Item saveItemCompany(Item item, Company company) {
		Assert.notNull(item);
		Assert.notNull(company);
		Item result;
		item.setDeleted(false);
		
		result = this.save(item);
		
		company.getItems().add(result);
		
		return result;
	}
	
	public void delete(Item item) {
		Assert.notNull(item);
		Assert.isTrue(this.itemRepository.exists(item.getId()));
		
		item.setDeleted(true);
		this.save(item);
	}
	
	public void deleteItem(Item item) {
		Assert.notNull(item);
		
		item.setDeleted(true);
		
		this.save(item);
	}
	
	public Collection<Item> findAllNotDeleted() {
		Collection<Item> result;
		Collection<Item> aux;
		
		result = this.itemRepository.findAllNotDeleted();
		Assert.notNull(result);
		
		aux = this.itemRepository.findAllItemsCompanyPro();
		Assert.notNull(aux);
		result.addAll(aux);
		
		return result;
	}
	
	public Collection<Item> findAllItemsBySell(int sellId) {
		Assert.notNull(sellId);
		Collection<Item> result;
		
		result = this.itemRepository.findAllItemsBySell(sellId);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Item> findAllItemsByMerchant() {
		Merchant merchant;
		
		merchant = this.merchantService.findByPrincipal();
		Assert.notNull(merchant.getItems(), "Este merchant no tiene items");
		
		return merchant.getItems();
	}
	
	public Collection<Item> findCompanyItems(int companyId) {
		Assert.notNull(companyId);
		Collection<Item> result;
		
		result = this.itemRepository.findAllItemsCompanyProId(companyId);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Item> findMerchantItems(int merchantId) {
		Assert.notNull(merchantId);
		Collection<Item> result;
		
		result = this.itemRepository.findAllNotDeletedId(merchantId);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Item> searchItems(String item) {
		Collection<Item> result;
		
		if(item == null || item.equals("")) {
			result = this.findAllNotDeleted();
		} else {
			result = this.itemRepository.searchItems(item);
		}
		return result;
	}
	
	public Collection<Item> searchItemsMerchant(String item) {
		Collection<Item> result;
		Merchant merchant;
		
		if (item == null || item.equals("")) {
			result = this.findAllItemsByMerchant();
		} else {
			merchant = this.merchantService.findByPrincipal();
			result = this.itemRepository.searchItemsByMerchant(item, merchant.getId());
		}
		return result;
	}
	
	public Collection<Item> searchItemsCompany(String item) {
		Collection<Item> result;
		Company company;
		
		if (item == null || item.equals("")) {
			company = this.companyService.findByPrincipal();
			result = company.getItems();
		} else {
			company = this.companyService.findByPrincipal();
			result = this.itemRepository.searchItemsByCompany(item, company.getId());
		}
		return result;
	}
	
	public Item itemByComment(int commentId) {
		Assert.notNull(commentId);
		Item result;
		
		result = this.itemRepository.itemByComment(commentId);
		
		return result;
	}
}
