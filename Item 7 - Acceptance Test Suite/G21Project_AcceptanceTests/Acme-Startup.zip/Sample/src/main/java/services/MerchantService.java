
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Folder;
import domain.Item;
import domain.Merchant;
import domain.Sell;
import repositories.MerchantRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class MerchantService {

	@Autowired
	private MerchantRepository merchantRepository;

	@Autowired
	private ActorService actorService;


	public Merchant create() {
		Merchant result;
		result = new Merchant();
		Collection<Folder> f = actorService.systemFolder();
		result.setFolders(f);
		Collection<Sell> shells = new HashSet<Sell>();
		result.setSells(shells);
		Collection<Item> items = new HashSet<Item>();
		result.setItems(items);
		return result;
	}

	public Merchant findOne(int merchantId) {
		Merchant result;

		result = merchantRepository.findOne(merchantId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Merchant> findAll() {
		Collection<Merchant> result;

		result = merchantRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Merchant save(Merchant merchant) {
		Assert.notNull(merchant);
		Merchant result = new Merchant();
		if (!merchant.getPhone().isEmpty()) {
			if (!merchant.getPhone().trim().substring(0, 1).equals("+")) {
				merchant.setPhone(actorService.patronPhone() + merchant.getPhone());
				result = merchantRepository.save(merchant);
			}
		} else {
			result = merchantRepository.save(merchant);
		}
		Assert.notNull(result);
		return result;
	}

	public void delete(Merchant merchant) {
		Assert.notNull(merchant);
		Assert.isTrue(merchant.getId() != 0);
		Assert.isTrue(merchantRepository.exists(merchant.getId()));

		merchantRepository.delete(merchant);
	}

	public Merchant findByPrincipal() {
		Merchant a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public Merchant findByUserAccount(UserAccount userAccount) {
		Assert.notNull(userAccount);
		Merchant a;
		a = merchantRepository.findByUserAccountId(userAccount.getId());
		return a;
	}
	
	public Merchant findByItem(int itemId) {
		Assert.notNull(itemId);
		Merchant result;
		
		result = this.merchantRepository.findByItem(itemId);
		
		return result;
	}
	
	public Merchant findOneWIthoutExceptions(int merchantId) {
		Assert.notNull(merchantId);
		Merchant merchant;
		
		merchant = this.merchantRepository.findOne(merchantId);
		
		return merchant;
	}

}
