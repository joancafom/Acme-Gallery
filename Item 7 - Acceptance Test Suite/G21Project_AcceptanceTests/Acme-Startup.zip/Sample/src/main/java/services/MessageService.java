
package services;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import domain.Admin;
import domain.Company;
import domain.Folder;
import domain.Merchant;
import domain.Message;
import domain.Sponsor;
import domain.User;
import repositories.MessageRepository;

@Service
@Transactional
public class MessageService {
	// Managed repository -----------------------------------------------------

	@Autowired
	private MessageRepository messageRepository;

	// Supporting services ----------------------------------------------------
	@Autowired
	private FolderService	folderService;
	@Autowired
	private ActorService	actorService;
	@Autowired
	private UserService		userService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private SponsorService	sponsorService;
	@Autowired
	private AdminService	adminService;


	// Constructors -----------------------------------------------------------

	public MessageService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------
	public Message create() {
		Message result;
		result = new Message();
		//Hora del sistema por defecto
		result.setDeliveryDate(new Date(System.currentTimeMillis() - 1000));
		return result;
	}

	public Message findOne(int messageId) {
		Assert.isTrue(messageId != 0);
		Message res;
		res = messageRepository.findOne(messageId);
		Assert.notNull(res);

		return res;
	}

	public Collection<Message> findAll() {
		Collection<Message> r;

		Assert.notNull(messageRepository);
		r = messageRepository.findAll();
		Assert.notNull(r);

		return r;
	}

	public Message save(Message message) {
		Assert.notNull(message);

		messageSaveTo(message);
		return messageSaveFrom(message);
	}

	private void messageSaveTo(Message message) {
		Assert.notNull(message);
		//Guardo mensaje en la Outbox del actorFrom
		Actor aTo = message.getActorTo();
		Folder fTo = new Folder();
		if (isSpam(message)) {
			fTo = folderService.findFolder(aTo, "Spambox");
			fTo.getMessages().add(message);
		} else {
			fTo = folderService.findFolder(aTo, "Inbox");
			fTo.getMessages().add(message);
		}

		message.setFolder(fTo);
		this.messageRepository.save(message);
	}

	private Message messageSaveFrom(Message message) {
		Assert.notNull(message);
		//Guardo mensaje en la Outbox del actorFrom
		Actor aFrom = message.getActorFrom();
		Folder fFo = folderService.findFolder(aFrom, "Outbox");
		fFo.getMessages().add(message);
		message.setFolder(fFo);
		Message m = this.messageRepository.save(message);
		return m;
	}

	public void delete(Message message) {
		Assert.isTrue(actorService.isAuthenticated());
		Assert.notNull(message);
		Assert.isTrue(actorService.findByPrincipal().equals(message.getActorTo()) || this.actorService.findByPrincipal().equals(message.getActorFrom()));

		Actor actor = actorService.findByPrincipal();

		if (actor.getClass() == User.class) {
			actor = userService.findOne(actor.getId());
		} else if (actor.getClass() == Admin.class) {
			actor = adminService.findOne(actor.getId());
		} else if (actor.getClass() == Company.class) {
			actor = companyService.findOne(actor.getId());
		} else if (actor.getClass() == Merchant.class) {
			actor = merchantService.findOne(actor.getId());
		} else if (actor.getClass() == Sponsor.class) {
			actor = sponsorService.findOne(actor.getId());
		}

		if (message.getFolder().getName().equals("Trashbox")) {
			this.messageRepository.delete(message);
		} else {
			message.setFolder(folderService.findFolder(actor, "Trashbox"));
			messageRepository.save(message);
		}
	}

	public void sendBroadcastMessage(Actor actor, String body, String priority, String subject) {
		adminService.findByPrincipal();
		Assert.notNull(actor, "El actor no puede ser null");
		Assert.notNull(body, "El body no puede ser null");
		Assert.notNull(priority, "El priority no puede ser null");
		Assert.notNull(subject, "El subject no puede ser null");
		Message mBroadcast = this.create();
		Folder fTo = new Folder();
		mBroadcast.setActorFrom(actor);
		mBroadcast.setBody(body);
		mBroadcast.setPriority(priority);
		mBroadcast.setSubject(subject);

		Collection<Actor> colA = new HashSet<Actor>();
		colA.addAll(actorService.findAll());
		colA.remove(actor);

		for (Actor a : colA) {
			mBroadcast.setActorTo(a);
			if (isSpam(mBroadcast)) {
				fTo = folderService.findFolder(a, "Spambox");
				mBroadcast.setFolder(fTo);
				fTo.getMessages().add(mBroadcast);
			} else {
				fTo = folderService.findFolder(a, "Notificationbox");
				fTo.getMessages().add(mBroadcast);
				mBroadcast.setFolder(fTo);
			}
			this.messageRepository.save(mBroadcast);
		}
		messageSaveFrom(mBroadcast);
	}

	public void sendRaffleMessage(User actor, String body, String priority, String subject) {
		adminService.findByPrincipal();
		Assert.notNull(actor, "El actor no puede ser null");
		Assert.notNull(body, "El body no puede ser null");
		Assert.notNull(priority, "El priority no puede ser null");
		Assert.notNull(subject, "El subject no puede ser null");
		Message mBroadcast = this.create();
		Folder fTo = new Folder();
		mBroadcast.setActorFrom(actor);
		mBroadcast.setBody(body);
		mBroadcast.setPriority(priority);
		mBroadcast.setSubject(subject);

		mBroadcast.setActorTo(actor);
		fTo = folderService.findFolder(actor, "Notificationbox");
		fTo.getMessages().add(mBroadcast);
		mBroadcast.setFolder(fTo);

		this.messageRepository.save(mBroadcast);
		messageSaveFrom(mBroadcast);
	}

	//Other business method-----------------------------------------------

	public boolean isSpam(Message message) {
		Boolean result = false;

		if (folderService.findTabooWordInMessage(message.getSubject().toLowerCase()) || folderService.findTabooWordInMessage(message.getBody().toLowerCase())) {
			result = true;

		}
		return result;
	}

	public Message messageActor(int idActor, int idMessage) {
		Message result = messageRepository.findMessage(idActor, idMessage);
		Assert.notNull(result);
		return result;
	}

	public Boolean messageActorYesNo(Actor actor, int messageId) {
		Boolean result = false;
		Collection<Message> mActor = messageRepository.allMessagesFromActor(actor.getId());
		if (mActor.contains(findOne(messageId))) {
			result = true;
		}
		return result;
	}

}
