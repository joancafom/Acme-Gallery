package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Comment;
import domain.Company;
import domain.News;
import domain.Startup;
import repositories.NewsRepository;

@Service
@Transactional
public class NewsService {
	
	@Autowired
	private NewsRepository newsRepository;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private CommentService commentService;
	
	
	//Constructor--------------------------------
	public NewsService() {
		super();
	}
	
	
	//Metodos CRUD------------------------------
	
	public News create() {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		News res = new News();
		Date momento = new Date(System.currentTimeMillis() - 1000);

		res.setCreationDate(momento);

		return res;
	}
	
	public Collection<News> findAll() {
		Collection<News> res;
		res = newsRepository.findAll();
		Assert.notNull(res);
		return res;
	}
	
	public News findOne(int newsId) {
		Assert.isTrue(newsId != 0);
		News res = newsRepository.findOne(newsId);
		Assert.notNull(res);
		return res;
	}

	public News save(News news) {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Assert.notNull(news);

		News result = newsRepository.save(news);
		Assert.notNull(result);
		
		//Si es nueva la meto en la company que la crea
		if(news.getId()==0){
			Collection<News> newss=new ArrayList<News>();
			newss = c.getNews();
			newss.add(result);
			c.setNews(newss);
			companyService.save(c);
		}
		
		return result;
	}	
	
	
	public News saveComment(News news) {
		Assert.notNull(news);
		News result = newsRepository.save(news);
		Assert.notNull(result);

		return result;
	}	
	
	
	public void delete(News news) {
		Assert.notNull(news);
		Assert.isTrue(newsRepository.exists(news.getId()));
		Company c=companyService.companyPerNews(news.getId());
		
		
		//Borrar los comentarios de este news
		Collection<Comment> comments=new ArrayList<Comment>();
		comments=news.getComments();
		for(Comment comment:comments){
			commentService.deleteNews(comment.getId());
		}
		
		//Borrar la news de la compa��a que la cre�
		Collection<News> newss= new ArrayList<News>();
		newss = c.getNews();
		newss.remove(news);
		c.setNews(newss);
		companyService.save(c);

		//Borrar la news del la Startup a la que pertenece
		Startup startup = startupService.startupPerNews(news.getId());
		Collection<News> newsss= new ArrayList<News>();
		newsss = startup.getNews();
		newsss.remove(news);
		startup.setNews(newsss);
		startupService.saveCategory(startup);
		

		
		newsRepository.delete(news.getId());

	}
	
	public void deleteStartup(News news) {
		Company c=companyService.companyPerNews(news.getId());
		Assert.notNull(c);
		Assert.notNull(news);
		Assert.isTrue(newsRepository.exists(news.getId()));
		
		//Borrar los comentarios de este news
		Collection<Comment> comments=new ArrayList<Comment>();
		comments=news.getComments();
		for(Comment comment:comments){
			commentService.deleteNews(comment.getId());
		}
		
		//Borrar la news de la compa��a que la cre�
		Collection<News> newss= new ArrayList<News>();
		newss = c.getNews();
		newss.remove(news);
		c.setNews(newss);
		companyService.save(c);
		
		newsRepository.delete(news.getId());

	}

	
	public News newsPerComment(int commentId) {
		News res = newsRepository.newsPerComment(commentId);
		return res;
	}
	
	
	public int newsPerCommentInt(int commentId) {
		int res = newsRepository.newsPerCommentInt(commentId);
		return res;
	}
	
	
	
}
