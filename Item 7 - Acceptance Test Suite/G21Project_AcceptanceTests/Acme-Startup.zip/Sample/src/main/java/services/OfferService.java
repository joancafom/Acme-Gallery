package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Company;
import domain.Message;
import domain.Offer;
import domain.PersonalData;
import domain.Startup;
import domain.User;
import repositories.OfferRepository;

@Service
@Transactional
public class OfferService {
	
	@Autowired
	private OfferRepository offerRepository;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MessageService messageService;
	
	
	
	//Constructor--------------------------------
	public OfferService() {
		super();
	}
	
	//Metodos CRUD------------------------------
	
	public Offer create() {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Offer res = new Offer();

		return res;
	}
	
	public Collection<Offer> findAll() {
		Collection<Offer> res;
		res = offerRepository.findAll();
		Assert.notNull(res);
		return res;
	}
	
	public Offer findOne(int offerId) {
		Assert.isTrue(offerId != 0);
		Offer res = offerRepository.findOne(offerId);
		Assert.notNull(res);
		return res;
	}
	
	public Offer save(Offer offer) {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Assert.notNull(offer);

		Offer result = offerRepository.save(offer);
		Assert.notNull(result);
		
		//Si es nueva la meto en la company que la crea
		if(offer.getId()==0){
			Collection<Offer> offers=new ArrayList<Offer>();
			offers = c.getOffers();
			offers.add(result);
			c.setOffers(offers);
			companyService.save(c);
		}
		
		return result;
	}	
	
	
	public Offer saveTag(Offer offer) {
		
		Assert.notNull(offer);

		Offer result = offerRepository.save(offer);
		return result;
		
	}
	
	public void delete(Offer offer) {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Assert.notNull(offer);
		Assert.isTrue(offerRepository.exists(offer.getId()));
		
		//Borrar la offer de la compa��a que la cre�
		Collection<Offer> offers= new ArrayList<Offer>();
		offers = c.getOffers();
		offers.remove(offer);
		c.setOffers(offers);
		companyService.save(c);

		//Borrar la offer del la Startup a la que pertenece
		Startup startup = startupService.startupPerOffer(offer.getId());
		Collection<Offer> offerss= new ArrayList<Offer>();
		offerss = startup.getOffers();
		offerss.remove(offer);
		startup.setOffers(offerss);
		startupService.saveCategory(startup);
		
		
		offerRepository.delete(offer.getId());

	}
	
	public void deleteStartup(Offer offer) {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Assert.notNull(offer);
		Assert.isTrue(offerRepository.exists(offer.getId()));
		
		//Borrar la offer de la compa��a que la cre�
		Collection<Offer> offers= new ArrayList<Offer>();
		offers = c.getOffers();
		offers.remove(offers);
		c.setOffers(offers);
		companyService.save(c);

		offerRepository.delete(offer.getId());

	}
	
	
	public void apply(Offer offer, int userId) {
		User u = userService.findByPrincipal();
		Offer res = offerRepository.findOne(offer.getId());
		
		Assert.isTrue(offerRepository.exists(offer.getId()));
		Assert.notNull(res);
		Assert.notNull(u);
		
		PersonalData personalData= u.getPersonalData();
		Collection<Offer> offers= new ArrayList<Offer>();
		offers=offerRepository.offersPerPersonalData(personalData.getId());
		
		Assert.isTrue(!(offers.contains(res)));
		
		Collection<PersonalData> personalDatas= new ArrayList<PersonalData>();
		personalDatas=res.getPersonalDatas();
		personalDatas.add(personalData);
		res.setPersonalDatas(personalDatas);
		
		//mandar mensaje de la company al user
		Company c = companyService.companyPerOffer(offer.getId());
		Message mes = messageService.create();

		mes.setActorFrom(c);
		mes.setActorTo(u);
		mes.setSubject("Has aplicado a la oferta de trabajo");
		mes.setBody("Desde la empresa "+c.getName()+" le agardecemos que haya aplicado a nuestra oferta de trabajo, en breves le daremos m�s informaci�n.");
		mes.setPriority("HIGH");
		messageService.save(mes);
		
		saveTag(res);
		
	}
	//Otros metodos-----------------------------------------------
	
	public Collection<Offer> offersPerPersonalData(int personalDataId) {
		Collection<Offer> res;
		res = offerRepository.offersPerPersonalData(personalDataId);
		return res;
	}
	
	
}
