package services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.PersonalData;
import domain.User;
import repositories.PersonalDataRepository;

@Service
@Transactional
public class PersonalDataService {

	@Autowired
	private PersonalDataRepository personalDataRepository;

	public PersonalDataService() {
		super();
	}

	// METODOS CRUD ----------------------------------------------

	public PersonalData create() {
		PersonalData personalData;
		personalData = new PersonalData();
		
		String identifier = this.checkIdentifier(this.cadenaAlfabetica() + "-" + this.cadenaNumerica());

		personalData.setIdentifier(identifier);

		return personalData;
	}

	public Collection<PersonalData> findAll() {
		Collection<PersonalData> personalDatas;
		Assert.notNull(this.personalDataRepository);

		personalDatas = this.personalDataRepository.findAll();
		Assert.notNull(personalDatas);

		return personalDatas;
	}

	public PersonalData findOne(int personalDataId) {
		PersonalData result;

		result = personalDataRepository.findOne(personalDataId);
		Assert.notNull(result);

		return result;
	}

	public PersonalData save(PersonalData personalData) {
		Assert.notNull(personalData);

		PersonalData result = personalDataRepository.save(personalData);

		return result;

	}

	public void delete(PersonalData personalData) {
		Assert.notNull(personalData);

		Collection<PersonalData> personalDatas = personalDataRepository.findAll();
		personalDatas.remove(personalData);
		personalDataRepository.delete(personalData);
	}
	
	private String cadenaNumerica() {
		String res = "";
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		String yearString = String.valueOf(year);
		String yy = yearString.substring(2);
		String mm;
		if (month > 9)
			mm = String.valueOf(month);
		else
			mm = "0" + String.valueOf(month);
		String dd;
		if (day > 9)
			dd = String.valueOf(day);
		else
			dd = "0" + String.valueOf(day);

		res = mm + dd + yy;

		return res;
	}

	private String cadenaAlfabetica() {
		String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String cadena = "";
		for (int i = 0; i < 3; i++) {
			int num = (int) (Math.random() * 26);
			cadena = cadena.concat(caracteres.substring(num, num + 1));
		}
		return cadena;

	}

	private String checkIdentifier(String identifier) {

		Collection<PersonalData> pd = new ArrayList<PersonalData>(this.personalDataRepository.findAll());
		for (PersonalData p : pd)
			if (p.getIdentifier().equals(identifier)) {
				identifier = this.cadenaNumerica() + "-" + this.cadenaAlfabetica();
				this.checkIdentifier(identifier);
			}
		return identifier;
	}

	// Bussines method ----------------------------------------------------------

	public PersonalData personalDataPerUser(int userId) {
		PersonalData res = personalDataRepository.personalDataPerUser(userId);

		return res;
	}
	
	public User userByPersonalDataId(int personalDataId) {
		
		User res = personalDataRepository.userByPersonalDataId(personalDataId);
		
		Assert.notNull(res);
		
		return res;
		
	}

}
