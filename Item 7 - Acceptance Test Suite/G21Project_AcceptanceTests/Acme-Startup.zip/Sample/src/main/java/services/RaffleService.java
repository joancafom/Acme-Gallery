
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Raffle;
import domain.User;
import repositories.RaffleRepository;

@Service
@Transactional
public class RaffleService {

	@Autowired
	private RaffleRepository raffleRepository;

	@Autowired
	private AdminService adminService;

	@Autowired
	private UserService userService;


	public RaffleService() {
		super();
	}

	public Raffle create() {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);

		Raffle raffle = new Raffle();
		Collection<User> users = new ArrayList<User>();
		Date datePublication = new Date(System.currentTimeMillis() - 1000);
		raffle.setDatePublication(datePublication);
		raffle.setClosed(false);
		raffle.setUsers(users);
		

		return raffle;
	}

	public Raffle findOne(int raffleId) {
		Raffle result;

		result = raffleRepository.findOne(raffleId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Raffle> findAll() {
		Collection<Raffle> result;

		result = raffleRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Raffle save(Raffle raffle) {
		Assert.notNull(raffle);
		Raffle result = raffleRepository.save(raffle);
		Assert.notNull(result);
		return result;
	}

	public void delete(Raffle raffle) {
		Assert.notNull(raffle);
		Assert.isTrue(raffle.getId() != 0);
		Assert.isTrue(raffleRepository.exists(raffle.getId()));

		raffleRepository.delete(raffle);
	}

	public void inscribe(Raffle raffle, int userId) {
		User u = userService.findOne(userId);
		Raffle res = raffleRepository.findOne(raffle.getId());
		Collection<User> users = new ArrayList<User>();
		users = res.getUsers();

		Assert.isTrue(raffleRepository.exists(raffle.getId()));
		Assert.notNull(res);

		Collection<Raffle> raffles = new ArrayList<Raffle>();
		raffles = this.rafflesPerUser(userId);
		Assert.isTrue(!(raffles.contains(res)));

		users.add(u);
		res.setUsers(users);
		userService.save(u);
	}

	// Bussines method ----------------------------------------------------------

	public Collection<Raffle> rafflesPerAdmin(int adminId) {
		Collection<Raffle> res = raffleRepository.rafflesPerAdmin(adminId);

		return res;
	}

	public Admin adminByRaffleId(int raffleId) {

		Admin res = raffleRepository.adminByRaffleId(raffleId);

		Assert.notNull(res);

		return res;

	}

	public Collection<Raffle> rafflesPerTitle(String title) {
		Collection<Raffle> res;
		res = raffleRepository.rafflesPerTitle(title);
		return res;
	}

	public Collection<Raffle> activeRafles() {
		Collection<Raffle> res;
		res = raffleRepository.activeRaffles();
		return res;
	}

	public Collection<Raffle> todayRaffles() {
		Collection<Raffle> res;
		res = raffleRepository.todayRaffles();
		return res;
	}

	public Collection<Raffle> rafflesPerUser(int userId) {
		Collection<Raffle> res = raffleRepository.rafflesPerUser(userId);
		return res;
	}

	public Boolean raffleActiveONo(int raffleId) {
		Boolean result = false;
		Integer num = raffleRepository.raffleActiveONo(raffleId);
		if (num == 1) {
			result = true;
		}
		return result;
	}

}
