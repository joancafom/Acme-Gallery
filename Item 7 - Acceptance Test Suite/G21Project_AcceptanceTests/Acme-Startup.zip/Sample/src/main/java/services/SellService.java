package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Company;
import domain.Item;
import domain.Merchant;
import domain.Sell;
import repositories.SellRepository;
import security.UserAccount;

@Service
@Transactional
public class SellService {

	@Autowired
	private SellRepository sellRepository;
	
	@Autowired
	private ActorService actorService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;
	
	public Sell create() {
		Sell result;
		
		result = new Sell();
		result.setItems(new HashSet<Item>());
		
		return result;
	}
	
	public Sell findOne(int id) {
		Sell result;
		
		result = this.sellRepository.findOne(id);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findAll() {
		Collection<Sell> result;
		
		result = this.sellRepository.findAll();
		Assert.notNull(result);
		
		return result;
	}
	
	public Sell save(Sell sell) {
		Assert.notNull(sell);
		Sell result;
		
		result = this.sellRepository.save(sell);
		Assert.notNull(result);
		
		return result;
	}
	
	public Sell saveSell(Sell sell) {
		Assert.notNull(sell);
		Sell result;
		
		sell.setTotal(this.calculateTotal(sell));
		
		result = this.save(sell);
		Assert.notNull(result);
		
		return result;
	}
	
	public double calculateTotal(Sell sell) {
		Assert.notNull(sell);
		double result;
		
		result = this.sellRepository.calculateTotal(sell.getId()); //Fallo
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellsByMerchant(int id) {
		Assert.notNull(id);
		Collection<Sell> result;
		
		result = this.sellRepository.findSellsByMerchant(id);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellsByMerchantAndCondition(int id, boolean condition) {
		Assert.notNull(id);
		Assert.notNull(condition);
		Collection<Sell> result;
		
		result = this.sellRepository.findSellsByMerchantAndCondition(id, condition);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellsByCompany(int id) {
		Assert.notNull(id);
		Collection<Sell> result;
		
		result = this.sellRepository.findSellsByCompany(id);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellsByCompanyAndCondition(int id, boolean condition) {
		Assert.notNull(id);
		Assert.notNull(condition);
		Collection<Sell> result;
		
		result = this.sellRepository.findSellsByCompanytAndCondition(id, condition);
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellsByItem(Item item) {
		Assert.notNull(item);
		Collection<Sell> result;
		
		result = this.sellRepository.findSellsByItem(item.getId());
		Assert.notNull(result);
		
		return result;
	}
	
	public Collection<Sell> findSellByPrincipal() {
		UserAccount userAccount;
		Merchant merchant;
		Company company;
		Collection<Sell> result;
		
		userAccount = this.actorService.findByPrincipal().getUserAccount();
		merchant = this.merchantService.findByUserAccount(userAccount);
		result = new ArrayList<>();
		company = this.companyService.findByUserAccount(userAccount);
		
		if (merchant == null) {
			if (company == null) {
				Assert.notNull(company, "La compa��a es nula");
			} else {
				result = company.getSells();
			}
		} else {
			result = merchant.getSells();
		}
		return result;
	}
}
