
package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Spam;
import repositories.SpamRepository;

@Service
@Transactional
public class SpamService {

	// Managed repository -----------------------------------------------------
	@Autowired
	private SpamRepository spamRepository;

	// Supporting services ----------------------------------------------------
	@Autowired
	private AdminService adminService;


	public SpamService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Spam create() {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);

		Spam res = new Spam();

		return res;
	}

	public Collection<Spam> findAll() {
		Collection<Spam> res;
		res = spamRepository.findAll();
		Assert.notNull(res);

		return res;
	}

	public Spam findOne(int spamId) {
		Assert.isTrue(spamId != 0);
		Spam res = spamRepository.findOne(spamId);
		Assert.notNull(res);
		return res;
	}

	public Spam save(Spam spam) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(spam);
		//No hay ninguna regla que comprobar
		Spam result = spamRepository.save(spam);
		Assert.notNull(result);
		return result;
	}

	public void delete(Spam spam) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(spam);
		Assert.isTrue(spamRepository.exists(spam.getId()));

		spamRepository.delete(spam.getId());
	}

	public Collection<Spam> findAllSpamByKeyword(String keyword) {

		Collection<Spam> res;
		res = spamRepository.findAllSpamByKeyword(keyword);
		Assert.notNull(res);

		return res;
	}

	public Collection<Spam> findKeyWord(String keyword) {

		Collection<Spam> res;
		res = spamRepository.findKeyWord(keyword);
		Assert.notNull(res);

		return res;
	}

	public Boolean findSpamInMessage(String phrase) {
		Boolean result = false;
		if (spamRepository.findSpamInMessage(phrase) >= 1) {
			result = true;
		}
		return result;
	}

}
