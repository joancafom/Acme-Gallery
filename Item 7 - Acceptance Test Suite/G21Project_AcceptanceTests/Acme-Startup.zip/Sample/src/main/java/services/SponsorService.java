
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Announcement;
import domain.Cooperate;
import domain.Folder;
import domain.Sponsor;
import repositories.SponsorRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class SponsorService {

	@Autowired
	private SponsorRepository sponsorRepository;

	@Autowired
	private ActorService actorService;


	public Sponsor create() {
		Sponsor result;
		result = new Sponsor();
		Collection<Folder> f = actorService.systemFolder();
		result.setFolders(f);
		result.setBuyStore(null);
		Collection<Cooperate> cooperates = new HashSet<Cooperate>();
		result.setCooperates(cooperates);
		Collection<Announcement> announcements = new HashSet<Announcement>();
		result.setAnnouncements(announcements);
		return result;
	}

	public Sponsor findOne(int sponsorId) {
		Sponsor result;

		result = sponsorRepository.findOne(sponsorId);
		Assert.notNull(result);

		return result;
	}

	public Collection<Sponsor> findAll() {
		Collection<Sponsor> result;

		result = sponsorRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Sponsor save(Sponsor sponsor) {
		Assert.notNull(sponsor);
		Sponsor result = new Sponsor();
		if (!sponsor.getPhone().isEmpty()) {
			if (!sponsor.getPhone().trim().substring(0, 1).equals("+")) {
				sponsor.setPhone(actorService.patronPhone() + sponsor.getPhone());
				result = sponsorRepository.save(sponsor);
			}
		} else {
			result = sponsorRepository.save(sponsor);
		}
		Assert.notNull(result);
		return result;
	}
	
	
	public Sponsor saveAnnouncement(Sponsor sponsor) {
		Assert.notNull(sponsor);
		Sponsor result = new Sponsor();
		
		result = sponsorRepository.save(sponsor);
		Assert.notNull(result);
		return result;
	}

	public void delete(Sponsor sponsor) {
		Assert.notNull(sponsor);
		Assert.isTrue(sponsor.getId() != 0);
		Assert.isTrue(sponsorRepository.exists(sponsor.getId()));

		sponsorRepository.delete(sponsor);
	}

	public Sponsor findByPrincipal() {
		Sponsor a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public Sponsor findByUserAccount(UserAccount userAccount) {
		Assert.notNull(userAccount);
		Sponsor a;
		a = sponsorRepository.findByUserAccountId(userAccount.getId());
		return a;
	}

	public Sponsor findSponsorByCooperate(Cooperate cooperate) {
		Assert.notNull(cooperate);
		Sponsor result;

		result = this.sponsorRepository.findSponsorByCooperate(cooperate.getId());
		Assert.notNull(result);

		return result;
	}

}
