package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Company;
import domain.Cooperate;
import domain.News;
import domain.Offer;
import domain.Startup;
import domain.User;
import repositories.StartupRepository;

@Service
@Transactional
public class StartupService {
	
	
	@Autowired
	private StartupRepository startupRepository;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private CooperateService cooperateService;
	
	@Autowired
	private CategoryService categoryService;
	
	//Constructor--------------------------------
	public StartupService() {
		super();
	}
	
	
	//Metodos CRUD------------------------------
	
	public Startup create() {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Startup res = new Startup();
		
		res.setCategory(categoryService.getCategoryPrincipal());
		
		return res;
	}
	
	public Collection<Startup> findAll() {
		Collection<Startup> res;
		res = startupRepository.findAll();
		Assert.notNull(res);
		return res;
	}
	
	public Startup findOne(int startupId) {
		Assert.isTrue(startupId != 0);
		Startup res = startupRepository.findOne(startupId);
		Assert.notNull(res);
		return res;
	}

	public Startup save(Startup startup) {
		Company c = companyService.findByPrincipal();
		Assert.notNull(c);
		Assert.notNull(startup);

		Startup result = startupRepository.save(startup);
		Assert.notNull(result);
		
		//Si es nueva la meto en la company que la crea
		if(startup.getId()==0){
			Collection<Startup> startups=new ArrayList<Startup>();
			startups = c.getStartups();
			startups.add(result);
			c.setStartups(startups);
			companyService.save(c);
		}
		
		return result;
	}	
	
	
	public Startup saveCategory(Startup startup) {
		Assert.notNull(startup);
		Startup result = startupRepository.save(startup);
		Assert.notNull(result);
		return result;
	}	
	
	
	public void delete(Startup startup) {
		Company c = companyService.findByPrincipal();
		Collection<Startup> startupCompany = new ArrayList<Startup>();
		startupCompany=c.getStartups();

		Assert.notNull(c);
		Assert.notNull(startup);
		Assert.isTrue(startupRepository.exists(startup.getId()));
		Assert.isTrue(startupCompany.contains(startup));
		
		//Borrar las News que se hayan creado
		Collection<News> newss= new ArrayList<News>();
		startup.setNews(new ArrayList<News>());

		newss = startup.getNews();
		startup.setNews(newss);
		for(News n : newss){
			newsService.deleteStartup(n);
		}
		
		//Quitar de la company la startup
		startupCompany.remove(startup);
		c.setStartups(startupCompany);
		companyService.save(c);
		
		//Borrar de los users que la sigan
		Collection<User> users =new ArrayList<User>();
		users = userService.usersPerStartup(startup.getId());
		for(User u : users){
			Collection<Startup> startupUser = new ArrayList<Startup>();
			startupUser=u.getStartups();
			startupUser.remove(startup);
			u.setStartups(startupUser);
			userService.save(u);
		}
		
		//Borrar las Offers que se hayan creado
		Collection<Offer> offers= new ArrayList<Offer>();
		startup.setOffers(new ArrayList<Offer>());
		offers = startup.getOffers();
		for(Offer o : offers){
			offerService.deleteStartup(o);
		}
		
		//Borrar los Cooperates que se hayan creado
		Collection<Cooperate> cooperates= new ArrayList<Cooperate>();
		startup.setCooperates(new ArrayList<Cooperate>());

		cooperates= startup.getCooperates();
		for(Cooperate co : cooperates){
			cooperateService.deleteStartup(co.getId());
		}

		
		startupRepository.delete(startup.getId());

	}

	
	public void subscribe(Startup startup, int userId) {
		User u = userService.findByPrincipal();
		Startup res = startupRepository.findOne(startup.getId());
		
		Assert.isTrue(startupRepository.exists(startup.getId()));
		Assert.notNull(res);
		Assert.notNull(u);
		
		Collection<Startup> startups = new ArrayList<Startup>();
		startups=u.getStartups();
		Assert.isTrue(!(startups.contains(res)));
		
		startups.add(res);
		u.setStartups(startups);
		userService.save(u);	
		
	}
	
	
	public void unSubscribe(Startup startup, int userId) {
		User u = userService.findByPrincipal();
		Startup res = startupRepository.findOne(startup.getId());
		
		Assert.isTrue(startupRepository.exists(startup.getId()));
		Assert.notNull(res);
		Assert.notNull(u);
		
		Collection<Startup> startups = new ArrayList<Startup>();
		startups=u.getStartups();
		Assert.isTrue(startups.contains(res));
		
		startups.remove(res);
		u.setStartups(startups);
		userService.save(u);	
		
	}
	
	
	//Otros metodos---------------------------------
	public Collection<Startup> startupsPerCategory(int categoryId) {
		Collection<Startup> res;
		res = startupRepository.startupsPerCategory(categoryId);
		return res;
	}

	public Collection<Startup> startupPerKeyWord(String keyWord) {
		Collection<Startup> res;
		res = startupRepository.startupPerKeyWord(keyWord);
		return res;
	}
	
	
	public Startup startupPerNews(int newsId) {
		Startup res = new Startup();
		res = startupRepository.startupsPerNews(newsId);
		return res;
	}
	
	public Startup startupPerCooperate(int cooperateId) {
		Startup res = new Startup();
		res = startupRepository.startupsPerCooperate(cooperateId);
		return res;
	}
	
	public Startup startupPerOffer(int offerId) {
		Startup res = new Startup();
		res = startupRepository.startupsPerOffer(offerId);
		return res;
	}
	
	
	
	
}
