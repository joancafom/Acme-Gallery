package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Company;
import domain.Offer;
import domain.Startup;
import domain.Tag;
import repositories.TagRepository;

@Service
@Transactional
public class TagService {

	// Managed repository -----------------------------------------------------
	@Autowired
	private TagRepository tagRepository;

	// Supporting services ----------------------------------------------------

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private CompanyService companyService;	
	
	
	public TagService() {
		super();
	}
	
	
	// Simple CRUD methods ----------------------------------------------------

	public Tag create() {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);

		Tag res = new Tag();
		//Collection<TagValue> ee = new ArrayList<TagValue>();
		//res.setTagValues(ee);
		
		Assert.notNull(res);

		return res;
	}

	public Collection<Tag> findAll() {
		Collection<Tag> res;
		res = tagRepository.findAll();
		Assert.notNull(res);

		return res;
	}

	public Tag findOne(int tagId) {
		Assert.isTrue(tagId != 0);
		Tag res = tagRepository.findOne(tagId);
		Assert.notNull(res);
		return res;
	}

	public Tag save(Tag tag) {
		//Admin a = adminService.findByPrincipal();
		//Assert.notNull(a);
		Assert.notNull(tag);
		Tag result = tagRepository.save(tag);
				
		
		Assert.notNull(result);

		
		return result;
	}
	
	
	public void delete(Tag tag) {
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Assert.notNull(tag);
		Assert.isTrue(tagRepository.exists(tag.getId()));
		
		
		Collection<Startup> startups = tagRepository.startupPerTag(tag.getId());
				
		for(Startup s : startups){
			Collection<Tag> taggs = s.getTags();
			taggs.remove(tag);
			s.setTags(taggs);
			startupService.saveCategory(s);
		}
		
		Collection<Offer> offers = tagRepository.offerPerTag(tag.getId());
		
		for(Offer s : offers){
			Collection<Tag> taggs = s.getTags();
			taggs.remove(tag);
			s.setTags(taggs);
			offerService.saveTag(s);
		}

		
		tagRepository.delete(tag.getId());
		
	}

	public void addTag(Tag tag, Startup startup) {
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups =new ArrayList<Startup>();
		Collection<Tag> tags=new ArrayList<Tag>();
		tags=startup.getTags();
		startups=c.getStartups();
		
		Assert.notNull(c);
		Assert.notNull(tag);
		Assert.notNull(startup);
		Assert.isTrue(startups.contains(startup));
		Assert.isTrue(!(tags.contains(tag)));
		
		tags.add(tag);
		startup.setTags(tags);
		startupService.saveCategory(startup);
	}
	
	
	public void removeTag(Tag tag, Startup startup) {
		Company c = companyService.findByPrincipal();
		Collection<Startup> startups =new ArrayList<Startup>();
		Collection<Tag> tags=new ArrayList<Tag>();
		tags=startup.getTags();
		startups=c.getStartups();
		
		Assert.notNull(c);
		Assert.notNull(tag);
		Assert.notNull(startup);
		Assert.isTrue(startups.contains(startup));
		Assert.isTrue(tags.contains(tag));
		
		tags.remove(tag);
		startup.setTags(tags);
		startupService.saveCategory(startup);
	}
	
	
	//Para offer
	public void addTago(Tag tag,Offer offer) {
		Company c = companyService.findByPrincipal();
		Collection<Offer> offers=new ArrayList<Offer>();
		Collection<Tag> tags=new ArrayList<Tag>();
		tags=offer.getTags();
		offers=c.getOffers();
		
		Assert.notNull(c);
		Assert.notNull(tag);
		Assert.notNull(offer);
		Assert.isTrue(offers.contains(offer));
		Assert.isTrue(!(tags.contains(tag)));
		
		tags.add(tag);
		offer.setTags(tags);
		offerService.save(offer);
	}
	
	
	public void removeTago(Tag tag,Offer offer) {
		Company c = companyService.findByPrincipal();
		Collection<Offer> offers=new ArrayList<Offer>();
		Collection<Tag> tags=new ArrayList<Tag>();
		tags=offer.getTags();
		offers=c.getOffers();
		
		Assert.notNull(c);
		Assert.notNull(tag);
		Assert.notNull(offer);
		Assert.isTrue(offers.contains(offer));
		Assert.isTrue((tags.contains(tag)));
		
		tags.remove(tag);
		offer.setTags(tags);
		offerService.save(offer);
	}
	
	
	

	//Other methods---------------------------------
	public Collection<Startup> startupPerTag(int tagId){
		
		Collection<Startup> startups;
		
		startups = tagRepository.startupPerTag(tagId);
		
		Assert.notNull(startups);
		
		return startups;
	}
	
	
	public Tag editTagValues(Tag tag){
		Assert.notNull(tag);
		Tag res;
		res = tagRepository.save(tag);
		return res;
		
	}
	
}
