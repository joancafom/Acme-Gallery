
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Comment;
import domain.Folder;
import domain.Startup;
import domain.User;
import repositories.UserRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ActorService actorService;


	public UserService() {
		super();
	}

	public User create() {
		User result;
		result = new User();
		Collection<Folder> f = actorService.systemFolder();
		result.setFolders(f);
		Collection<Comment> comments = new HashSet<Comment>();
		result.setComments(comments);
		Collection<Startup> startups = new HashSet<Startup>();
		result.setStartups(startups);
		return result;
	}

	public User findOne(int userId) {
		User result;

		result = userRepository.findOne(userId);
		Assert.notNull(result);

		return result;
	}

	public Collection<User> findAll() {
		Collection<User> result;
		result = userRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public User save(User user) {
		Assert.notNull(user);
		User result = new User();
		if (!user.getPhone().isEmpty()) {
			if (!user.getPhone().trim().substring(0, 1).equals("+")) {
				user.setPhone(actorService.patronPhone() + user.getPhone());
				result = userRepository.save(user);
			}
		} else {
			result = userRepository.save(user);
		}
		Assert.notNull(result);
		return result;
	}

	public void delete(User userId) {
		Assert.notNull(userId);
		Assert.isTrue(userId.getId() != 0);
		Assert.isTrue(userRepository.exists(userId.getId()));

		userRepository.delete(userId);
	}

	//-------------------------------------------------------------

	public User findByPrincipal() {
		User a;
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		a = findByUserAccount(userAccount);
		Assert.notNull(a);
		return a;
	}

	public User findByUserAccount(UserAccount userAccount) {
		Assert.notNull(userAccount);
		User a;
		a = userRepository.findByUserAccountId(userAccount.getId());
		return a;
	}

	
	public Collection<User> usersPerStartup(int startupId) {
		Collection<User> res = new ArrayList<User>();
		res = userRepository.usersPerStartup(startupId);
		return res;
	}
	
	public User findUserByComment(int commentId) {
		Assert.notNull(commentId);
		User result;
		
		result = this.userRepository.findUserByComment(commentId);
		Assert.notNull(result);
		
		return result;
	}
	
	
}
