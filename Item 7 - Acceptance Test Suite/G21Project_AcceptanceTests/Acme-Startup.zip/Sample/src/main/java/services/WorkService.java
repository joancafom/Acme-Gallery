package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import domain.PersonalData;
import domain.User;
import domain.Work;
import repositories.WorkRepository;


@Service
@Transactional
public class WorkService {
	
	@Autowired
	private WorkRepository	workRepository;


	public WorkService() {
		super();
	}

	//METODOS CRUD ----------------------------------------------
	
	public Work create() {
		Work work;
		work = new Work();
		
		return work;
	}

	public Collection<Work> findAll() {
		Collection<Work> works;
		Assert.notNull(this.workRepository);
		
		works = this.workRepository.findAll();
		Assert.notNull(works);
		
		return works;
	}

	public Work findOne(int workId) {
		Work result;
	
		result = workRepository.findOne(workId);
		Assert.notNull(result);
		
		return result;
	}

	public Work save(Work work) {
		Assert.notNull(work);
		
		Work result = workRepository.save(work);

		return result;

	}

	public void delete(Work work) {
		Assert.notNull(work);
		
		Collection<Work> works = workRepository.findAll();
		works.remove(work);
		workRepository.delete(work);
	}
	
	//Bussines method
	
	public Collection<Work> workPerPersonalData(int personalDataId) {
		Collection<Work> res = workRepository.workPerPersonalData(personalDataId);

		return res;
	}
	
	public User userByWorkId(int workId) {
		User res = workRepository.userByWorkId(workId);
		Assert.notNull(res);
		
		return res;
	}
	
	public PersonalData personalDataByWorkId(int workId) {
		PersonalData res = workRepository.personalDataByWorkId(workId);
		Assert.notNull(res);
		
		return res;
	}
}
