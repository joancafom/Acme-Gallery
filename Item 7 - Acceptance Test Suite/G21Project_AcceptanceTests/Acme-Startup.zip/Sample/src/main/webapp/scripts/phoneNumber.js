function validar(){
	return phone();
}


function phone() {
	var tel = document.getElementById("telefonoin").value;
	var m = document.getElementById("message").value;
	var validar = true;
	var longitudYNumeros = /^[+][0-9]{1,3}\s[(][0-9]{1,3}[)]\s[0-9]{4,9}$|^[+][0-9]{1,3}\s[0-9]{4,9}$|[0-9]{4,9}/;
	if (tel.length == 0) {
		
	} else if (longitudYNumeros.test(tel) == false) {
		if (!confirm(m) == true) {
			validar = false;
		}
	}
	return validar;
}
