
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Actor;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ActorServiceTest extends AbstractTest {

	@Autowired
	private ActorService actorService;


	@Test
	public void testFindAllActors() {
		Collection<Actor> actors;

		actors = this.actorService.findAll();
		Assert.notNull(actors);
	}

	@Test
	public void testFindAllActors2() {
		Collection<Actor> actors;

		actors = this.actorService.findAllActors();
		Assert.notNull(actors);
	}

	@Test
	public void testFindActorsBanned() {
		Collection<Actor> actors;

		actors = this.actorService.actorBanneds();
		Assert.notNull(actors);
	}

	@Test
	public void testFindAllActorPRO() {
		Collection<Actor> actors;

		actors = this.actorService.actorsPRO();
		Assert.notNull(actors);
	}

}
