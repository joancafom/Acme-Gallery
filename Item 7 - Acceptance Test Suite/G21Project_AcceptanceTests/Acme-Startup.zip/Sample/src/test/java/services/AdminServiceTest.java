
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class AdminServiceTest extends AbstractTest {

	@Autowired
	private AdminService adminService;


	@Test
	public void testFindOneAdmin() {
		Admin result;
		Admin aux;

		Collection<Admin> admins = new ArrayList<Admin>();
		admins = adminService.findAll();
		aux = (Admin) admins.toArray()[0];

		result = adminService.findOne(aux.getId());
		Assert.notNull(result);
	}

	@Test
	public void testFindAllAdmin() {
		Collection<Admin> admins;

		admins = this.adminService.findAll();
		Assert.notNull(admins);
	}

	@Test
	public void testCreateAdmin() {
		Admin admin;

		admin = this.adminService.create();
		Assert.notNull(admin);

		super.authenticate(null);
	}

	@Test
	public void testSaveAdmin() {

		Admin admin;

		Collection<Admin> admins = new ArrayList<Admin>();
		admins = adminService.findAll();
		admin = (Admin) admins.toArray()[0];

		admin.setName("Natalia");

		admin = adminService.save(admin);
	}

	@Test
	public void testDeleteAdmin() {

		Admin result;
		Admin aux;

		Collection<Admin> admins = new ArrayList<Admin>();
		admins = adminService.findAll();
		aux = (Admin) admins.toArray()[0];

		result = adminService.findOne(aux.getId());

		this.adminService.delete(result);
	}

	@Test
	public void offerstPerStartup() {
		Object[] result = adminService.offerstPerStartup();
		Assert.notNull(result);
	}

	@Test
	public void commentsPerUser() {
		Object[] result = adminService.commentsPerUser();
		Assert.notNull(result);
	}

	@Test
	public void offerstPerPersonalData() {
		Object[] result = adminService.offerstPerPersonalData();
		Assert.notNull(result);
	}

	@Test
	public void startupsPerCompany() {
		Object[] result = adminService.startupsPerCompany();
		Assert.notNull(result);
	}

	public void usersPerRaffle() {
		Object[] result = adminService.usersPerRaffle();
		Assert.notNull(result);
	}

	@Test
	public void commentsPerNews() {
		Object[] result = adminService.commentsPerNews();
		Assert.notNull(result);
	}

	@Test
	public void avgOffersPerStartupAverage() {
		Double result = adminService.avgOffersPerStartupAverage();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void avgNewsPerStartupAverage() {
		Double result = adminService.avgNewsPerStartupAverage();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void avgUsersPro() {
		Double result = adminService.avgUsersPro();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void stddevUsersPro() {
		Double result = adminService.stddevUsersPro();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void countUsersPro() {
		Integer result = adminService.countUsersPro();
		if (result == null) {
			result = 0;
		}
	}

	@Test
	public void avgCompaniesPro() {
		Double result = adminService.avgCompaniesPro();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void stddevCompaniesPro() {
		Double result = adminService.stddevCompaniesPro();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void countCompaniesPro() {
		Integer result = adminService.countCompaniesPro();
		if (result == null) {
			result = 0;
		}
	}

	@Test
	public void itemsPerCompanyEnVenta() {
		Double result = adminService.itemsPerCompanyEnVenta();
		if (result == null) {
			result = 0.0;
		}
	}

	@Test
	public void itemsBuyStorePerUser() {
		Double result = adminService.itemsBuyStorePerUser();
		if (result == null) {
			result = 0.0;
		}
	}

}
