package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Announcement;
import domain.Sponsor;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class AnnouncementServiceTest extends AbstractTest{
	
	@Autowired
	private AnnouncementService announcementService;
	
	@Autowired
	private SponsorService sponsorService;
	
	@Test
	public void testFindOneAdvertisement() {
		Announcement result;
		Announcement aux;

		Collection<Announcement> advertisements = new ArrayList<Announcement>();
		advertisements = announcementService.findAll();
		aux = (Announcement) advertisements.toArray()[0];

		result = announcementService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllAdvertisement() {
		Collection<Announcement> advertisements;

		advertisements = this.announcementService.findAll();
		Assert.notNull(advertisements);
	}
	
	
	@Test
	public void testCreateAdvertisement() {
		super.authenticate("sponsor1");
		Announcement advertisement;

		Sponsor agent = this.sponsorService.findByPrincipal();
		Assert.notNull(agent);

		advertisement = this.announcementService.create();
		Assert.notNull(advertisement);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSaveAdvertisement() {
		
		super.authenticate("sponsor1");
		Announcement advertisement;

		Collection<Announcement> advertisements = new ArrayList<Announcement>();
		advertisements = announcementService.findAll();
		advertisement = (Announcement) advertisements.toArray()[0];


		advertisement.setLink("prueba");

		advertisement = announcementService.save(advertisement);
	}
	
	@Test
	public void testDeleteAdvertisement() {
		super.authenticate("sponsor1");

		Announcement result;
		Announcement aux;

		Collection<Announcement> advertisements = new ArrayList<Announcement>();
		advertisements  = announcementService.findAll();
		aux = (Announcement) advertisements.toArray()[0];

		result = announcementService.findOne(aux.getId());

		this.announcementService.delete(result);
	}
	

	

}
