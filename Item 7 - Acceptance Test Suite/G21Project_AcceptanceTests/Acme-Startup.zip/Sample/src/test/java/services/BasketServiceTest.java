package services;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import domain.Basket;
import domain.CreditCard;
import domain.Item;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class BasketServiceTest extends AbstractTest {

	@Autowired
	private BasketService basketService;
	
	@Autowired
	private ItemService itemService;
	
	@Test
	public void testFindOne() {
		Basket basket = (Basket) this.basketService.findAll().toArray()[0];
		
		this.basketService.findOne(basket.getId());
	}
	
	@Test
	public void testSaveBasket() {
		Basket basket;
		Date date;
		Collection<Item> items = new ArrayList<Item>();
		
		date = new Date(System.currentTimeMillis());
		
		basket = this.basketService.create();
		basket.setDate(date);
		basket.setItems(items);
		basket.setTotal(0);
		
		this.basketService.save(basket);
	}
	
	@Test
	public void testDeleteBasket() {
		Basket basket = (Basket) this.basketService.findAll().toArray()[0];
		
		this.basketService.delete(basket);
	}
	
	@Test
	public void testFindByPrincipal() {
		super.authenticate("user1");
		
		this.basketService.findByPrincipal();
		
		super.unauthenticate();
	}
	
	@Test
	public void addProduct() {
		super.authenticate("sponsor1");
		Item item;
		
		item = (Item) this.itemService.findAll().toArray()[0];
		
		this.basketService.addProduct(item.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void deleteProduct() {
		super.authenticate("user1");
		Item item;
		Basket basket;
		
		basket = this.basketService.findByPrincipal();
		
		item = (Item) basket.getItems().toArray()[0];
		
		this.basketService.deleteProduct(item.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void testIsValidCreditCard() {
		CreditCard creditCard = new CreditCard();
		creditCard.setBrandName("Antonio");
		creditCard.setCvvCode("174");
		creditCard.setExpirationMonth("11");
		creditCard.setExpirationYear("20");
		creditCard.setHolderName("Unicaja");
		creditCard.setNumber("4556482012824355");
		
		this.basketService.isValidCreditCard(creditCard);
	}
	
	@Test
	public void testPayBasket() {
		super.authenticate("user1");
		
		CreditCard creditCard = new CreditCard();
		creditCard.setBrandName("Antonio");
		creditCard.setCvvCode("174");
		creditCard.setExpirationMonth("11");
		creditCard.setExpirationYear("20");
		creditCard.setHolderName("Unicaja");
		creditCard.setNumber("4556482012824355");
		
		this.basketService.pay(creditCard, "c/ castillo");
		
		super.unauthenticate();
	}
}
