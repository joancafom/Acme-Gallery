package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.BuyStore;
import domain.Item;
import domain.User;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class BuyStoreServiceTest extends AbstractTest{
	
	@Autowired
	private BuyStoreService buyStoreService;
	
	@Autowired
	private UserService userService;
	
	@Test
	public void testFindOneBuyStore() {
		BuyStore result;
		BuyStore aux;

		Collection<BuyStore> buyStores = new ArrayList<BuyStore>();
		buyStores = buyStoreService.findAll();
		aux = (BuyStore) buyStores.toArray()[0];

		result = buyStoreService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllBuyStore() {
		Collection<BuyStore> buyStores;

		buyStores = this.buyStoreService.findAll();
		Assert.notNull(buyStores);
	}
	
	
	@Test
	public void testCreateBuyStore() {
		super.authenticate("user1");
		BuyStore buyStore;

		User user = this.userService.findByPrincipal();
		Assert.notNull(user);

		buyStore = this.buyStoreService.create();
		Assert.notNull(buyStore);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSaveBuyStore() {
		
		super.authenticate("user1");
		BuyStore buyStore;

		Collection<BuyStore> buyStores = new ArrayList<BuyStore>();
		buyStores = buyStoreService.findAll();
		buyStore = (BuyStore) buyStores.toArray()[0];
		Collection<Item> items = new ArrayList<Item>();
	
		buyStore.setItems(items);

		buyStore=buyStoreService.save(buyStore);
	}
	
	@Test
	public void testDeleteBuyStore() {
		super.authenticate("user1");

		BuyStore result;
		BuyStore aux;

		Collection<BuyStore> buyStores = new ArrayList<BuyStore>();
		buyStores  = buyStoreService.findAll();
		aux = (BuyStore) buyStores.toArray()[0];

		result = buyStoreService.findOne(aux.getId());

		this.buyStoreService.delete(result);
	}

}
