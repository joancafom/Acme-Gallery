
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Category;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class CategoryServiceTest extends AbstractTest {

	//Service under test ---------------------
	@Autowired
	private CategoryService categoryService;

	//Supporting services --------------------
	
	//Tests ----------------------------------
	@Test
	public void testCreateCategory() {
		authenticate("admin");
		Category c = categoryService.create();
		Assert.notNull(c);
		authenticate(null);

	}

	@Test
	public void testFindOneCategory() {
		Category res;
		Category aux;
		
		Collection<Category> cs = categoryService.findAll();
		aux=(Category) cs.toArray()[0];
		
		res=categoryService.findOne(aux.getId());
		Assert.notNull(res);

	}

	@Test
	public void testFindAllCategory() {
		authenticate("admin");

		Collection<Category> cs;

		cs = categoryService.findAll();
		Assert.notNull(cs);

		authenticate(null);

	}

	@Test
	public void testSaveCategory() {
		authenticate("admin");

		Category res;
		Category aux;
		Collection<Category> cs = new ArrayList<Category>();
		cs = categoryService.findAll();
		aux=(Category) cs.toArray()[0];
		
		res=categoryService.findOne(aux.getId());
		res.setName("PRUEBA");
		categoryService.save(res);
		Assert.notNull(res);
	}

	@Test
	public void testDeleteCategory() {
		authenticate("admin");
		
		Category res;
		Category aux;
		
		Collection<Category> cs = categoryService.findAll();
		aux=(Category) cs.toArray()[1];
		
		res=categoryService.findOne(aux.getId());
		categoryService.delete(res);
		authenticate(null);

	}
	
	
	@Test
	public void testFindPrincipalCategory() {
		authenticate("admin");
		
		Category res;
		res=categoryService.getCategoryPrincipal();
		Assert.notNull(res);
		
		authenticate(null);

	}
	

	
	

}
