package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import domain.Comment;
import domain.Item;
import domain.News;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class CommentServiceTest extends AbstractTest {

	@Autowired
	private CommentService commentService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private ItemService itemService;
	
	@Test
	public void testFindOneComment() {
		Comment comment = (Comment) this.commentService.findAll().toArray()[0];
		
		this.commentService.findOne(comment.getId());
	}
	
	@Test
	public void testSaveComment() {
		super.authenticate("user1");
		
		Date creationDate = new Date(System.currentTimeMillis());
		Collection<Comment> comments = new ArrayList<Comment>();
		Comment comment = (Comment) this.commentService.findAll().toArray()[0];
		
		Comment comment2 = this.commentService.create();
		comment2.setBody("Cuerpo de prueba");
		comment2.setComments(comments);
		comment2.setCreationDate(creationDate);
		
		this.commentService.saveComment(comment2, comment.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void testSaveCommentNew() {
		super.authenticate("user1");
		
		Date creationDate = new Date(System.currentTimeMillis());
		Collection<Comment> comments = new ArrayList<Comment>();
		News news = (News) this.newsService.findAll().toArray()[0];
		
		Comment comment2 = this.commentService.create();
		comment2.setBody("Cuerpo de prueba");
		comment2.setComments(comments);
		comment2.setCreationDate(creationDate);
		
		this.commentService.saveCommentNew(comment2, news.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void testSaveCommentItem() {
		super.authenticate("user1");
		
		Date creationDate = new Date(System.currentTimeMillis());
		Collection<Comment> comments = new ArrayList<Comment>();
		Item item = (Item) this.itemService.findAll().toArray()[0];
		
		Comment comment2 = this.commentService.create();
		comment2.setBody("Cuerpo de prueba");
		comment2.setComments(comments);
		comment2.setCreationDate(creationDate);
		
		this.commentService.saveCommentItem(comment2, item.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindPrincipal() {
		Comment comment = (Comment) this.commentService.findAll().toArray()[0];
		
		this.commentService.findPrincipal(comment.getId());
	}
	
	@Test
	public void testDeleteComplete() {
		super.authenticate("user1");
		
		Comment comment = (Comment) this.commentService.findAll().toArray()[0];
		
		this.commentService.deleteComplete(comment.getId());
		
		super.unauthenticate();
	}
}
