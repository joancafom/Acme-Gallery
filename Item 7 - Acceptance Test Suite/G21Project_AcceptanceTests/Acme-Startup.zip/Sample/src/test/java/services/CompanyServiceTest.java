
package services;

import java.util.Collection;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Company;
import domain.Item;
import domain.News;
import domain.Offer;
import domain.Sell;
import domain.Startup;
import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class CompanyServiceTest extends AbstractTest {

	@Autowired
	private CompanyService companyService;


	private Company companyExample() {
		Company u = companyService.create();
		u.setName("Name");
		u.setEmail("email@email.com");
		u.setPhone("123123123");
		u.setAddress("Address");
		u.setPostalAddress("43213");
		u.setCreditCard(null);
		u.setPro(false);

		Collection<Sell> shells = new HashSet<Sell>();
		u.setSells(shells);
		Collection<Item> items = new HashSet<Item>();
		u.setItems(items);
		Collection<Offer> offers = new HashSet<Offer>();
		u.setOffers(offers);
		Collection<Startup> startups = new HashSet<Startup>();
		u.setStartups(startups);
		Collection<News> news = new HashSet<News>();
		u.setNews(news);

		Authority auth = new Authority();
		auth.setAuthority(Authority.COMPANY);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername("username");
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword("password", null));
		userAccount.getAuthorities().add(auth);
		userAccount.setBanned(true);
		u.setUserAccount(userAccount);
		Company result = companyService.save(u);

		return result;
	}

	@Test
	public void testFindOneCompany() {
		Company result = companyService.findOne(companyExample().getId());
		Assert.notNull(result);
		this.companyService.delete(result);
	}

	@Test
	public void testFindAllCompanies() {
		Collection<Company> companies;

		companies = this.companyService.findAll();
		Assert.notNull(companies);
	}

	@Test
	public void testCreateCompany() {

		Company user = this.companyService.create();
		Assert.notNull(user);

	}

	@Test
	public void testSaveCompany() {

		Company company = companyExample();

		company = companyService.save(company);

	}

	@Test
	public void testDeleteCompany() {

		Company result = companyExample();

		this.companyService.delete(result);
	}

}
