package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Announcement;
import domain.Configuration;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ConfigurationServiceTest extends AbstractTest{
	
	//Service under test ---------------------
		@Autowired
		private ConfigurationService configurationService;
				
		//Supporting services --------------------
		@Autowired
		private AdminService adminService;
		//Tests ----------------------------------

		@Test
		public void testCreateConfiguration() {
			authenticate("admin");
			Configuration c = configurationService.create();
			Assert.notNull(c);
			authenticate(null);
			
		}
		
		@Test
		public void testFindOneConfiguration() {
			Configuration c;
			
			Collection<Configuration> advertisements = new ArrayList<Configuration>();
			advertisements = configurationService.findAll();
			c = (Configuration) advertisements.toArray()[0];
			
			c = configurationService.findOne(c.getId());
			Assert.notNull(c);
			
		}
		
		@Test
		public void testFindAllConfiguration() {
			authenticate("admin");
			
			Collection<Configuration> cs;
			
			cs = configurationService.findAll();
			Assert.notNull(cs);
			
			
			authenticate(null);

		}
		
		
		@Test
		public void testSaveConfiguration() {
			authenticate("admin");
			Admin a = adminService.findByPrincipal();
			Assert.notNull(a);	
			
			Configuration c;
			
			Collection<Configuration> advertisements = new ArrayList<Configuration>();
			advertisements = configurationService.findAll();
			c = (Configuration) advertisements.toArray()[0];
			c.setCompany("Sevilla S.L.");
			c.setBanner("Sev");
			c.setCountryCode("77");
			c.setBienvenida("Holaaaa");
			c.setWelcome("hola");
			Assert.notNull(c);	
			configurationService.save(c);
				
			authenticate(null);
		}
		
		
		@Test
		public void testDeleteConfiguration() {
			authenticate("admin");
			//Collection<Configuration> cs = configurationService.findAll();
			//Assert.notNull(cs);
			
			Configuration c;
			
			Collection<Configuration> advertisements = new ArrayList<Configuration>();
			advertisements = configurationService.findAll();
			c = (Configuration) advertisements.toArray()[0];
			configurationService.delete(c);
			//cs = configurationService.findAll();
			authenticate(null);
			
		}
		

	

}
