package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import domain.Cooperate;
import domain.CreditCard;
import domain.Startup;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class CooperateServiceTest extends AbstractTest {

	@Autowired
	private CooperateService cooperateService;
	
	@Autowired
	private StartupService startupService;
	
	@Test
	public void testFindOneCooperate() {
		Cooperate cooperate = (Cooperate) this.cooperateService.findAll().toArray()[0];
		
		this.cooperateService.findOne(cooperate.getId());
	}
	
	@Test
	public void testSaveCooperate() {
		super.authenticate("sponsor1");
		
		Startup startup = (Startup) this.startupService.findAll().toArray()[0];
		
		CreditCard creditCard = new CreditCard();
		creditCard.setBrandName("Antonio");
		creditCard.setCvvCode("174");
		creditCard.setExpirationMonth("11");
		creditCard.setExpirationYear("20");
		creditCard.setHolderName("Unicaja");
		creditCard.setNumber("4556482012824355");
		
		Cooperate cooperate = this.cooperateService.create();
		cooperate.setBanner("https://dlcdnimgs.asus.com/20160129_cosmo/cosmo/images/asus_logo.jpg");
		cooperate.setCompany("Asus");
		cooperate.setCreditCard(creditCard);
		cooperate.setDescription("Good company");
		cooperate.setLink("https://www.asus.com/es/");
		
		this.cooperateService.save(cooperate, startup);
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindCooperateByPrincipal() {
		super.authenticate("sponsor1");
		
		this.cooperateService.findCooperatesByPrincipal();
		
		super.unauthenticate();
	}
	
	@Test
	public void testDeleteCooperate() {
		super.authenticate("sponsor1");
		
		Startup startup = (Startup) this.startupService.findAll().toArray()[0];
		
		Cooperate cooperate = (Cooperate) startup.getCooperates().toArray()[0];
		
		this.cooperateService.deleteCooperate(cooperate.getId(), startup);
		
		super.unauthenticate();
	}
}
