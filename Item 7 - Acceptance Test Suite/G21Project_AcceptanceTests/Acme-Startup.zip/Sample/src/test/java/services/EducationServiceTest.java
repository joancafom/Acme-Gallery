package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Education;
import domain.PersonalData;
import domain.User;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class EducationServiceTest extends AbstractTest{
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private PersonalDataService personalDataService;
	
	@Test
	public void testFindOneEducation() {
		Education result;
		Education aux;

		Collection<Education> educations = new ArrayList<Education>();
		educations = educationService.findAll();
		aux = (Education) educations.toArray()[0];

		result = educationService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllEducation() {
		Collection<Education> educations;

		educations = this.educationService.findAll();
		Assert.notNull(educations);
	}
	
	
	@Test
	public void testCreateEducation() {
		super.authenticate("user1");
		Education education;

		User user = this.userService.findByPrincipal();
		Assert.notNull(user);

		education = this.educationService.create();
		Assert.notNull(education);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSaveEducation() {
		
		super.authenticate("user1");
		Education education;

		Collection<Education> educations = new ArrayList<Education>();
		educations = educationService.findAll();
		education = (Education) educations.toArray()[0];


		education.setTitle("PRUEBA");

		education=educationService.save(education);
	}
	
	@Test
	public void testDeleteEducation() {
		super.authenticate("user1");

		Education result;
		Education aux;

		Collection<Education> educations = new ArrayList<Education>();
		educations  = educationService.findAll();
		aux = (Education) educations.toArray()[0];

		result = educationService.findOne(aux.getId());

		this.educationService.delete(result);
	}
	
	@Test
	public void testEducationPerPersonalData() {
		Collection<Education> educations;
		PersonalData personalData;
		
		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		personalData = (PersonalData) personalDatas.toArray()[0];
		
		educations = this.educationService.educationPerPersonalData(personalData.getId());
		Assert.notNull(educations);
	}
	
	
	@Test
	public void testUserByEducationId() {
		Education education;
		User user;
		
		Collection<Education> educations = new ArrayList<Education>();
		educations = educationService.findAll();
		education = (Education) educations.toArray()[0];
		
		user = this.educationService.userByEducationId(education.getId());
		Assert.notNull(user);
	}
	
	
	@Test
	public void testPersonalDataByEducationId() {
		PersonalData personalData;
		Education education;
		
		Collection<Education> educations = new ArrayList<Education>();
		educations = educationService.findAll();
		education = (Education) educations.toArray()[0];
		
		personalData = this.educationService.personalDataByEducationId(education.getId());
		Assert.notNull(personalData);
	}
	
	

}
