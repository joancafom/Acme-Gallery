
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Folder;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class FolderServiceTest extends AbstractTest {

	@Autowired
	private FolderService folderService;

	@Autowired
	private AdminService adminService;


	//Test-----------------------------------------------------

	@Test
	public void testCreateDelete() {
		authenticate("admin");
		Folder f = folderService.create();
		Assert.notNull(f);
		f.setName("New Admin1 Folder Delete");
		f.setSystem(false);
		Folder saved = folderService.save(f);
		Assert.notNull(saved);
	}

	@Test
	public void testCreateFolder() {
		authenticate("admin");

		Folder f = folderService.create();
		Assert.notNull(f);

		f.setName("New Admin1 Folder");
		f.setSystem(false);

		Folder saved = folderService.save(f);

		Folder fN = saved;

		fN.setName("New Admin1 Folder Saved");

		Folder saved2 = folderService.save(fN);
		Assert.notNull(saved2);

		authenticate(null);
	}

	@Test
	public void testFindOneFolder() {
		authenticate("admin");
		Admin actor = adminService.findByPrincipal();
		Folder ff = (Folder) actor.getFolders().toArray()[0];
		Folder f = folderService.findOne(ff.getId());
		Assert.notNull(f);
		authenticate(null);
	}

	@Test
	public void testFindAllFolder() {
		Collection<Folder> cF = folderService.findAll();
		Assert.notNull(cF);

	}
}
