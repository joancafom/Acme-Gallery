
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.InterestData;
import domain.PersonalData;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
public class InterestDataServiceTest extends AbstractTest {

	@Autowired
	private InterestDataService interestDataService;
	
	@Autowired
	private PersonalDataService personalDataService;

	@Test
	public void testFindAllInterestDatas() {
		Collection<InterestData> interestDatas;

		interestDatas = this.interestDataService.findAll();
		Assert.notNull(interestDatas);
	}

	@Test
	public void testFindAllInterestData() {
		Collection<InterestData> interestDatas;

		interestDatas = this.interestDataService.findAll();
		Assert.notNull(interestDatas);
	}

	@Test
	public void testSaveInterestData() {
		super.authenticate("user1");
		InterestData interestData;

		Collection<InterestData> interestDatas = new ArrayList<InterestData>();
		interestDatas = interestDataService.findAll();
		interestData = (InterestData) interestDatas.toArray()[0];

		interestData.setComments("PRUEBA");

		interestData = interestDataService.save(interestData);
	}
	
	@Test
	public void testInterestDataPerPersonalData() {
		Collection<InterestData> interestDatas;
		PersonalData personalData;
		
		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		personalData = (PersonalData) personalDatas.toArray()[0];
		
		interestDatas = this.interestDataService.interestDataPerPersonalData(personalData.getId());
		Assert.notNull(interestDatas);
	}
	
	

}
