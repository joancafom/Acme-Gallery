package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Comment;
import domain.Company;
import domain.Item;
import domain.Merchant;
import domain.Sell;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class ItemServiceTest extends AbstractTest {

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private SellService sellService;
	
	@Autowired
	private CommentService commentService;
	
	@Test
	public void testFindOneItem() {
		Item item;
		
		item = (Item) this.itemService.findAll().toArray()[0];
		
		this.itemService.findOne(item.getId());
	}
	
	@Test
	public void testCreateItem() {
		this.itemService.create();
	}
	
	@Test
	public void testSaveItem() {
		super.authenticate("merchant1");
		Merchant merchant;
		Item item;
		Collection<Comment> comments = new ArrayList<Comment>();
		
		item = this.itemService.create();
		item.setComments(comments);
		item.setDeleted(false);
		item.setDescription("Example description");
		item.setDiscount(1.00);
		item.setPrice(100.00);
		item.setTitle("Example title");
		
		merchant = this.merchantService.findByPrincipal();
		
		this.itemService.saveItem(item, merchant);
		
		super.unauthenticate();
	}
	
	@Test
	public void testSaveItemCompany() {
		super.authenticate("company1");
		Company company;
		Item item;
		Collection<Comment> comments = new ArrayList<Comment>();
		
		item = this.itemService.create();
		item.setComments(comments);
		item.setDeleted(false);
		item.setDescription("Example description");
		item.setDiscount(1.00);
		item.setPrice(100.00);
		item.setTitle("Example title");
		
		company = this.companyService.findByPrincipal();
		
		this.itemService.saveItemCompany(item, company);
		
		super.unauthenticate();
	}
	
	@Test
	public void testDeleteItem() {
		super.authenticate("company1");
		Company company;
		Item item;
		
		company = this.companyService.findByPrincipal();
		
		item = (Item) company.getItems().toArray()[0];
		
		this.itemService.deleteItem(item);
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindAllNotDeleted() {
		this.itemService.findAllNotDeleted();
	}
	
	@Test
	public void testFindAllItemsBySell() {
		Sell sell = (Sell) this.sellService.findAll().toArray()[0];
		
		this.itemService.findAllItemsBySell(sell.getId());
	}
	
	@Test
	public void testFindAllItemsByMerchant() {
		super.authenticate("merchant1");
		
		this.itemService.findAllItemsByMerchant();
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindCompanyItems() {
		super.authenticate("company1");
		Company company;
		
		company = this.companyService.findByPrincipal();
		
		this.itemService.findCompanyItems(company.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void searchItems() {
		Collection<Item> result;
		
		result = this.itemService.searchItems("a");
		Assert.notNull(result);
	}
	
	//No hay comentarios en un item
	@Test(expected = IllegalArgumentException.class)
	public void testItemByComment() {
		Comment comment = (Comment) this.commentService.findAll().toArray()[0];
		Item result;
		
		result = this.itemService.itemByComment(comment.getId());
		Assert.notNull(result);
	}
}
