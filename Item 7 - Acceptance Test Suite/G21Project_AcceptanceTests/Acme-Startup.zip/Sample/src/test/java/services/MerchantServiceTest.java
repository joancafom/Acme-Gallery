
package services;

import java.util.Collection;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Item;
import domain.Merchant;
import domain.Sell;
import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MerchantServiceTest extends AbstractTest {

	@Autowired
	private MerchantService merchantService;


	private Merchant merchantExample() {
		Merchant u = merchantService.create();
		u.setName("Name");
		u.setEmail("email@email.com");
		u.setPhone("123123123");
		u.setAddress("Address");
		u.setPostalAddress("43213");

		Collection<Sell> shells = new HashSet<Sell>();
		u.setSells(shells);
		Collection<Item> items = new HashSet<Item>();
		u.setItems(items);

		Authority auth = new Authority();
		auth.setAuthority(Authority.MERCHANT);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername("username");
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword("password", null));
		userAccount.getAuthorities().add(auth);
		userAccount.setBanned(true);
		u.setUserAccount(userAccount);
		Merchant result = merchantService.save(u);

		return result;
	}

	@Test
	public void testFindOneUser() {
		Merchant result = merchantService.findOne(merchantExample().getId());
		Assert.notNull(result);
		this.merchantService.delete(result);
	}

	@Test
	public void testFindAllMerchant() {
		Collection<Merchant> merchants;

		merchants = this.merchantService.findAll();
		Assert.notNull(merchants);
	}

	@Test
	public void testCreateMerchant() {

		Merchant merchant = this.merchantService.create();
		Assert.notNull(merchant);

	}

	@Test
	public void testSaveMerchant() {

		Merchant merchant = merchantExample();
		merchant = merchantService.save(merchant);
	}

	@Test
	public void testDeleteMerchant() {

		Merchant result = merchantExample();

		this.merchantService.delete(result);
	}

}
