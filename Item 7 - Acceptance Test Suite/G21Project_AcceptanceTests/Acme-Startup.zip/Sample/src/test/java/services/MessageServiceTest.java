
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import domain.Actor;
import domain.Admin;
import domain.Message;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class MessageServiceTest extends AbstractTest {

	@Autowired
	private MessageService	messageService;
	@Autowired
	private AdminService	adminService;
	@Autowired
	private ActorService	actorService;
	@Autowired
	private UserService		userService;


	@Test
	public void testCreateMessage() {
		Collection<Actor> actor = actorService.findAll();
		authenticate("user1");
		Message m = messageService.create();
		m.setActorFrom(userService.findByPrincipal());
		m.setActorTo((Actor) actor.toArray()[0]);
		m.setBody("Hola tio que tal. Cuanto tiempo sin vernos.");
		m.setPriority("LOW");
		m.setSubject("Noche Loca");

		messageService.save(m);
		unauthenticate();
	}

	@Test
	public void testDeleteMessage() {
		Collection<Actor> actor = actorService.findAll();
		authenticate("user1");
		Message m = messageService.create();
		m.setActorFrom(userService.findByPrincipal());
		m.setActorTo((Actor) actor.toArray()[0]);
		m.setBody("Hola tio que tal. Cuanto tiempo sin vernos.");
		m.setPriority("LOW");
		m.setSubject("Noche Loca");

		Message mm = messageService.save(m);

		messageService.delete(mm);
		unauthenticate();
	}

	@Test
	public void testMessageFindOne() {
		Collection<Actor> actor = actorService.findAll();
		authenticate("user1");
		Message m = messageService.create();
		m.setActorFrom(userService.findByPrincipal());
		m.setActorTo((Actor) actor.toArray()[0]);
		m.setBody("Hola tio que tal. Cuanto tiempo sin vernos.");
		m.setPriority("LOW");
		m.setSubject("Noche Loca");

		Message mm = messageService.save(m);

		messageService.findOne(mm.getId());
		unauthenticate();
	}

	@Test
	public void testMessageFindAll() {
		messageService.findAll();
	}

	@Test
	public void testMessageBroadcast() {
		authenticate("admin");
		Admin actor = adminService.findByPrincipal();
		String body = "Hola a todos, esto es una prueba de Notificaci�n";
		String priority = "HIGH";
		String subject = "Prioridad de Notificaci�n sex";
		messageService.sendBroadcastMessage(actor, body, priority, subject);
		unauthenticate();
	}
}
