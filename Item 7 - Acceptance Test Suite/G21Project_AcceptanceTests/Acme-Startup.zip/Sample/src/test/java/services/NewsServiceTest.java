package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Comment;
import domain.News;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class NewsServiceTest extends AbstractTest{
	
	//Service under test ---------------------
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private CommentService commentService;
	
	//Tests ----------------------------------
	@Test
	public void testCreateNews() {
		authenticate("company1");
		News c = newsService.create();
		Assert.notNull(c);
		authenticate(null);

	}

	@Test
	public void testFindOneNews() {
		News res;
		News aux;
		
		Collection<News> cs = newsService.findAll();
		aux=(News) cs.toArray()[0];
		
		res=newsService.findOne(aux.getId());
		Assert.notNull(res);

	}

	@Test
	public void testFindAllNews() {

		Collection<News> cs;

		cs = newsService.findAll();
		Assert.notNull(cs);
	}
	
	@Test
	public void testSaveNews() {
		authenticate("company1");

		News res;
		News aux;
		Collection<News> cs = new ArrayList<News>();
		cs = newsService.findAll();
		aux=(News) cs.toArray()[0];
		
		res=newsService.findOne(aux.getId());
		res.setBody("PRUEBA");
		newsService.save(res);
		Assert.notNull(res);
	}
	
	
	@Test
	public void testDeleteNews() {
		authenticate("company1");
		
		News res;
		News aux;
		
		Collection<News> cs = newsService.findAll();
		aux=(News) cs.toArray()[0];
		
		res=newsService.findOne(aux.getId());
		newsService.delete(res);
		authenticate(null);

	}
	
	
	@Test
	public void testNewsPerComment() {
		News res;
		Comment aux;
		
		Collection<Comment> cs = commentService.findAll();
		aux=(Comment) cs.toArray()[0];
		
		res=newsService.newsPerComment(aux.getId());
		Assert.notNull(res);

	}
	
}
