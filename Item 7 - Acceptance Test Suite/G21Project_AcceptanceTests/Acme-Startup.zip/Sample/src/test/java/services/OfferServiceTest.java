package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Offer;
import domain.PersonalData;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class OfferServiceTest extends AbstractTest{
	
	//Service under test ---------------------
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private PersonalDataService personalDataService;
	
	//Tests ----------------------------------
	@Test
	public void testCreateOffer() {
		authenticate("company1");
		Offer c = offerService.create();
		Assert.notNull(c);
		authenticate(null);

	}

	@Test
	public void testFindOneOffer() {
		Offer res;
		Offer aux;
		
		Collection<Offer> cs = offerService.findAll();
		aux=(Offer) cs.toArray()[0];
		
		res=offerService.findOne(aux.getId());
		Assert.notNull(res);

	}

	@Test
	public void testFindAllOffer() {

		Collection<Offer> cs;

		cs = offerService.findAll();
		Assert.notNull(cs);
	}
	
	@Test
	public void testSaveOffer() {
		authenticate("company1");

		Offer res;
		Offer aux;
		Collection<Offer> cs = new ArrayList<Offer>();
		cs = offerService.findAll();
		aux=(Offer) cs.toArray()[0];
		
		res=offerService.findOne(aux.getId());
		res.setDescription("PRUEBA");
		offerService.save(res);
		Assert.notNull(res);
	}
	
	@Test
	public void testDeleteOffer() {
		authenticate("company1");
		
		Offer res;
		Offer aux;
		
		Collection<Offer> cs = offerService.findAll();
		aux=(Offer) cs.toArray()[0];
		
		res=offerService.findOne(aux.getId());
		offerService.delete(res);
		authenticate(null);

	}
	
	@Test
	public void testOffersPerPersonalData() {
		Collection<Offer> res;
		PersonalData aux;
		
		Collection<PersonalData> cs = personalDataService.findAll();
		aux=(PersonalData) cs.toArray()[0];
		
		res=offerService.offersPerPersonalData(aux.getId());
		Assert.notNull(res);
	}
	
	
}
