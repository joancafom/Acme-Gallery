package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.PersonalData;
import domain.User;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class PersonalDataServiceTest extends AbstractTest{
	
	@Autowired
	private PersonalDataService personalDataService;
	
	@Autowired
	private UserService userService;
	
	@Test
	public void testFindOnePersonalData() {
		PersonalData result;
		PersonalData aux;

		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		aux = (PersonalData) personalDatas.toArray()[0];

		result = personalDataService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllPersonalData() {
		Collection<PersonalData> personalDatas;

		personalDatas = this.personalDataService.findAll();
		Assert.notNull(personalDatas);
	}
	
	
	@Test
	public void testCreatePersonalData() {
		super.authenticate("user1");
		PersonalData personalData;

		User user = this.userService.findByPrincipal();
		Assert.notNull(user);

		personalData = this.personalDataService.create();
		Assert.notNull(personalData);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSavePersonalData() {
		
		super.authenticate("user1");
		PersonalData personalData;

		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		personalData = (PersonalData) personalDatas.toArray()[0];
	
		personalData.setName("prueba");

		personalData=personalDataService.save(personalData);
	}
	
	@Test
	public void testDeletePersonalData() {
		super.authenticate("user1");

		PersonalData result;
		PersonalData aux;

		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas  = personalDataService.findAll();
		aux = (PersonalData) personalDatas.toArray()[0];

		result = personalDataService.findOne(aux.getId());

		this.personalDataService.delete(result);
	}
	
	@Test
	public void testPersonalDataPerUser() {
		User user;
		PersonalData personalData;
		
		Collection<User> users = new ArrayList<User>();
		users = userService.findAll();
		user = (User) users.toArray()[0];
		
		personalData = this.personalDataService.personalDataPerUser(user.getId());
		Assert.notNull(personalData);
	}
	
	@Test
	public void testUserByPersonalDataId() {
		User user;
		PersonalData personalData;
		
		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		personalData = (PersonalData) personalDatas.toArray()[0];
		
		user = this.personalDataService.userByPersonalDataId(personalData.getId());
		Assert.notNull(user);
	}

}
