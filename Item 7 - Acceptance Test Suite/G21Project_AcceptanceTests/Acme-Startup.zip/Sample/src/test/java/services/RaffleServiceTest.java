package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Raffle;
import domain.User;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class RaffleServiceTest extends AbstractTest{
	
	@Autowired
	private RaffleService raffleService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AdminService adminService;
	
	@Test
	public void testFindOneRaffle() {
		Raffle result;
		Raffle aux;

		Collection<Raffle> raffles = new ArrayList<Raffle>();
		raffles = raffleService.findAll();
		aux = (Raffle) raffles.toArray()[0];

		result = raffleService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllRaffle() {
		Collection<Raffle> raffles;

		raffles = this.raffleService.findAll();
		Assert.notNull(raffles);
	}
	
	
	@Test
	public void testCreateRaffle() {
		super.authenticate("admin");
		Raffle raffle;

		Admin admin = this.adminService.findByPrincipal();
		Assert.notNull(admin);

		raffle = this.raffleService.create();
		Assert.notNull(raffle);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSaveRaffle() {
		
		super.authenticate("admin");
		Raffle raffle;

		Collection<Raffle> raffles = new ArrayList<Raffle>();
		raffles = raffleService.findAll();
		raffle = (Raffle) raffles.toArray()[0];
	
		raffle.setGift("prueba");

		raffle=raffleService.save(raffle);
	}
	
	@Test
	public void testDeleteRaffle() {
		super.authenticate("admin");

		Raffle result;
		Raffle aux;

		Collection<Raffle> raffles = new ArrayList<Raffle>();
		raffles  = raffleService.findAll();
		aux = (Raffle) raffles.toArray()[0];

		result = raffleService.findOne(aux.getId());

		this.raffleService.delete(result);
	}
	
	@Test
	public void testRafflesPerAdmin() {
		Admin admin;
		Collection<Raffle> raffles;
		
		Collection<Admin> admins = new ArrayList<Admin>();
		admins = adminService.findAll();
		admin = (Admin) admins.toArray()[0];
		
		raffles = this.raffleService.rafflesPerAdmin(admin.getId());
		Assert.notNull(raffles);
	}
	
	@Test
	public void testAdminByRaffleId() {
		Admin admin;
		Raffle raffle;
		
		Collection<Raffle> raffles = new ArrayList<Raffle>();
		raffles = raffleService.findAll();
		raffle = (Raffle) raffles.toArray()[0];
		
		admin = this.raffleService.adminByRaffleId(raffle.getId());
		Assert.notNull(admin);
	}
	
	@Test
	public void testRafflesPerTitle() {
		Collection<Raffle> raffles;
		String title = "hola";
		
		raffles = this.raffleService.rafflesPerTitle(title);
		Assert.notNull(raffles);
	}

	@Test
	public void testActiveRaffles() {
		Collection<Raffle> raffles;
		
		raffles = this.raffleService.activeRafles();
		Assert.notNull(raffles);
	}
	
	@Test
	public void testTodayRaffles() {
		Collection<Raffle> raffles;
		
		raffles = this.raffleService.todayRaffles();
		Assert.notNull(raffles);
	}
	
	@Test
	public void testRafflesPerUser() {
		User user;
		Collection<Raffle> raffles;
		
		Collection<User> users = new ArrayList<User>();
		users = userService.findAll();
		user = (User) users.toArray()[0];
		
		raffles = this.raffleService.rafflesPerUser(user.getId());
		Assert.notNull(raffles);
	}
	
}
