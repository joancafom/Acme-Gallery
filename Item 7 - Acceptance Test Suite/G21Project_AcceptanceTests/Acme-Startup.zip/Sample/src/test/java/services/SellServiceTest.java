package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import domain.Company;
import domain.Item;
import domain.Merchant;
import domain.Sell;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class SellServiceTest extends AbstractTest {

	@Autowired
	private SellService sellService;
	
	@Autowired
	private MerchantService merchantService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private ItemService itemService;
	
	@Test
	public void testCreateSell() {
		this.sellService.create();
	}
	
	@Test
	public void testFindOneSell() {
		Sell sell = (Sell) this.sellService.findAll().toArray()[0];
		
		this.sellService.findOne(sell.getId());
	}
	
	@Test
	public void testSaveSell() {
		Sell sell = (Sell) this.sellService.findAll().toArray()[0];
		sell.setDirection("Calle montana");
		
		this.sellService.saveSell(sell);
	}
	
	@Test
	public void findSellsByMerchant() {
		super.authenticate("merchant1");
		Merchant merchant;
		
		merchant = this.merchantService.findByPrincipal();
		
		this.sellService.findSellsByMerchant(merchant.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void findSellByMerchantAndCondition() {
		super.authenticate("merchant1");
		Merchant merchant;
		
		merchant = this.merchantService.findByPrincipal();
		
		this.sellService.findSellsByMerchantAndCondition(merchant.getId(), true);
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindSellByCompany() {
		super.authenticate("company1");
		Company company;
		
		company = this.companyService.findByPrincipal();
		
		this.sellService.findSellsByCompany(company.getId());
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindSellByCompanyAndCondition() {
		super.authenticate("company1");
		Company company;
		
		company = this.companyService.findByPrincipal();
		
		this.sellService.findSellsByCompanyAndCondition(company.getId(), false);
		
		super.unauthenticate();
	}
	
	@Test
	public void testFindSellsByItem() {
		Item item = (Item) this.itemService.findAll().toArray()[0];
		
		this.sellService.findSellsByItem(item);
	}
	
	@Test
	public void testFindSellsByPrincipal() {
		super.authenticate("merchant1");
		
		this.merchantService.findByPrincipal();
		
		super.unauthenticate();
	}
}
