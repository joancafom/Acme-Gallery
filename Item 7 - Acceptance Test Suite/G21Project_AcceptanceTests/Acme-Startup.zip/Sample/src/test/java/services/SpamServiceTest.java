
package services;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Configuration;
import domain.Spam;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class SpamServiceTest extends AbstractTest {

	//Service under test ---------------------
	@Autowired
	private SpamService spamService;

	//Supporting services --------------------
	@Autowired
	private AdminService adminService;
	//Tests ----------------------------------


	@Test
	public void testCreateSpamWord() {
		authenticate("admin");
		Spam sw = spamService.create();
		Assert.notNull(sw);
		authenticate(null);

	}

	@Test
	public void testFindOneSpamWord() {
		Spam sw;

		
		Collection<Spam> advertisements = new ArrayList<Spam>();
		advertisements = spamService.findAll();
		sw = (Spam) advertisements.toArray()[0];
		sw = spamService.findOne(sw.getId());
		Assert.notNull(sw);

	}

	@Test
	public void testFindAllSpamWord() {
		authenticate("admin");

		Collection<Spam> sws;

		sws = spamService.findAll();
		Assert.notNull(sws);


		authenticate(null);

	}

	@Test
	public void testSaveSpamWord() {
		authenticate("admin");
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);

		Spam sw = spamService.create();
		sw.setName("consolador");
		Assert.notNull(sw);
		spamService.save(sw);

		authenticate(null);
	}

	@Test
	public void testDeleteSpamWord() {
		authenticate("admin");
		Spam sw;

		
		Collection<Spam> advertisements = new ArrayList<Spam>();
		advertisements = spamService.findAll();
		sw = (Spam) advertisements.toArray()[0];
		sw = spamService.findOne(sw.getId());
		spamService.delete(sw);
		authenticate(null);

	}

	@Test
	public void testfindAllSpamWordByKeyword() {
		authenticate("admin");
		Collection<Spam> sws;

		sws = spamService.findAllSpamByKeyword("sex");
		Assert.notNull(sws);


		authenticate(null);

	}

}
