
package services;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Announcement;
import domain.Basket;
import domain.Cooperate;
import domain.Item;
import domain.Sponsor;
import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class SponsorServiceTest extends AbstractTest {

	@Autowired
	private SponsorService sponsorService;

	@Autowired
	private BasketService basketService;


	private Sponsor sponsorExample() {
		Sponsor u = sponsorService.create();
		u.setName("Name");
		u.setEmail("email@email.com");
		u.setPhone("123123123");
		u.setAddress("Address");
		u.setPostalAddress("43213");
		u.setBuyStore(null);
		Collection<Cooperate> cooperates = new HashSet<Cooperate>();
		u.setCooperates(cooperates);
		Collection<Announcement> announcements = new HashSet<Announcement>();
		u.setAnnouncements(announcements);

		Basket b = new Basket();
		Collection<Item> items = new HashSet<Item>();
		b.setItems(items);
		b.setDate(new Date(System.currentTimeMillis() - 1000));
		b.setTotal(0.0);
		Basket bb = basketService.save(b);
		u.setBasket(bb);

		Authority auth = new Authority();
		auth.setAuthority(Authority.SPONSOR);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername("username");
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword("password", null));
		userAccount.getAuthorities().add(auth);
		userAccount.setBanned(true);
		u.setUserAccount(userAccount);
		Sponsor result = sponsorService.save(u);

		return result;
	}

	@Test
	public void testFindOneSponsor() {
		Sponsor result = sponsorService.findOne(sponsorExample().getId());
		Assert.notNull(result);
		this.sponsorService.delete(result);
	}

	@Test
	public void testFindAllSponsor() {
		Collection<Sponsor> sponsors;

		sponsors = this.sponsorService.findAll();
		Assert.notNull(sponsors);
	}

	@Test
	public void testCreateSponsor() {

		Sponsor sponsor = this.sponsorService.create();
		Assert.notNull(sponsor);

	}

	@Test
	public void testSaveSponsor() {

		Sponsor sponsor = sponsorExample();
		sponsor = sponsorService.save(sponsor);
	}

	@Test
	public void testDeleteSponsor() {
		Sponsor result = sponsorExample();
		this.sponsorService.delete(result);
	}

}
