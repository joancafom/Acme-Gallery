package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Category;
import domain.Cooperate;
import domain.News;
import domain.Offer;
import domain.Spam;
import domain.Startup;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class StartupServiceTest extends AbstractTest{
	
	//Service under test ---------------------
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private SpamService spamService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private CooperateService cooperateService;
	
	//Tests ----------------------------------
	@Test
	public void testCreateStartup() {
		authenticate("company1");
		Startup c = startupService.create();
		Assert.notNull(c);
		authenticate(null);

	}

	@Test
	public void testFindOneStartup() {
		Startup res;
		Startup aux;
		
		Collection<Startup> cs = startupService.findAll();
		aux=(Startup) cs.toArray()[0];
		
		res=startupService.findOne(aux.getId());
		Assert.notNull(res);

	}

	@Test
	public void testFindAllStartup() {

		Collection<Startup> cs;

		cs = startupService.findAll();
		Assert.notNull(cs);
	}
	
	@Test
	public void testSaveStartup() {
		authenticate("company1");

		Startup res;
		Startup aux;
		Collection<Startup> cs = new ArrayList<Startup>();
		cs = startupService.findAll();
		aux=(Startup) cs.toArray()[0];
		
		res=startupService.findOne(aux.getId());
		res.setDescription("PRUEBA");
		startupService.save(res);
		Assert.notNull(res);
	}
	
	@Test
	public void testDeleteStartup() {
		authenticate("company1");
		
		Startup res;
		Startup aux;
		
		Collection<Startup> cs = startupService.findAll();
		aux=(Startup) cs.toArray()[0];
		
		res=startupService.findOne(aux.getId());
		startupService.delete(res);
		authenticate(null);

	}
	
	@Test
	public void testStartupsPerCategory() {
		Collection<Startup> res;
		Category aux;
		
		Collection<Category> cs = categoryService.findAll();
		aux=(Category) cs.toArray()[0];
		
		res=startupService.startupsPerCategory(aux.getId());
		Assert.notNull(res);

	}
	
	@Test
	public void testStartupsPerKeyWord() {
		Collection<Startup> res;
		Spam aux;
		
		Collection<Spam> cs = spamService.findAll();
		aux=(Spam) cs.toArray()[0];
		
		res=startupService.startupPerKeyWord(aux.getName());
		Assert.notNull(res);

	}
	
	
	@Test
	public void testStartupPerNews() {
		Startup res;
		News aux;
		
		Collection<News> cs = newsService.findAll();
		aux=(News) cs.toArray()[0];
		
		res=startupService.startupPerNews(aux.getId());
		Assert.notNull(res);

	}
	
	@Test
	public void testStartupsPerCooperate() {
		Startup res;
		Cooperate aux;
		
		Collection<Cooperate> cs = cooperateService.findAll();
		aux=(Cooperate) cs.toArray()[0];
		
		res=startupService.startupPerCooperate(aux.getId());
		Assert.notNull(res);

	}
	
	@Test
	public void testStartupsPerOffer() {
		Startup res;
		Offer aux;
		
		Collection<Offer> cs = offerService.findAll();
		aux=(Offer) cs.toArray()[0];
		
		res=startupService.startupPerOffer(aux.getId());
		Assert.notNull(res);

	}
	
	
	
	
	
	

}
