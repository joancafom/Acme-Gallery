
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Spam;
import domain.Tag;

import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class TagServiceTest extends AbstractTest {

	//Service under test ---------------------
	@Autowired
	private TagService tagService;

	//Supporting services --------------------
	@Autowired
	private AdminService adminService;
	//Tests ----------------------------------


	@Test
	public void testCreateTag() {
		authenticate("admin");
		Tag t = tagService.create();
		Assert.notNull(t);
		authenticate(null);

	}

	@Test
	public void testFindOneTag() {
		Tag t;
		

		
		Collection<Tag> advertisements = new ArrayList<Tag>();
		advertisements = tagService.findAll();
		t = (Tag) advertisements.toArray()[0];
		t = tagService.findOne(t.getId());


		Assert.notNull(t);

	}

	@Test
	public void testFindAllTag() {
		authenticate("admin");

		Collection<Tag> ts;

		ts = tagService.findAll();
		Assert.notNull(ts);

		authenticate(null);

	}

	@Test
	public void testSaveTag() {
		authenticate("admin");
		Admin a = adminService.findByPrincipal();
		Assert.notNull(a);
		Tag t;
		

		
		Collection<Tag> advertisements = new ArrayList<Tag>();
		advertisements = tagService.findAll();
		t = (Tag) advertisements.toArray()[0];
		t = tagService.findOne(t.getId());
		t.setName("Rota");
		Assert.notNull(t);
		tagService.save(t);

		authenticate(null);
	}

	@Test
	public void testDeleteTag() {
		authenticate("admin");

		Tag t;
		

		
		Collection<Tag> advertisements = new ArrayList<Tag>();
		advertisements = tagService.findAll();
		t = (Tag) advertisements.toArray()[0];
		t = tagService.findOne(t.getId());
		tagService.delete(t);

		authenticate(null);

	}

	
	
	

	
}
