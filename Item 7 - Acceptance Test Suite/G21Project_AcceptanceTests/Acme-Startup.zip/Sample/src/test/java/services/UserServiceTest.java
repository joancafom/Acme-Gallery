
package services;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Basket;
import domain.Comment;
import domain.Item;
import domain.Startup;
import domain.User;
import security.Authority;
import security.UserAccount;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class UserServiceTest extends AbstractTest {

	@Autowired
	private UserService userService;

	@Autowired
	private BasketService basketService;


	private User userExample() {
		User u = userService.create();
		u.setName("Name");
		u.setEmail("email@email.com");
		u.setPhone("123123123");
		u.setAddress("Address");
		u.setPostalAddress("43213");
		u.setSurname("Surname");
		u.setProfession("Profession");
		u.setCreditCard(null);
		Collection<Comment> comments = new HashSet<Comment>();
		u.setComments(comments);
		Collection<Startup> startups = new HashSet<Startup>();
		u.setStartups(startups);
		u.setPro(false);
		Basket b = new Basket();
		Collection<Item> items = new HashSet<Item>();
		b.setItems(items);
		b.setDate(new Date(System.currentTimeMillis() - 1000));
		b.setTotal(0.0);
		Basket bb = basketService.save(b);
		u.setBasket(bb);
		Authority auth = new Authority();
		auth.setAuthority(Authority.USER);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername("username");
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword("password", null));
		userAccount.getAuthorities().add(auth);
		userAccount.setBanned(true);
		u.setUserAccount(userAccount);
		User result = userService.save(u);

		return result;
	}

	@Test
	public void testFindOneUser() {
		User result = userService.findOne(userExample().getId());
		Assert.notNull(result);
		this.userService.delete(result);
	}

	@Test
	public void testFindAllUser() {
		Collection<User> users;

		users = this.userService.findAll();
		Assert.notNull(users);
	}

	@Test
	public void testCreateUser() {

		User user = this.userService.create();
		Assert.notNull(user);

	}

	@Test
	public void testSaveUser() {

		User user = userExample();
		user = userService.save(user);
	}

	@Test
	public void testDeleteUser() {

		User result = userExample();

		this.userService.delete(result);
	}

}
