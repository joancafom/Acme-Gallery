package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import domain.Work;
import domain.PersonalData;
import domain.User;
import utilities.AbstractTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/datasource.xml", "classpath:spring/config/packages.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class WorkServiceTest extends AbstractTest{
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private PersonalDataService personalDataService;
	
	@Test
	public void testFindOneWork() {
		Work result;
		Work aux;

		Collection<Work> works = new ArrayList<Work>();
		works = workService.findAll();
		aux = (Work) works.toArray()[0];

		result = workService.findOne(aux.getId());
		Assert.notNull(result);
	}
	
	@Test
	public void testFindAllWork() {
		Collection<Work> works;

		works = this.workService.findAll();
		Assert.notNull(works);
	}
	
	
	@Test
	public void testCreateWork() {
		super.authenticate("user1");
		Work work;

		User user = this.userService.findByPrincipal();
		Assert.notNull(user);

		work = this.workService.create();
		Assert.notNull(work);

		super.authenticate(null);
	}
	
	
	@Test
	public void testSaveWork() {
		
		super.authenticate("user1");
		Work work;

		Collection<Work> works = new ArrayList<Work>();
		works = workService.findAll();
		work = (Work) works.toArray()[0];


		work.setCompany("PRUEBA");

		work=workService.save(work);
	}
	
	@Test
	public void testDeleteWork() {
		super.authenticate("user1");

		Work result;
		Work aux;

		Collection<Work> works = new ArrayList<Work>();
		works  = workService.findAll();
		aux = (Work) works.toArray()[0];

		result = workService.findOne(aux.getId());

		this.workService.delete(result);
	}
	
	@Test
	public void testWorkPerPersonalData() {
		Collection<Work> works;
		PersonalData personalData;
		
		Collection<PersonalData> personalDatas = new ArrayList<PersonalData>();
		personalDatas = personalDataService.findAll();
		personalData = (PersonalData) personalDatas.toArray()[0];
		
		works = this.workService.workPerPersonalData(personalData.getId());
		Assert.notNull(works);
	}
	
	
	@Test
	public void testUserByWorkId() {
		Work work;
		User user;
		
		Collection<Work> works = new ArrayList<Work>();
		works = workService.findAll();
		work = (Work) works.toArray()[0];
		
		user = this.workService.userByWorkId(work.getId());
		Assert.notNull(user);
	}
	
	
	@Test
	public void testPersonalDataByWorkId() {
		PersonalData personalData;
		Work work;
		
		Collection<Work> works = new ArrayList<Work>();
		works = workService.findAll();
		work = (Work) works.toArray()[0];
		
		personalData = this.workService.personalDataByWorkId(work.getId());
		Assert.notNull(personalData);
	}
	
	

}
