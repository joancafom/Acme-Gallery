package usecases;

import java.util.Collection;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import domain.Basket;
import domain.CreditCard;
import domain.Item;
import domain.Sponsor;
import domain.User;
import services.BasketService;
import services.ItemService;
import services.SponsorService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
		"classpath:spring/junit.xml"
	})
	@RunWith(SpringJUnit4ClassRunner.class)
	@Transactional
public class BasketUseCases extends AbstractTest {

	@Autowired
	private BasketService basketService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SponsorService sponsorService;
	
	@Autowired
	private ItemService itemService;
	
	@Test
	public void testBuy() {
		CreditCard creditCard = new CreditCard();
		creditCard.setBrandName("Unicaja");
		creditCard.setCvvCode("725");
		creditCard.setExpirationMonth("11");
		creditCard.setExpirationYear("20");
		creditCard.setHolderName("Antonio");
		creditCard.setNumber("4539967051853937");
		
		CreditCard fail = new CreditCard();
		creditCard.setBrandName("Unicaja");
		creditCard.setCvvCode("725");
		creditCard.setExpirationMonth("11");
		creditCard.setExpirationYear("11");
		creditCard.setHolderName("Antonio");
		creditCard.setNumber("4539967051853937");
		
		final Object testingData[][] = {
				{
					"user1", creditCard, "c/ castilla", null
				}, {
					"user1", fail, "c/ castilla", NullPointerException.class
				}, {
					"sponsor3", creditCard, "c/ castilla", NullPointerException.class
				}, {
					"sponsor1", creditCard, "c/ castilla", null
				}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.buyTemplate((String) testingData[i][0], (CreditCard) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3]);
		}
	}
	
	protected void buyTemplate(final String username, final CreditCard creditCard, final String direction, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		User user;
		Basket basket;
		Sponsor sponsor;
		
		try {
			super.authenticate(username);
			
			if (username.contains("user")) {
				user = this.userService.findByPrincipal();
				basket = user.getBasket();
			} else {
				sponsor = this.sponsorService.findByPrincipal();
				basket = sponsor.getBasket();
			}
			
			this.basketService.pay(creditCard, direction);
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
	
	@Test
	public void testAdd() {
		final Object testingData[][] = {
				{
					"user1", 1448, null
				}, {
					"user1", 1456, IllegalArgumentException.class
				}, {
					"sponsor1", 1448, null
				}, {
					"sponsor1", 1456, IllegalArgumentException.class
				}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.addTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
		}
	}
	
	protected void addTemplate(final String username, final int itemId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		Collection<Item> items;
		
		try {
			super.authenticate(username);
			
			items = this.itemService.findAllNotDeleted();
			
			this.basketService.addProduct(itemId);
		} catch (Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
	
	@Test
	public void testDelete() {
		final Object testingData[][] = {
				{
					"user1", 1448, null
				}, {
					"user1", 1451, null
				}, {
					"sponsor1", 1448, null
				}, {
					"sponsor1", 1451, null
				}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.addTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
		}
	}
	
	protected void deleteTemplate(final String username, final int itemId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		Basket basket;
		
		try {
			super.authenticate(username);
			
			basket = this.basketService.findByPrincipal();
			
			this.basketService.deleteProduct(itemId);
		} catch (Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
}
