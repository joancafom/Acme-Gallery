package usecases;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Category;
import services.CategoryService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
		"classpath:spring/junit.xml"
	})
	@RunWith(SpringJUnit4ClassRunner.class)
	@Transactional
public class CategoryUseCases extends AbstractTest{
	
	@Autowired
	private CategoryService categoryService;
	
	
	//BORRAR CATEGORY---------------------------------------------------------------
	@Test 
	public void deleteCategory() {

		final Object testingData[][] = {
			{
				/* Delete a category */
				"admin", 1492, null
			}, {
				/* Trying to delete a category without authentication */
				null, 1492, IllegalArgumentException.class
			}, {
				/* Trying to delete a category that doesn't exist */
				"admin", 0, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.deleteCategoryTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);

	}
	
	/*
	 * 13.2 
	 * */
	protected void deleteCategoryTemplate(final String username, final int categoryId, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			final Category category;
			Collection<Category> aux = new ArrayList<Category>();
			aux=categoryService.findAll();
			Assert.notNull(aux);
			category = categoryService.findOne(categoryId);
			categoryService.delete(category);
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}

		this.checkExceptions(expected, caught);
	}	
	
	
	//CREAR CATEGORY-----------------------------------------------------------
	@Test
	public void createCategory() {

		final Object testingData[][] = {
			{
				/* Create a category */
				"admin", "NAME", null

			}, {
				/* Trying to create a category without authentication */
				null, "NAME", IllegalArgumentException.class
			}, {
				/* Trying to create a category a manager */
				"manager1", "NAME", IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.createCategoryTemplate((String) testingData[i][0], (String) testingData[i][1], (Class<?>) testingData[i][2]);

	}
	
	
	/*
	 * 13.2
	 * */
	protected void createCategoryTemplate(final String username, final String name, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			Category cateogry= categoryService.create();
			cateogry.setName(name);
			this.categoryService.save(cateogry);
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}	

	
	
	//EDIT CATEGORY-------------------------------------------------------------
	
	@Test
	public void editCategory() {

		final Object testingData[][] = {
			{
				/* Edit a category */
				"admin", 1491, "TestMessageFolderJUnit", null
			}, {
				/* Trying to edit a messageFolder without authentication */
				null, 1491, "TestMessageFolderJUnit", IllegalArgumentException.class
			}
			, {
				/*Trying to edit a category being manager1 */
				"manager1", 1128, "TestMessageFolderJUnit", IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.editCategoryTemplate((String) testingData[i][0], (int) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3]);

	}
	
	
	/*
	 * 13.2 
	 * */
	protected void editCategoryTemplate(final String username, final int categoryId, final String name, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			Collection<Category> aux = new ArrayList<Category>();
			aux=categoryService.findAll();
			Assert.notNull(aux);
			final Category category= categoryService.findOne(categoryId);
			category.setName(name);
			categoryService.save(category);
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

}
