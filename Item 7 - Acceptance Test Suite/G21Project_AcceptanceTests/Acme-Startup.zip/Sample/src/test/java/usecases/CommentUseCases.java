package usecases;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Admin;
import domain.Comment;
import domain.Item;
import domain.News;
import domain.Startup;
import domain.User;
import services.AdminService;
import services.CommentService;
import services.ItemService;
import services.NewsService;
import services.StartupService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class CommentUseCases extends AbstractTest {

	@Autowired
	private CommentService commentService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private AdminService adminService;
	
	@Test
	public void testComment() {
		Date creationDate = new Date(System.currentTimeMillis());
		
		Comment comment = this.commentService.create();
		comment.setBody("Cuerpo de prueba");
		comment.setComments(new ArrayList<Comment>());
		comment.setCreationDate(creationDate);
		
		Comment fail = this.commentService.create();
		final Object testingData[][] = {
			{
				comment, "user1", "comment", 1437, null
			}, {
				fail, "user1", "comment", 1437, IllegalArgumentException.class
			}, {
				comment, "user1", "comment", 0, IllegalArgumentException.class
			}, {
				comment, null, "comment", 1437, IllegalArgumentException.class
			}, {
				null, "user1", "comment", 1437, NullPointerException.class
			}, {
				comment, "user1", "news", 1430, null
			},  {
				comment, "user1", "news", 0, IllegalArgumentException.class
			}, {
				fail, "user1", "news", 1430, IllegalArgumentException.class
			}, {
				comment, null, "news", 1430, IllegalArgumentException.class
			}, {
				null, "user1", "news", 1430, NullPointerException.class
			}, {
				comment, "user1", "item", 1448, null
			}, {
				fail, "user1", "item", 1448, IllegalArgumentException.class
			}, {
				comment, "user1", "item", 0, IllegalArgumentException.class
			}, {
				comment, null, "item", 1448, IllegalArgumentException.class
			}, {
				null, "user1", "item", 1448, NullPointerException.class
			}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.commentTemplate((Comment) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (int) testingData[i][3], (Class<?>) testingData[i][4]);
		}
	}
	
	protected void commentTemplate(final Comment comment, final String username, final String use, final int id, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		User user;
		Collection<Comment> comments;
		Comment comment2;
		Collection<Item> items;
		Item item;
		Collection<News> newsCollection;
		News news;
		Collection<Startup> startups;
		Startup startup;
		
		try {
			super.authenticate(username);
			user = this.userService.findByPrincipal();
			
			if (use == "comment") {
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = (News) newsCollection.toArray()[0];
				comments = news.getComments();
				comment2 = this.commentService.findOne(id);
				Assert.notNull(comment.getBody());
				
				this.commentService.saveComment(comment, id);
			} else if (use == "news") {
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = this.newsService.findOne(id);
				Assert.notNull(comment.getBody());
				
				this.commentService.saveCommentNew(comment, id);
			} else {
				items = this.itemService.findAll();
				item = this.itemService.findOne(id);
				Assert.notNull(comment.getBody());
				
				this.commentService.saveCommentItem(comment, id);
			}
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
	
	@Test
	public void testEditComment() {
		final Object testingData[][] = {
			{
				"user1", "comment", 1437, "Edit de prueba", null
			}, {
				"user1", "news", 1437, "Edit de prueba", null
			}, {
				"user1", "item", 1437, "Edit de prueba", null
			}, {
				"user1", "comment", 1437, null, IllegalArgumentException.class
			}, {
				"user2", "comment", 1437, "Edit de prueba", IllegalArgumentException.class
			}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.editCommentTemplate((String) testingData[i][0], (String) testingData[i][1], (int) testingData[i][2], (String) testingData[i][3], (Class<?>) testingData[i][4]);
		}
	}
	
	protected void editCommentTemplate(final String username, final String use, final int id, final String edit, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		User user;
		Collection<Comment> comments;
		Comment comment;
		Collection<Item> items;
		Item item;
		Collection<News> newsCollection;
		News news;
		Collection<Startup> startups;
		Startup startup;
		
		try {
			super.authenticate(username);
			user = this.userService.findByPrincipal();
			Assert.notNull(edit);
			
			if (use == "comment") {
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = (News) newsCollection.toArray()[0];
				comments = news.getComments();
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				comment.setBody(edit);
				this.commentService.save(comment);
			} else if (use == "news") {
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = (News) newsCollection.toArray()[0];
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				comment.setBody(edit);
				this.commentService.save(comment);
			} else {
				items = this.itemService.findAll();
				item = (Item) items.toArray()[0];
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				comment.setBody(edit);
				this.commentService.save(comment);
			}
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
	
	@Test
	public void testDeleteComment() {
		final Object testingData[][] = {
			{
				"user1", "comment", 1437, null
			}, {
				"user1", "news", 1437, IllegalArgumentException.class
			}, {
				"user1", "item", 1438, null
			}, {
				"admin", "admin", 1437, null
			}, {
				"user2", "comment", 1437, IllegalArgumentException.class
			}
		};
		
		for (int i = 0; i < testingData.length; i++) {
			this.deleteCommentTemplate((String) testingData[i][0], (String) testingData[i][1], (int) testingData[i][2], (Class<?>) testingData[i][3]);
		}
	}
	
	protected void deleteCommentTemplate(final String username, final String use, final int id, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		User user;
		Collection<Comment> comments;
		Comment comment;
		Collection<Item> items;
		Item item;
		Collection<News> newsCollection;
		News news;
		Collection<Startup> startups;
		Startup startup;
		Admin admin;
		
		try {
			super.authenticate(username);
			
			
			if (use == "comment") {
				user = this.userService.findByPrincipal();
				
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = (News) newsCollection.toArray()[0];
				comments = news.getComments();
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				this.commentService.deleteComplete(id);;
			} else if (use == "news") {
				user = this.userService.findByPrincipal();
				
				startups = this.startupService.findAll();
				startup = (Startup) startups.toArray()[0];
				newsCollection = startup.getNews();
				news = (News) newsCollection.toArray()[0];
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				this.commentService.deleteComplete(id);
			} else if (use == "item") {
				user = this.userService.findByPrincipal();
				
				items = this.itemService.findAll();
				item = (Item) items.toArray()[0];
				
				comment = this.commentService.findOne(id);
				Assert.isTrue(user.getComments().contains(comment));
				this.commentService.deleteComplete(id);
			} else {
				admin = this.adminService.findByPrincipal();
				
				this.commentService.deleteComplete(id);
			}
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.unauthenticate();
		this.checkExceptions(expected, caught);
	}
}
