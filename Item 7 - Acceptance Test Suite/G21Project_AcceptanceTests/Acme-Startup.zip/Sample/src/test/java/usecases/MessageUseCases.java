
package usecases;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import domain.Actor;
import domain.Message;
import forms.MessageForm;
import services.ActorService;
import services.MessageService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class MessageUseCases extends AbstractTest {

	@Autowired
	private MessageService messageService;

	@Autowired
	private ActorService actorService;


	//---------------------------TEST-------------------------------------------------

	@Test
	public void testMessage() {
		final Object testingData[][] = {
			{
				/* Message V�lido */
				formMessageValido(), null

			},
			{
				/* Message No Valido */
				formMessageNoValido(), IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.drive((MessageForm) testingData[i][0], (Class<?>) testingData[i][1]);

	}

	//---------------------------TEMPLATE---------------------------------------------

	protected void drive(MessageForm messageForm, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			Message s = messageService.create();
			super.authenticate("user1");
			Actor actorFrom = actorService.findByPrincipal();
			s.setActorFrom(actorFrom);
			s.setBody(messageForm.getBody());
			s.setPriority(messageForm.getPriority());
			s.setSubject(messageForm.getSubject());
			s.setActorTo(actorService.findActorForEmail(messageForm.getEmail()));
			messageService.save(s);
			super.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

	private MessageForm formMessageValido() {
		MessageForm result = new MessageForm();

		result.setBody("HOLA, COMO ESTAS?");
		result.setEmail("angelizaga@gmail.com");
		result.setPriority("LOW");
		result.setSubject("MENSAJE DE PRUEBA");

		return result;
	}

	private MessageForm formMessageNoValido() {
		MessageForm result = new MessageForm();

		result.setBody("HOLA, COMO ESTAS?");
		result.setEmail("");
		result.setPriority("LOW");
		result.setSubject("MENSAJE DE PRUEBA");

		return result;
	}

}
