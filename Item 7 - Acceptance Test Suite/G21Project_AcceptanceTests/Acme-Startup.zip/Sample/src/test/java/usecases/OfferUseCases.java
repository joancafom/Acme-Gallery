package usecases;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Offer;
import domain.Startup;
import domain.User;
import services.OfferService;
import services.StartupService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = { "classpath:spring/junit.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class OfferUseCases extends AbstractTest {

	@Autowired
	private OfferService offerService;

	@Autowired
	private UserService userService;
	
	@Autowired
	private StartupService startupService;

	// Aplicar a una
	// oferta---------------------------------------------------------------
	@Test
	public void applyOffer() {

		final Object testingData[][] = {
				{
						/* Aplicar a una oferta siendo user1 */
						"user1", 1442, null },
				{
						/* Aplicar a una oferta siendo user2 */
						"user2", 1444, null },
				{
						/* Aplicar a una oferta sin autenticaci�n */
						null, 1492, IllegalArgumentException.class },
				{
						/* Aplicar a una oferta siendo admin */
						"admin", 1442, IllegalArgumentException.class },
				{
						/* Aplicar a una oferta siendo merchant1 */
						"merchant1", 1442, IllegalArgumentException.class },
				{
						/* Aplicar a una oferta siendo sponsor1 */
						"sponsor1", 1442, IllegalArgumentException.class },
				{
						/* Aplicar a una oferta siendo company1 */
						"company1", 1442, IllegalArgumentException.class },
				{
						/*
						 * Aplicar a una oferta a la que ya has aplicado siendo
						 * user1
						 */
						"user1", 1441, IllegalArgumentException.class },
				{
						/*
						 * Aplicar a una oferta a la que ya has aplicado siendo
						 * user2
						 */
						"user2", 1442, IllegalArgumentException.class },
				{
						/* Aplicar a una oferta que no existe */
						"user1", 0, IllegalArgumentException.class }

		};

		for (int i = 0; i < testingData.length; i++)
			this.applyOfferTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);

	}

	/*
	 * 12.1
	 */
	protected void applyOfferTemplate(final String username, final int offerId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			User user = userService.findByPrincipal();
			Collection<Startup> startups = new ArrayList<Startup>();
			startups=startupService.findAll();
			Assert.notNull(startups);
			Startup startup = startupService.startupPerOffer(offerId);
			Assert.notNull(startup);
			Offer offer = offerService.findOne(offerId);
			this.offerService.apply(offer, user.getId());
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

}
