package usecases;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Raffle;
import domain.User;
import services.RaffleService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
		"classpath:spring/junit.xml"
	})
	@RunWith(SpringJUnit4ClassRunner.class)
	@Transactional
public class RaffleUseCases extends AbstractTest {
	
	@Autowired
	private RaffleService raffleService;
	
	@Autowired
	private UserService userService;
	
	
	//INSCRIBIRSE A UN CONCURSO---------------------------------------------------------------
	@Test 
	public void inscribeRaffle() {

		final Object testingData[][] = {
			{
				/* Inscribirse a un concurso*/
				"user1", 1506, null
			}, {
				/* Inscribirse a una concurso sin autenticaci�n */
				null, 1523, IllegalArgumentException.class
			}, {
				/* Inscribirse a una concurso que ya est�s inscrito */
				"user1", 1502, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.inscribeRaffleTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}
	
	
	
	/*
	 * 43.2
	 */
	protected void inscribeRaffleTemplate(final String username, final int raffleId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			Date momento = new Date(System.currentTimeMillis() - 1000);
			this.authenticate(username);
			User user = userService.findByPrincipal();
			Collection<Raffle> raffles = new ArrayList<Raffle>();
			raffles=raffleService.findAll();
			Assert.notNull(raffles);
			Raffle raffle= raffleService.findOne(raffleId);
			Assert.isTrue(!(raffle.getUsers().contains(user)));
			Assert.isTrue(raffle.getDateFinish().after(momento));
			this.raffleService.inscribe(raffle, user.getId());
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}
	
	
	//SELECCIONAR GANADOR DE UN CONCURSO---------------------------------------------------------------
	@Test 
	public void winnerRaffle() {

		final Object testingData[][] = {
			{
				/* Seleccionar ganador de un concurso*/
				"user1", 1502, null
			}, {
				/* Seleccionar ganador de un concurso sin autenticaci�n*/
				null, 1523, IllegalArgumentException.class
			}, {
				/*Hacer ganador del concurso a un usario que no est� inscrito */
				"user1", 1506, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.winnerRaffleTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}
	
	
	
	/*
	 * 46
	 */
	protected void winnerRaffleTemplate(final String username, final int raffleId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			User user = userService.findByPrincipal();
			Collection<Raffle> raffles = new ArrayList<Raffle>();
			raffles=raffleService.findAll();
			Assert.notNull(raffles);
			Raffle raffle= raffleService.findOne(raffleId);
			Assert.isTrue(!raffle.getClosed());
			Assert.isTrue(raffle.getUsers().contains(user));
	
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}
}
