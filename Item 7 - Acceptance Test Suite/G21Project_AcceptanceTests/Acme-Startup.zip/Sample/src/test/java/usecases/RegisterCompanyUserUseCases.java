
package usecases;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Company;
import forms.CompanyForm;
import security.Authority;
import security.UserAccount;
import services.ActorService;
import services.CompanyService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class RegisterCompanyUserUseCases extends AbstractTest {

	@Autowired
	private ActorService actorService;

	@Autowired
	private CompanyService companyService;


	@Test
	public void testRegisterCompany() {
		final Object testingData[][] = {
			{
				/* Registro V�lido */
				formularioDeRegistroValido(), null

			},
			{
				/* Differents Passwords */
				formularioDeRegistroContrase�asDiferentes(), IllegalArgumentException.class
			},
			{
				/* Ususario ya registrado */
				formularioDeRegistroCompanyRegistrada(), IllegalArgumentException.class
			},
			{
				/* Email mal escrito */
				formularioDeRegistroEmailMal(), IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.drive((CompanyForm) testingData[i][0], (Class<?>) testingData[i][1]);

	}

	//---------------------------TEMPLATE---------------------------------------------

	protected void drive(CompanyForm companyForm, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			Assert.isTrue(validaciones(companyForm));
			registroCompany(companyForm);
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

	//---------------------------TEST-------------------------------------------------

	private CompanyForm formularioDeRegistroValido() {
		CompanyForm result = new CompanyForm();

		result.setName("Nicol�s");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("manCompany");
		result.setPassword("manCompany");
		result.setConfPassword("manCompany");
		result.setTerms(true);

		return result;
	}

	private CompanyForm formularioDeRegistroEmailMal() {
		CompanyForm result = new CompanyForm();

		result.setName("Nicol�s");
		result.setEmail("email");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("manCompany");
		result.setPassword("manCompany");
		result.setConfPassword("manCompany");
		result.setTerms(true);

		return result;
	}

	private CompanyForm formularioDeRegistroCompanyRegistrada() {
		CompanyForm result = new CompanyForm();

		result.setName("Nicol�s");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("company1");
		result.setPassword("manCompany");
		result.setConfPassword("manCompany");
		result.setTerms(true);

		return result;
	}

	private CompanyForm formularioDeRegistroContrase�asDiferentes() {
		CompanyForm result = new CompanyForm();

		result.setName("Nicol�s");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("company11");
		result.setPassword("manCompany");
		result.setConfPassword("manpany");
		result.setTerms(true);

		return result;
	}

	//---------------------------COMPROBACIONES---------------------------------------

	private Boolean validaciones(CompanyForm companyForm) {
		Assert.isTrue(companyForm.getTerms());
		Assert.isTrue(actorService.findEqualsUsername(companyForm.getUsername()) == 0);
		Assert.isTrue(actorService.findEqualsEmail(companyForm.getEmail()) == 0);
		Assert.isTrue(companyForm.getPassword().equals(companyForm.getConfPassword()));
		return true;
	}

	private void registroCompany(CompanyForm companyForm) {
		Company u = companyService.create();
		u.setName(companyForm.getName());
		u.setEmail(companyForm.getEmail());
		u.setPhone(companyForm.getPhone());
		u.setAddress(companyForm.getAddress());
		u.setPostalAddress(companyForm.getPostalAddress());
		u.setPro(false);

		// UserAccount --------------------------------------------
		Authority auth = new Authority();
		auth.setAuthority(Authority.COMPANY);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername(companyForm.getUsername());
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword(companyForm.getPassword(), null));
		userAccount.getAuthorities().add(auth);
		u.setUserAccount(userAccount);
		userAccount.setBanned(true);
		companyService.save(u);
	}
}
