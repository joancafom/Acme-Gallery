
package usecases;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Merchant;
import forms.SponsorForm;
import security.Authority;
import security.UserAccount;
import services.ActorService;
import services.MerchantService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class RegisterMerchantUseCases extends AbstractTest {

	@Autowired
	private MerchantService merchantService;

	@Autowired
	private ActorService actorService;


	//---------------------------TEST-------------------------------------------------

	@Test
	public void testRegisterMerchant() {
		final Object testingData[][] = {
			{
				/* Registro V�lido */
				formularioDeRegistroValido(), null

			},
			{
				/* Differents Passwords */
				formularioDeRegistroContrase�asDiferentes(), IllegalArgumentException.class
			},
			{
				/* Ususario ya registrado */
				formularioDeRegistroMerchantRegistrado(), IllegalArgumentException.class
			},
			{
				/* Email mal escrito */
				formularioDeRegistroEmailMal(), IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.drive((SponsorForm) testingData[i][0], (Class<?>) testingData[i][1]);

	}

	//---------------------------TEMPLATE---------------------------------------------

	protected void drive(SponsorForm sponsorForm, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			Assert.isTrue(validaciones(sponsorForm));
			registroMerchant(sponsorForm);
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

	//---------------------------DATOS------------------------------------------------

	private SponsorForm formularioDeRegistroValido() {
		SponsorForm result = new SponsorForm();

		result.setName("Nicol�s");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("manManager");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private SponsorForm formularioDeRegistroEmailMal() {
		SponsorForm result = new SponsorForm();

		result.setName("Nicol�s");
		result.setEmail("emailemail.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("manManager");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private SponsorForm formularioDeRegistroMerchantRegistrado() {
		SponsorForm result = new SponsorForm();

		result.setName("Nicol�s");
		result.setEmail("emailemail.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("merchant1");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private SponsorForm formularioDeRegistroContrase�asDiferentes() {
		SponsorForm result = new SponsorForm();

		result.setName("Nicol�s");
		result.setEmail("emailemail.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setUsername("manManager");
		result.setPassword("manManager");
		result.setConfPassword("mgerll");
		result.setTerms(true);

		return result;
	}

	//---------------------------COMPROBACIONES---------------------------------------

	private Boolean validaciones(SponsorForm sponsorForm) {
		Assert.isTrue(sponsorForm.getTerms());
		Assert.isTrue(actorService.findEqualsUsername(sponsorForm.getUsername()) == 0);
		Assert.isTrue(actorService.findEqualsEmail(sponsorForm.getEmail()) == 0);
		Assert.isTrue(sponsorForm.getPassword().equals(sponsorForm.getConfPassword()));
		return true;
	}

	private void registroMerchant(SponsorForm sponsorForm) {
		Merchant u = merchantService.create();
		u.setName(sponsorForm.getName());
		u.setEmail(sponsorForm.getEmail());
		u.setPhone(sponsorForm.getPhone());
		u.setAddress(sponsorForm.getAddress());
		u.setPostalAddress(sponsorForm.getPostalAddress());

		// UserAccount --------------------------------------------
		Authority auth = new Authority();
		auth.setAuthority(Authority.MERCHANT);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername(sponsorForm.getUsername());
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword(sponsorForm.getPassword(), null));
		userAccount.getAuthorities().add(auth);
		u.setUserAccount(userAccount);
		userAccount.setBanned(true);
		merchantService.save(u);
	}
}
