
package usecases;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Basket;
import domain.Item;
import domain.User;
import forms.UserForm;
import security.Authority;
import security.UserAccount;
import services.ActorService;
import services.BasketService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class RegisterUserUseCases extends AbstractTest {

	@Autowired
	private UserService userService;

	@Autowired
	private ActorService actorService;

	@Autowired
	private BasketService basketService;


	//---------------------------TEST-------------------------------------------------

	@Test
	public void testRegisterUser() {
		final Object testingData[][] = {
			{
				/* Registro V�lido */
				formularioDeRegistroValido(), null

			},
			{
				/* Differents Passwords */
				formularioDeRegistroContrase�asDiferentes(), IllegalArgumentException.class
			},
			{
				/* Ususario ya registrado */
				formularioDeRegistroUserRegistrado(), IllegalArgumentException.class
			},
			{
				/* Email mal escrito */
				formularioDeRegistroEmailMal(), IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.drive((UserForm) testingData[i][0], (Class<?>) testingData[i][1]);

	}

	//---------------------------TEMPLATE---------------------------------------------

	protected void drive(UserForm userForm, final Class<?> expected) {

		Class<?> caught;
		caught = null;
		try {
			Assert.isTrue(validaciones(userForm));
			registroUser(userForm);
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}

	//---------------------------DATOS------------------------------------------------

	private UserForm formularioDeRegistroValido() {
		UserForm result = new UserForm();

		result.setName("Nicol�s");
		result.setSurname("Cortes Ruiz");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setProfession("Estudiante");
		result.setUsername("manManager");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private UserForm formularioDeRegistroEmailMal() {
		UserForm result = new UserForm();

		result.setName("Nicol�s");
		result.setSurname("Cortes Ruiz");
		result.setEmail("email");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setProfession("Estudiante");
		result.setUsername("manManager");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private UserForm formularioDeRegistroUserRegistrado() {
		UserForm result = new UserForm();

		result.setName("Nicol�s");
		result.setSurname("Cortes Ruiz");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setPostalAddress("");
		result.setAddress("");
		result.setProfession("Estudiante");
		result.setUsername("user1");
		result.setPassword("manManager");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	private UserForm formularioDeRegistroContrase�asDiferentes() {
		UserForm result = new UserForm();

		result.setName("Nicol�s");
		result.setSurname("Cortes Ruiz");
		result.setEmail("email@email.com");
		result.setPhone("");
		result.setAddress("");
		result.setPostalAddress("");
		result.setProfession("Estudiante");
		result.setUsername("manManager");
		result.setPassword("manMana");
		result.setConfPassword("manManager");
		result.setTerms(true);

		return result;
	}

	//---------------------------COMPROBACIONES---------------------------------------

	private Boolean validaciones(UserForm userForm) {
		Assert.isTrue(userForm.getTerms());
		Assert.isTrue(actorService.findEqualsUsername(userForm.getUsername()) == 0);
		Assert.isTrue(actorService.findEqualsEmail(userForm.getEmail()) == 0);
		Assert.isTrue(userForm.getPassword().equals(userForm.getConfPassword()));
		return true;
	}

	private void registroUser(UserForm userForm) {
		User u = userService.create();
		u.setName(userForm.getName());
		u.setSurname(userForm.getSurname());
		u.setEmail(userForm.getEmail());
		u.setPhone(userForm.getPhone());
		u.setAddress(userForm.getAddress());
		u.setPostalAddress(userForm.getPostalAddress());
		u.setProfession(userForm.getProfession());
		u.setPro(false);
		Basket b = new Basket();
		Collection<Item> items = new HashSet<Item>();
		b.setItems(items);
		b.setDate(new Date(System.currentTimeMillis() - 1000));
		b.setTotal(0.0);
		Basket bb = basketService.save(b);
		u.setBasket(bb);

		// UserAccount --------------------------------------------
		Authority auth = new Authority();
		auth.setAuthority(Authority.USER);
		UserAccount userAccount = new UserAccount();
		userAccount.setUsername(userForm.getUsername());
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		userAccount.setPassword(encoder.encodePassword(userForm.getPassword(), null));
		userAccount.getAuthorities().add(auth);
		u.setUserAccount(userAccount);
		userService.save(u);
	}

}
