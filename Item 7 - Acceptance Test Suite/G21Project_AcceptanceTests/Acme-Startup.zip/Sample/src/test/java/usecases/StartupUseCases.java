package usecases;

import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import domain.Startup;
import domain.User;
import services.StartupService;
import services.UserService;
import utilities.AbstractTest;

@ContextConfiguration(locations = {
		"classpath:spring/junit.xml"
	})
	@RunWith(SpringJUnit4ClassRunner.class)
	@Transactional
public class StartupUseCases extends AbstractTest{
	
	@Autowired
	private StartupService startupService;
	
	@Autowired
	private UserService userService;
	
	
	//SUBCRIBIRSE A UNA STARTUP---------------------------------------------------------------
	@Test 
	public void subscribeStartup() {

		final Object testingData[][] = {
			{
				/* Subscribirse a una startup */
				"user1", 1523, null
			}, {
				/* Subscribirse a una startup sin autenticaci�n */
				null, 1523, IllegalArgumentException.class
			}, {
				/* Subscribirse a una startup que ya est�s subscrito */
				"user1", 1521, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.subscribeStartupTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}
	
	/*
	 * 12.1
	 */
	protected void subscribeStartupTemplate(final String username, final int startupId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			User user = userService.findByPrincipal();
			Collection<Startup> startups = new ArrayList<Startup>();
			startups=startupService.findAll();
			Assert.notNull(startups);
			Startup startup= startupService.findOne(startupId);
			this.startupService.subscribe(startup, user.getId());
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}	

	
	
	
	//UNSUBCRIBIRSE A UNA STARTUP---------------------------------------------------------------
	@Test 
	public void unSubscribeStartup() {

		final Object testingData[][] = {
			{
				/* UnSubscribirse a una startup */
				"user1", 1521, null
			}, {
				/* UnSubscribirse a una startup sin autenticaci�n */
				null, 1521, IllegalArgumentException.class
			}, {
				/* UnSubscribirse a una startup que no est�s subscrito */
				"user1", 1523, IllegalArgumentException.class
			}

		};

		for (int i = 0; i < testingData.length; i++)
			this.unSubscribeStartupTemplate((String) testingData[i][0], (int) testingData[i][1], (Class<?>) testingData[i][2]);
	}
	
	/*
	 * 12.1
	 */
	protected void unSubscribeStartupTemplate(final String username, final int startupId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			this.authenticate(username);
			User user = userService.findByPrincipal();
			Collection<Startup> startups = new ArrayList<Startup>();
			startups=user.getStartups();
			Assert.notNull(startups);
			Startup startup= startupService.findOne(startupId);
			this.startupService.unSubscribe(startup, user.getId());
		} catch (final Throwable oops) {
			caught = oops.getClass();

		}

		this.checkExceptions(expected, caught);
	}
}
